plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xadrezdica"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.xadrezdica"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += "arm64-v8a" }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        jniLibs {
            // o Stockfish entra como libstockfish.so e precisa ser extraído pra pasta nativa do app
            useLegacyPackaging = true
            keepDebugSymbols += "**/libstockfish.so"
        }
    }
}
