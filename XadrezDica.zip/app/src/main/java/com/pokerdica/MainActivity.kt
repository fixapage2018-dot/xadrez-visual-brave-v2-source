package com.pokerdica

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.ViewGroup
import android.graphics.Bitmap
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import com.pokerdica.core.Glyphs
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var teachBox: LinearLayout

    override fun onResume() {
        super.onResume()
        refreshTeach()
    }

    private fun prefs() = getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun labelsFor(kind: String): List<Pair<String, String>> = when (kind) {
        "rank" -> listOf("A", "K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2").map { it to it }
        "suit" -> listOf("♥" to "h", "♦" to "d", "♠" to "s", "♣" to "c")
        else -> listOf("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "K", "M").map { it to it }
    }

    private fun refreshTeach() {
        teachBox.removeAllViews()
        val lines = (prefs().getString("pending", "") ?: "").lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) { teachBox.addView(tv("Nada pendente. Quando o jogo mostrar algo que o app não conhece, aparece aqui.", 14f)); return }
        for (line in lines) {
            val p = line.split("|")
            if (p.size < 4) continue
            val kind = p[0]; val aspect = p[1].toFloatOrNull() ?: 1f; val hex = p[2]; val where = p[3]
            val n = Glyphs.fromHex(kind, aspect, hex)
            val bmp = Bitmap.createBitmap(n.w * 8, n.h * 8, Bitmap.Config.ARGB_8888)
            for (y in 0 until n.h) for (x in 0 until n.w) {
                val c = if (n.m[y * n.w + x]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
                for (dy in 0 until 8) for (dx in 0 until 8) bmp.setPixel(x * 8 + dx, y * 8 + dy, c)
            }
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 16) }
            box.addView(tv(when (kind) { "rank" -> "Que VALOR de carta é este? ($where)"; "suit" -> "Que NAIPE é este? ($where)"; else -> "Que NÚMERO é este? ($where)" }, 14f))
            box.addView(ImageView(this).apply { setImageBitmap(bmp); setBackgroundColor(0xFFDDDDDD.toInt()); setPadding(8, 8, 8, 8) })
            val grid = GridLayout(this).apply { columnCount = 7 }
            for ((shown, value) in labelsFor(kind)) grid.addView(Button(this).apply {
                text = shown; minWidth = 0; minimumWidth = 0; setPadding(10, 6, 10, 6)
                setOnClickListener { learn(line, kind, value, aspect, hex) }
            })
            grid.addView(Button(this).apply { text = "pular"; setOnClickListener { learn(line, kind, null, aspect, hex) } })
            box.addView(grid)
            teachBox.addView(box)
        }
    }

    private fun learn(line: String, kind: String, label: String?, aspect: Float, hex: String) {
        val sp = prefs()
        val e = sp.edit()
        if (label != null) {
            val cur = sp.getString("learned", "") ?: ""
            e.putString("learned", cur + "$kind $label ${"%.3f".format(java.util.Locale.US, aspect)} $hex\n")
            e.putLong("learned_in", System.currentTimeMillis())
        }
        val rest = (sp.getString("pending", "") ?: "").lines().filter { it.isNotBlank() && it != line }
        e.putString("pending", rest.joinToString("\n"))
        e.apply()
        refreshTeach()
    }
    private fun tv(text: String, sp: Float = 15f): TextView = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setPadding(0, 12, 0, 12)
    }

    private fun btn(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 60)
        }
        col.addView(tv("Poker Dica", 26f))
        col.addView(tv(
            "1) Permita exibir sobre outros apps.\n" +
            "2) Toque em INICIAR e permita a captura de tela.\n" +
            "3) Abra o jogo (deitado). A caixinha mostra sua mão, a chance de ganhar e a sugestão.\n" +
            "4) Se aparecer uma janelinha perguntando que carta/número é, toque no certo: o app aprende e guarda."
        ))
        col.addView(btn("1. Permitir exibir sobre outros apps") { askOverlay() })
        col.addView(btn("2. INICIAR") { start() })
        col.addView(btn("Parar") { stopService(Intent(this, CaptureService::class.java)) })
        col.addView(btn("Esquecer o que aprendi") {
            getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().remove("learned").remove("pending").putLong("learned_in", System.currentTimeMillis()).apply()
            refreshTeach()
            Toast.makeText(this, "Apagado. Toque em Parar e INICIAR de novo.", Toast.LENGTH_LONG).show()
        })
        teachBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv("Ensinar símbolos novos (faça depois do jogo, sem pressa):", 16f))
        col.addView(teachBox)
        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    private fun askOverlay() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primeiro permita exibir sobre outros apps", Toast.LENGTH_LONG).show()
            askOverlay()
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            startForegroundService(i)
            Toast.makeText(this, "Rodando. Abra o jogo.", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
