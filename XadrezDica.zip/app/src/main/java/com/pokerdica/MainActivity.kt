package com.pokerdica

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun tv(text: String, sp: Float = 15f): TextView = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setPadding(0, 12, 0, 12)
    }

    private fun btn(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 60)
        }
        col.addView(tv("Poker Dica", 26f))
        col.addView(tv(
            "1) Permita exibir sobre outros apps.\n" +
            "2) Toque em INICIAR e permita a captura de tela.\n" +
            "3) Abra o jogo (deitado). A caixinha mostra sua mão, a chance de ganhar e a sugestão.\n" +
            "4) Se aparecer uma janelinha perguntando que carta/número é, toque no certo: o app aprende e guarda."
        ))
        col.addView(btn("1. Permitir exibir sobre outros apps") { askOverlay() })
        col.addView(btn("2. INICIAR") { start() })
        col.addView(btn("Parar") { stopService(Intent(this, CaptureService::class.java)) })
        col.addView(btn("Esquecer o que aprendi") {
            getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().remove("learned").apply()
            Toast.makeText(this, "Apagado. Toque em Parar e INICIAR de novo.", Toast.LENGTH_LONG).show()
        })
        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    private fun askOverlay() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primeiro permita exibir sobre outros apps", Toast.LENGTH_LONG).show()
            askOverlay()
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            startForegroundService(i)
            Toast.makeText(this, "Rodando. Abra o jogo.", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
