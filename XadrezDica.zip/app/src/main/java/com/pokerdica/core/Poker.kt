package com.pokerdica.core

import java.util.Random

/** Carta = naipe*13 + rank. rank 0..12 = 2..A ; naipe 0=♥ 1=♦ 2=♠ 3=♣ */
object Cards {
    const val RANKS = "23456789TJQKA"
    const val SUITS = "hdsc"
    fun make(rank: Int, suit: Int) = suit * 13 + rank
    fun rank(c: Int) = c % 13
    fun suit(c: Int) = c / 13
    fun parseRank(s: String): Int = when (s) { "10" -> 8; else -> RANKS.indexOf(s[0]) }
    fun rankLabel(r: Int) = if (r == 8) "10" else RANKS[r].toString()
    fun suitSymbol(s: Int) = when (s) { 0 -> "♥"; 1 -> "♦"; 2 -> "♠"; else -> "♣" }
    fun name(c: Int) = rankLabel(rank(c)) + suitSymbol(suit(c))
    fun parse(s: String): Int {   // "Kh", "10d", "Ts"
        val suit = SUITS.indexOf(s.last())
        val r = s.dropLast(1)
        return make(if (r == "T") 8 else parseRank(r), suit)
    }
}

object Eval {
    private fun straightHigh(mask: Int): Int {
        for (h in 12 downTo 4) {
            val need = 0x1F shl (h - 4)
            if (mask and need == need) return h
        }
        if (mask and 0x100F == 0x100F) return 3   // A-2-3-4-5
        return -1
    }

    /** Avalia as melhores 5 de n (5..7) cartas. Maior = melhor. */
    fun eval(c: IntArray, n: Int): Int {
        val rc = IntArray(13); val sm = IntArray(4); val sc = IntArray(4)
        var all = 0
        for (i in 0 until n) {
            val r = c[i] % 13; val s = c[i] / 13
            rc[r]++; sm[s] = sm[s] or (1 shl r); sc[s]++; all = all or (1 shl r)
        }
        var fs = -1
        for (s in 0..3) if (sc[s] >= 5) fs = s
        if (fs >= 0) {
            val h = straightHigh(sm[fs])
            if (h >= 0) return (8 shl 20) or h
        }
        var quad = -1; var trips = -1; var p1 = -1; var p2 = -1
        for (r in 12 downTo 0) {
            when (rc[r]) {
                4 -> if (quad < 0) quad = r
                3 -> if (trips < 0) trips = r else if (p1 < 0) p1 = r
                2 -> if (p1 < 0) p1 = r else if (p2 < 0) p2 = r
            }
        }
        if (quad >= 0) {
            var k = -1
            for (r in 12 downTo 0) if (r != quad && rc[r] > 0) { k = r; break }
            return (7 shl 20) or (quad shl 4) or k
        }
        if (trips >= 0 && p1 >= 0) return (6 shl 20) or (trips shl 4) or p1
        if (fs >= 0) {
            var v = 0; var cnt = 0
            for (r in 12 downTo 0) if (sm[fs] and (1 shl r) != 0 && cnt < 5) { v = (v shl 4) or r; cnt++ }
            return (5 shl 20) or v
        }
        val sh = straightHigh(all)
        if (sh >= 0) return (4 shl 20) or sh
        if (trips >= 0) {
            var v = 0; var cnt = 0
            for (r in 12 downTo 0) if (r != trips && rc[r] > 0 && cnt < 2) { v = (v shl 4) or r; cnt++ }
            return (3 shl 20) or (trips shl 8) or v
        }
        if (p1 >= 0 && p2 >= 0) {
            var k = -1
            for (r in 12 downTo 0) if (r != p1 && r != p2 && rc[r] > 0) { k = r; break }
            return (2 shl 20) or (p1 shl 8) or (p2 shl 4) or k
        }
        if (p1 >= 0) {
            var v = 0; var cnt = 0
            for (r in 12 downTo 0) if (r != p1 && rc[r] > 0 && cnt < 3) { v = (v shl 4) or r; cnt++ }
            return (1 shl 20) or (p1 shl 12) or v
        }
        var v = 0; var cnt = 0
        for (r in 12 downTo 0) if (rc[r] > 0 && cnt < 5) { v = (v shl 4) or r; cnt++ }
        return v
    }

    fun category(score: Int) = score shr 20
}

class EquityResult(val equity: Double, val win: Double, val tie: Double, val sims: Int)

object Equity {
    /** Chance de ganhar contra [opps] adversários com mãos aleatórias (Monte Carlo). */
    fun run(hero: IntArray, board: IntArray, opps: Int, sims: Int, rnd: Random = Random()): EquityResult {
        val used = BooleanArray(52)
        for (c in hero) used[c] = true
        for (c in board) used[c] = true
        val deck = IntArray(52); var nd = 0
        for (c in 0 until 52) if (!used[c]) deck[nd++] = c
        val needBoard = 5 - board.size
        val need = needBoard + 2 * opps
        val seven = IntArray(7)
        var wins = 0.0; var ties = 0.0
        val full = IntArray(5)
        for (s in 0 until sims) {
            for (i in 0 until need) {
                val j = i + rnd.nextInt(nd - i)
                val t = deck[i]; deck[i] = deck[j]; deck[j] = t
            }
            for (i in board.indices) full[i] = board[i]
            for (i in 0 until needBoard) full[board.size + i] = deck[i]
            seven[0] = hero[0]; seven[1] = hero[1]
            for (i in 0 until 5) seven[2 + i] = full[i]
            val hs = Eval.eval(seven, 7)
            var best = -1; var cnt = 0
            for (o in 0 until opps) {
                seven[0] = deck[needBoard + 2 * o]; seven[1] = deck[needBoard + 2 * o + 1]
                val os = Eval.eval(seven, 7)
                if (os > best) { best = os; cnt = 1 } else if (os == best) cnt++
            }
            if (hs > best) wins += 1.0
            else if (hs == best) { ties += 1.0 / (cnt + 1) }
        }
        return EquityResult((wins + ties) / sims, wins / sims, ties / sims, sims)
    }
}
