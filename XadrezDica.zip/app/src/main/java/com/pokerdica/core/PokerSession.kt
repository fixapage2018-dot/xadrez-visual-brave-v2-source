package com.pokerdica.core

import java.util.Random
import java.util.ArrayList

class PokerSession(
    val glyphs: Glyphs,
    val onLearned: () -> Unit = {},
    val onUnknown: (Unknown) -> Unit = {}
) {
    class Out(
        val lines: List<String>,
        val action: String?,
        val heroTurn: Boolean,
        val learn: Unknown?
    ) {
        val text: String get() = lines.joinToString("\n")
    }

    private val reader = TableReader(glyphs)
    private val rnd = Random()
    private var lastKey = ""
    private var stable = 0
    private var last: Out = Out(listOf("Poker Dica: aguardando a mesa..."), null, false, null)
    private val ignored = HashSet<String>()
    private val seenCount = HashMap<String, Int>()
    private var calcKey = ""
    private var calcEq: EquityResult? = null

    fun learn(u: Unknown, label: String) {
        glyphs.add(u.kind, label, u.norm)
        onLearned()
        lastKey = ""
        stable = 0
    }

    fun ignore(u: Unknown) {
        ignored.add(u.sig)
    }

    fun tick(bmp: android.graphics.Bitmap): Out {
        val st = reader.read(bmp)

        // Verificação do Hero
        val heroCards = ArrayList<Card>()
        for (c in st.hero) {
            if (c != null) heroCards.add(c)
        }
        if (heroCards.size < 2) {
            return Out(listOf("Identificando cartas da mao..."), null, st.heroTurn, null)
        }

        val boardCards = ArrayList<Card>()
        var unread = 0
        for (c in st.board) {
            if (c != null) {
                boardCards.add(c)
            } else {
                unread = unread + 1
            }
        }

        if (st.board.size == 1 || st.board.size == 2) {
            return Out(listOf("Aguardando flop completo..."), null, st.heroTurn, null)
        }

        // Filtro de cartas repetidas em transição de animação
        val cardSet = HashSet<String>()
        for (c in heroCards) cardSet.add(c.toString())
        for (c in boardCards) cardSet.add(c.toString())
        if (cardSet.size != (heroCards.size + boardCards.size)) {
            return Out(listOf("Aguardando cartas estabilizarem..."), null, st.heroTurn, null)
        }

        val ck = heroCards[0].toString() + "," + heroCards[1].toString() + "|" + boardCards.size.toString() + "|" + st.opponents.toString()
        if (ck != calcKey) {
            calcEq = Equity.run(heroCards, boardCards, st.opponents, 8000, rnd)
            calcKey = ck
        }

        val eq = if (calcEq != null) calcEq!!.equity else 0.0

        var maxBet = 0L
        var betUnk = false
        var sum = 0L
        for (entry in st.bets.entries) {
            val v = entry.value
            if (v == null) {
                betUnk = true
            } else {
                sum = sum + v
                if (v > maxBet) {
                    maxBet = v
                }
            }
        }

        val mine = if (st.bets.containsKey("eu") && st.bets["eu"] != null) st.bets["eu"]!! else 0L
        val toCall: Long? = if (betUnk) null else (if (maxBet - mine > 0L) maxBet - mine else 0L)
        val pot: Long? = if (betUnk) st.pot else ((if (st.pot != null) st.pot!! else 0L) + sum)

        val adv = Advisor.advise(eq, st.opponents, pot, toCall)

        val outLines = ArrayList<String>()
        val vezTexto = if (st.heroTurn) "SUA VEZ  " else "(nao e sua vez)  "
        val heroStr = Cards.name(heroCards[0]) + " " + Cards.name(heroCards[1])
        val sbBoard = java.lang.StringBuilder()
        for (i in 0 until boardCards.size) {
            if (i > 0) sbBoard.append(" ")
            sbBoard.append(Cards.name(boardCards[i]))
        }
        val boardStr = if (boardCards.size > 0) "  |  " + sbBoard.toString() else ""
        outLines.add(vezTexto + heroStr + boardStr)
        outLines.addAll(adv.lines)

        if (unread > 0) {
            outLines.add("(" + unread.toString() + " carta(s) da mesa nao lida(s))")
        }
        outLines.add("-> " + adv.action)

        return Out(outLines, adv.action, st.heroTurn, null)
    }
}
