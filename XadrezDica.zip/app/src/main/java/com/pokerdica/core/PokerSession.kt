package com.pokerdica.core

class PokerSession(val advisor: Advisor) {

    data class Out(
        val text: String,
        val heroTurn: Boolean,
        val action: Advisor.Action?
    )

    private var lastState: TableReader.State? = null
    private var stableState: TableReader.State? = null
    private var stableCount = 0

    private var lastOut: Out = Out("Aguardando jogo...", false, null)
    private var equityCacheKey = ""
    private var lastEquity = 0.0

    fun tick(st: TableReader.State): Out {
        if (st.hero.isEmpty()) {
            stableState = null
            stableCount = 0
            lastOut = Out("Aguardando suas cartas...", false, null)
            return lastOut
        }

        if (st.unknown != null) {
            return Out("Novo símbolo: ${st.unknown.kind} em ${st.unknown.where}", false, null)
        }

        // Validação correta: só rejeita se a mesma CARTA (valor + naipe) for idêntica
        val allCards = st.hero + st.board
        val uniqueCards = allCards.distinctBy { it.raw }
        if (uniqueCards.size != allCards.size) {
            return Out("Aguardando cartas estabilizarem...", false, null)
        }

        if (lastState != null && sameState(lastState!!, st)) {
            stableCount++
        } else {
            stableCount = 1
            lastState = st
        }

        if (stableCount >= 2) {
            stableState = st
            lastOut = decide(st)
        }

        return lastOut
    }

    private fun sameState(a: TableReader.State, b: TableReader.State): Boolean {
        if (a.hero != b.hero) return false
        if (a.board != b.board) return false
        if (a.toCall != b.toCall) return false
        if (a.pot != b.pot) return false
        if (a.opponents != b.opponents) return false
        if (a.heroTurn != b.heroTurn) return false
        return true
    }

    private fun decide(st: TableReader.State): Out {
        val key = st.hero.joinToString("") { it.raw } + "|" + st.board.joinToString("") { it.raw } + "|" + st.opponents
        val equity = if (key == equityCacheKey) {
            lastEquity
        } else {
            val eq = Equity.calc(st.hero, st.board, st.opponents, 4000)
            equityCacheKey = key
            lastEquity = eq
            eq
        }

        val pct = (equity * 100).toInt()
        val adv = advisor.advise(equity, st.pot, st.toCall, st.opponents)

        val heroStr = st.hero.joinToString(" ") { it.raw }
        val boardStr = if (st.board.isEmpty()) "-" else st.board.joinToString(" ") { it.raw }
        val potStr = if (st.pot != null) formatChips(st.pot) else "?"
        val toCallStr = formatChips(st.toCall)

        val turnWarn = if (st.heroTurn) "SUA VEZ! " else ""

        val txt = """
            $turnWarn${adv.action.name}
            Mão: $heroStr  Mesa: $boardStr
            Vitória: $pct% (vs ${st.opponents} opp)
            Pote: $potStr | Pagar: $toCallStr
        """.trimIndent()

        return Out(txt, st.heroTurn, adv.action)
    }

    private fun formatChips(n: Long): String {
        return when {
            n >= 1_000_000 -> String.format("%.1fM", n / 1_000_000.0)
            n >= 1_000 -> String.format("%.0fK", n / 1_000.0)
            else -> n.toString()
        }
    }
}
