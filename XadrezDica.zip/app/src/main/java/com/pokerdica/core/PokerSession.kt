No trecho de `decide`, substitua:
```kotlin
        val all = hero.toList() + board.toList()
        if (all.toSet().size != all.size) return Out(listOf(""), null, st.heroTurn, null)
```
por:
```kotlin
        val all = hero.toList() + board.toList()
        // O identificador da carta representa rank e naipe; só a mesma carta exata é repetição.
        if (all.groupingBy { it }.eachCount().values.any { it > 1 }) {
            return Out(listOf(""), null, st.heroTurn, null)
        }
```