package com.pokerdica.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Algo que o leitor não reconheceu: o app pergunta ao usuário. */
class Unknown(val kind: String, val norm: Norm, val where: String)

/** Resultado de ler uma carta: carta conhecida, ausente ou com símbolo desconhecido. */
class CardRead(val card: Int?, val faceUp: Boolean, val unknown: List<Unknown> = emptyList(), val desc: String = "")

class TableState(
    val hero: List<CardRead>,
    val board: List<CardRead>,
    val pot: Long?,
    val potUnknown: List<Unknown>,
    val bets: Map<String, Long?>,
    val betUnknown: List<Unknown>,
    val opponents: Int,
    val heroTurn: Boolean
) {
    fun heroCards(): IntArray? = if (hero.size == 2 && hero.all { it.card != null }) intArrayOf(hero[0].card!!, hero[1].card!!) else null
    fun boardCards(): IntArray? {
        val faces = board.filter { it.faceUp }
        if (faces.any { it.card == null }) return null
        return faces.map { it.card!! }.toIntArray()
    }
    fun allUnknown(): List<Unknown> {
        val l = ArrayList<Unknown>()
        for (c in hero + board) l.addAll(c.unknown)
        l.addAll(potUnknown); l.addAll(betUnknown)
        return l
    }
    fun key(): String = "H" + hero.joinToString(",") { it.card?.toString() ?: "?" } + "|B" +
        board.joinToString(",") { if (!it.faceUp) "-" else it.card?.toString() ?: "?" } + "|P$pot|" +
        bets.entries.sortedBy { it.key }.joinToString(",") { "${it.key}=${it.value}" } + "|O$opponents|T$heroTurn"
}

/**
 * Lê a mesa do jogo (tela deitada). Todas as coordenadas abaixo são do print 2400x1080 e escalam pela largura.
 */
class TableReader(val glyphs: Glyphs) {
    private var pix = IntArray(0)
    private var fw = 0
    private var fh = 0
    private var sc = 1.0

    class Rect(val x0: Int, val y0: Int, val x1: Int, val y1: Int) {
        val w get() = x1 - x0
        val h get() = y1 - y0
    }

    private fun at(x: Int, y: Int): Int {
        val sx = (x * sc).toInt(); val sy = (y * sc).toInt()
        if (sx < 0 || sy < 0 || sx >= fw || sy >= fh) return 0
        return pix[sy * fw + sx]
    }

    companion object {
        const val BOARD_L = 1030; const val BOARD_T = 413; const val BOARD_STEP = 123; const val CW = 103; const val CH = 145
        val POT_WIN = Rect(1295, 585, 1560, 632)
        val SEATS = listOf("rei", "jordan", "esq", "zeus", "eu")
        val PILL = mapOf(
            "rei" to Rect(900, 270, 1120, 340), "jordan" to Rect(1530, 275, 1760, 345),
            "esq" to Rect(760, 550, 1010, 620), "zeus" to Rect(1700, 550, 1960, 620), "eu" to Rect(1330, 630, 1620, 700)
        )
        val BACKS = listOf(Rect(1120, 275, 1215, 345), Rect(1440, 275, 1530, 345), Rect(795, 675, 885, 745), Rect(1765, 670, 1855, 740))
        val HERO_RING = Rect(1000, 600, 1300, 920)
        val HERO1 = Rect(1320, 680, 1410, 790)
        val HERO2 = Rect(1420, 670, 1515, 790)
    }

    // ---------------- cores ----------------
    private fun isInk(p: Int): Boolean {
        val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
        val black = r < 110 && g < 110 && b < 110 && max(r, max(g, b)) - min(r, min(g, b)) < 45
        val red = r > 140 && g < 110 && b < 120 && r - g > 70
        return black || red
    }
    private fun isRed(p: Int): Boolean {
        val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
        return r > 140 && g < 110 && b < 120 && r - g > 70
    }
    private fun isWhite(p: Int): Boolean {
        val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
        return min(r, min(g, b)) >= 190
    }

    // ---------------- cartas ----------------
    /** Símbolos de uma janela de carta: primeira corrida de linhas com tinta = rank; segunda = naipe. */
    class CardGlyphs(val rankMask: BooleanArray?, val rw: Int, val rh: Int, val suitMask: BooleanArray?, val sw: Int, val sh: Int, val red: Boolean)

    /** Erosão (erode=true) ou dilatação em caixa (2r+1)x(2r+1). [outside] = valor assumido fora da janela. */
    private fun morph(src: BooleanArray, w: Int, h: Int, r: Int, erode: Boolean, outside: Boolean = false): BooleanArray {
        val tmp = BooleanArray(w * h)
        val out = BooleanArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var v = erode
            for (dx in -r..r) {
                val nx = x + dx
                val b = if (nx < 0 || nx >= w) outside else src[y * w + nx]
                if (erode) { if (!b) { v = false; break } } else { if (b) { v = true; break } }
            }
            tmp[y * w + x] = v
        }
        for (y in 0 until h) for (x in 0 until w) {
            var v = erode
            for (dy in -r..r) {
                val ny = y + dy
                val b = if (ny < 0 || ny >= h) outside else tmp[ny * w + x]
                if (erode) { if (!b) { v = false; break } } else { if (b) { v = true; break } }
            }
            out[y * w + x] = v
        }
        return out
    }

    private class Cc(var x0: Int, var y0: Int, var x1: Int, var y1: Int, var area: Int, val px: ArrayList<Int>)

    /**
     * Valor (grande, no alto) e naipe (pequeno, logo abaixo) do canto da carta, por componentes conectados:
     * rank = componentes da faixa do topo; naipe = componente mais alto logo abaixo do rank.
     */
    fun glyphsIn(win: Rect): CardGlyphs {
        val w = win.w; val h = win.h
        val ink = BooleanArray(w * h)
        val red = BooleanArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val p = at(win.x0 + x, win.y0 + y)
            if (isInk(p)) { ink[y * w + x] = true; red[y * w + x] = isRed(p) }
        }
        val seen = BooleanArray(w * h)
        val stack = IntArray(w * h)
        val comps = ArrayList<Cc>()
        for (s0 in 0 until w * h) {
            if (!ink[s0] || seen[s0]) continue
            var sp = 0; stack[sp++] = s0; seen[s0] = true
            val c = Cc(s0 % w, s0 / w, s0 % w, s0 / w, 0, ArrayList())
            while (sp > 0) {
                val i = stack[--sp]; val x = i % w; val y = i / w
                c.area++; c.px.add(i)
                if (x < c.x0) c.x0 = x; if (x > c.x1) c.x1 = x; if (y < c.y0) c.y0 = y; if (y > c.y1) c.y1 = y
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx; val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val j = ny * w + nx
                    if (ink[j] && !seen[j]) { seen[j] = true; stack[sp++] = j }
                }
            }
            // tinta que encosta na borda esquerda/de baixo da janela é a mesa/sombra fora da carta, não símbolo
            if (c.area >= 50 && c.x1 - c.x0 >= 4 && c.y1 - c.y0 >= 4 && c.x0 > 0) comps.add(c)
        }
        fun maskOf(cs: List<Cc>): Triple<BooleanArray, Int, Int>? {
            if (cs.isEmpty()) return null
            val x0 = cs.minOf { it.x0 }; val x1 = cs.maxOf { it.x1 }; val y0 = cs.minOf { it.y0 }; val y1 = cs.maxOf { it.y1 }
            val mw = x1 - x0 + 1; val mh = y1 - y0 + 1
            val m = BooleanArray(mw * mh)
            for (c in cs) for (i in c.px) m[(i / w - y0) * mw + (i % w - x0)] = true
            return Triple(m, mw, mh)
        }
        if (comps.isEmpty()) return CardGlyphs(null, 0, 0, null, 0, 0, false)
        // rank: componentes cujo topo está na faixa mais alta e que têm altura de valor (>= 55% do maior do topo)
        val top = comps.minOf { it.y0 }
        val near = comps.filter { it.y0 <= top + 14 }
        val maxH = near.maxOf { it.y1 - it.y0 }
        val rankC = near.filter { it.y1 - it.y0 >= maxH * 0.55 }
        val rankBottom = rankC.maxOf { it.y1 }
        val rankLeft = rankC.minOf { it.x0 }
        // naipe pequeno: o mais alto abaixo do rank, alinhado à esquerda
        val below = comps.filter { it !in rankC && it.y0 >= rankBottom - 6 && it.x0 <= rankLeft + 30 }
        val first = below.minByOrNull { it.y0 }
        var suitC: List<Cc> = emptyList()
        var isRedSuit = false
        if (first != null) {
            suitC = below.filter { it.x1 >= first.x0 - 6 && it.x0 <= first.x1 + 6 && it.y0 <= first.y0 + 40 }
            var rr = 0; var tt = 0
            for (c in suitC) for (i in c.px) { tt++; if (red[i]) rr++ }
            isRedSuit = tt > 0 && rr * 2 > tt
        }
        val rk = maskOf(rankC); val su = maskOf(suitC)
        return CardGlyphs(rk?.first, rk?.second ?: 0, rk?.third ?: 0, su?.first, su?.second ?: 0, su?.third ?: 0, isRedSuit)
    }

    fun debugInk(frame: IntArray, frameW: Int, frameH: Int, win: Rect): String {
        pix = frame; fw = frameW; fh = frameH; sc = frameW / 2400.0
        val sb = StringBuilder()
        for (y in 0 until win.h step 2) { for (x in 0 until win.w) sb.append(if (isInk(at(win.x0 + x, win.y0 + y))) '#' else '.'); sb.append('\n') }
        return sb.toString()
    }

    private fun suitIndex(label: String) = Cards.SUITS.indexOf(label[0])

    fun classifyCard(g: CardGlyphs, where: String): CardRead {
        val unk = ArrayList<Unknown>()
        var rank: Int? = null; var suit: Int? = null
        val rn = g.rankMask?.let { Glyphs.norm("rank", it, g.rw, g.rh) }
        val sn = g.suitMask?.let { Glyphs.norm("suit", it, g.sw, g.sh) }
        if (rn == null || sn == null) return CardRead(null, true, emptyList(), "ilegível")
        val rh = glyphs.match("rank", rn)
        if (rh.label != null) rank = Cards.parseRank(rh.label) else unk.add(Unknown("rank", rn, where))
        // naipe: só entre os da mesma cor
        val sh = matchSuit(sn, g.red)
        if (sh != null) suit = suitIndex(sh) else unk.add(Unknown("suit", sn, where))
        val card = if (rank != null && suit != null) Cards.make(rank, suit) else null
        return CardRead(card, true, unk, "rank=${rh.best}:${"%.2f".format(rh.score)} suit=$sh")
    }

    var suitMin = 0.6f
    var suitMargin = 0.1f

    fun matchSuitPublic(n: Norm, red: Boolean): String? = matchSuit(n, red)

    private fun matchSuit(n: Norm, red: Boolean): String? {
        val allowed = if (red) "hd" else "sc"
        var best: String? = null; var bs = -9f; var second = -9f
        for (t in glyphs.tpls) {
            if (t.kind != "suit" || allowed.indexOf(t.label[0]) < 0) continue
            val s = glyphs.score(n, t.norm)
            if (s > bs) { if (best != t.label) second = max(second, bs); bs = s; best = t.label }
            else if (t.label != best && s > second) second = s
        }
        if (best == null) return null
        if (second < -8f) return if (bs >= suitMin) best else null
        return if (bs >= suitMin && bs - second >= suitMargin) best else null
    }

    private fun faceUpFraction(x0: Int, y0: Int, w: Int, h: Int): Double {
        var n = 0; var t = 0
        var y = y0 + 4
        while (y < y0 + h - 4) { var x = x0 + 4; while (x < x0 + w - 4) { t++; if (isWhite(at(x, y))) n++; x += 3 }; y += 3 }
        return if (t == 0) 0.0 else n.toDouble() / t
    }

    private fun backFraction(r: Rect): Double {
        var n = 0; var t = 0
        var y = r.y0
        while (y < r.y1) { var x = r.x0; while (x < r.x1) { t++; val p = at(x, y); val rr = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            if (rr > 150 && rr - g > 60 && rr - b > 30) n++; x += 2 }; y += 2 }
        return if (t == 0) 0.0 else n.toDouble() / t
    }

    private fun limeCount(r: Rect): Int {
        var n = 0
        for (y in r.y0 until r.y1 step 2) for (x in r.x0 until r.x1 step 2) {
            val p = at(x, y); val rr = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            if (g > 200 && rr in 111..214 && b < 90) n++                 // anel verde-limão
            else if (rr > 215 && g in 100..215 && b < 80) n++            // anel laranja (tempo acabando)
        }
        return n * 4
    }

    // ---------------- números ----------------
    class Comp(val x0: Int, val y0: Int, val x1: Int, val y1: Int, val mask: BooleanArray, val w: Int, val h: Int)

    private fun components(m: BooleanArray, w: Int, h: Int): List<Comp> {
        val seen = BooleanArray(w * h)
        val out = ArrayList<Comp>()
        val stack = IntArray(w * h)
        for (start in 0 until w * h) {
            if (!m[start] || seen[start]) continue
            var sp = 0; stack[sp++] = start; seen[start] = true
            val pts = ArrayList<Int>()
            var x0 = w; var x1 = -1; var y0 = h; var y1 = -1
            while (sp > 0) {
                val i = stack[--sp]; pts.add(i)
                val x = i % w; val y = i / w
                if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx; val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val j = ny * w + nx
                    if (m[j] && !seen[j]) { seen[j] = true; stack[sp++] = j }
                }
            }
            if (pts.size < 12) continue
            val cw = x1 - x0 + 1; val ch = y1 - y0 + 1
            val cm = BooleanArray(cw * ch)
            for (i in pts) cm[(i / w - y0) * cw + (i % w - x0)] = true
            out.add(Comp(x0, y0, x1, y1, cm, cw, ch))
        }
        return out.sortedBy { it.x0 }
    }

    /** Lê um número ("10K", "270,000", "2.0M") de uma janela. [dark] = texto escuro em fundo claro. */
    fun readNumber(win: Rect, dark: Boolean, unknown: MutableList<Unknown>, where: String): Long? {
        val w = win.w; val h = win.h
        val m = BooleanArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val p = at(win.x0 + x, win.y0 + y)
            val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            m[y * w + x] = if (dark) max(r, max(g, b)) < 110 else min(r, min(g, b)) > 200
        }
        val cs = components(m, w, h)
        if (cs.isEmpty()) return null
        val maxH = cs.maxOf { it.h }
        if (maxH < 14) return null
        val sb = StringBuilder()
        var sepAt = -1
        var failed = false
        for (c in cs) {
            if (c.h < maxH * 0.55) { if (sb.isNotEmpty() && sepAt < 0) sepAt = sb.length; continue }
            val n = Glyphs.norm("num", c.mask, c.w, c.h) ?: continue
            val hit = glyphs.match("num", n, 0.58f, 0.04f)
            if (hit.label == null) { unknown.add(Unknown("num", n, where)); failed = true; sb.append('?') } else sb.append(hit.label)
        }
        if (failed) return null
        val s = sb.toString()
        if (s.isEmpty()) return null
        var mult = 1.0
        var body = s
        if (s.last() == 'K') { mult = 1000.0; body = s.dropLast(1) }
        else if (s.last() == 'M') { mult = 1_000_000.0; body = s.dropLast(1) }
        if (body.isEmpty() || body.any { !it.isDigit() }) return null
        val v: Double = if (mult > 1.0 && sepAt in 1 until body.length + 1 && sepAt <= body.length) {
            val ip = body.substring(0, sepAt); val fp = body.substring(sepAt)
            (ip + (if (fp.isNotEmpty()) ".$fp" else "")).toDouble()
        } else body.toDouble()
        return Math.round(v * mult)
    }

    private fun findPill(win: Rect): Rect? {
        var x0 = Int.MAX_VALUE; var y0 = Int.MAX_VALUE; var x1 = -1; var y1 = -1; var n = 0
        for (y in win.y0 until win.y1) for (x in win.x0 until win.x1) {
            val p = at(x, y); val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            if (r > 200 && g > 225 && b in 150..224 && g - b > 20) {
                n++; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
            }
        }
        if (n < 800 || x1 - x0 < 40 || y1 - y0 < 25) return null
        return Rect(x0, y0, x1, y1)
    }

    /** Usado pra montar os templates: símbolos (sem separadores) de um número na janela. */
    fun numberGlyphs(frame: IntArray, frameW: Int, frameH: Int, win: Rect, dark: Boolean): List<Norm?> {
        pix = frame; fw = frameW; fh = frameH; sc = frameW / 2400.0
        val w = win.w; val h = win.h
        val m = BooleanArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val p = at(win.x0 + x, win.y0 + y)
            val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            m[y * w + x] = if (dark) max(r, max(g, b)) < 110 else min(r, min(g, b)) > 200
        }
        val cs = components(m, w, h)
        val maxH = cs.maxOfOrNull { it.h } ?: 0
        return cs.filter { it.h >= maxH * 0.55 }.map { Glyphs.norm("num", it.mask, it.w, it.h) }
    }

    fun cardGlyphs(frame: IntArray, frameW: Int, frameH: Int, win: Rect): CardGlyphs {
        pix = frame; fw = frameW; fh = frameH; sc = frameW / 2400.0
        return glyphsIn(win)
    }

    fun pillOf(frame: IntArray, frameW: Int, frameH: Int, seat: String): Rect? {
        pix = frame; fw = frameW; fh = frameH; sc = frameW / 2400.0
        return findPill(PILL[seat]!!)
    }

    // ---------------- mesa inteira ----------------
    /** [frame] = pixels 0xRRGGBB da tela inteira (largura fw, altura fh). Deve estar deitada. */
    fun read(frame: IntArray, frameW: Int, frameH: Int): TableState {
        pix = frame; fw = frameW; fh = frameH; sc = frameW / 2400.0

        // minhas cartas
        val h1 = classifyCard(glyphsIn(HERO1), "minha carta 1")
        val h2 = classifyCard(glyphsIn(HERO2), "minha carta 2")
        val hero = if (heroPresent()) listOf(h1, h2) else emptyList()

        // mesa
        val board = ArrayList<CardRead>()
        for (k in 0 until 5) {
            val l = BOARD_L + k * BOARD_STEP
            if (faceUpFraction(l, BOARD_T, CW, CH) < 0.45) continue
            val win = Rect(l - 3, BOARD_T + 3, l + 45, BOARD_T + 112)
            board.add(classifyCard(glyphsIn(win), "carta ${k + 1} da mesa"))
        }

        // pote
        val potUnk = ArrayList<Unknown>()
        var pot: Long? = null
        if (darkFraction(Rect(1296, 588, 1400, 628)) > 0.45) pot = readNumber(Rect(1296, 586, 1560, 630), false, potUnk, "pote")

        // apostas
        val bets = HashMap<String, Long?>()
        val betUnk = ArrayList<Unknown>()
        for ((seat, win) in PILL) {
            val pill = findPill(win) ?: continue
            bets[seat] = readNumber(Rect(pill.x0 + 10, pill.y0 + 2, pill.x1 - 1, pill.y1 - 1), true, betUnk, "aposta ($seat)")
        }

        var opp = 0
        for (b in BACKS) if (backFraction(b) > 0.2) opp++
        val turn = limeCount(HERO_RING) > 800
        return TableState(hero, board, pot, potUnk, bets, betUnk, opp, turn)
    }

    private fun heroPresent(): Boolean {
        // carta 2 da mão tem mais branco que o tapete
        return faceUpFraction(1440, 730, 100, 100) > 0.3
    }

    private fun darkFraction(r: Rect): Double {
        var n = 0; var t = 0
        for (y in r.y0 until r.y1 step 3) for (x in r.x0 + 20 until r.x1 step 3) {
            t++; val p = at(x, y)
            if (((p shr 16) and 255) < 40 && ((p shr 8) and 255) < 40 && (p and 255) < 40) n++
        }
        return if (t == 0) 0.0 else n.toDouble() / t
    }
}
