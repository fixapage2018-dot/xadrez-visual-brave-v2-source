package com.pokerdica.core

import android.graphics.Rect

class TableReader(val cfg: Cfg, val glyphs: Glyphs) {

    val HERO1 = Rect(1324, 716, 1415, 851)
    val HERO2 = Rect(1423, 706, 1530, 851)

    val HERO_RING = Rect(1194, 696, 1264, 766)

    val SEATS = listOf(
        Seat(0, "Hero",   1200, 750, Rect(1220, 670, 1340, 700), true),
        Seat(1, "Omaha",   650, 680, Rect( 630, 610,  750, 640), false),
        Seat(2, "128",     830, 160, Rect( 840, 200,  960, 230), false),
        Seat(3, "19",     1650, 160, Rect(1520, 200, 1640, 230), false),
        Seat(4, "01",     1830, 680, Rect(1730, 610, 1850, 640), false)
    )

    val BOARD_L = 1030
    val BOARD_STEP = 123
    val BOARD_T = 413
    val BOARD_W = 103
    val BOARD_H = 145

    val POT_RECT = Rect(1295, 585, 1560, 632)

    data class Seat(val id: Int, val name: String, val cx: Int, val cy: Int, val pill: Rect, val isHero: Boolean)

    data class State(
        val hero: List<Card>,
        val board: List<Card>,
        val pot: Long?,
        val toCall: Long,
        val opponents: Int,
        val heroTurn: Boolean,
        val heroBet: Long,
        val unknown: Unknown?
    )

    fun read(screen: IntArray, sw: Int, sh: Int): State {
        val heroCards = mutableListOf<Card>()
        val unkList = mutableListOf<Unknown>()

        val h1 = readCard(screen, sw, sh, HERO1, "hero1")
        val h2 = readCard(screen, sw, sh, HERO2, "hero2")

        if (h1 != null) {
            if (h1.card != null) heroCards.add(h1.card)
            if (h1.unknown != null) unkList.add(h1.unknown)
        }
        if (h2 != null) {
            if (h2.card != null) heroCards.add(h2.card)
            if (h2.unknown != null) unkList.add(h2.unknown)
        }

        val boardCards = mutableListOf<Card>()
        for (i in 0 until 5) {
            val l = BOARD_L + i * BOARD_STEP
            val win = Rect(l - 3, 416, l + 66, 525)
            val res = readCard(screen, sw, sh, win, "board$i")
            if (res != null) {
                if (res.card != null) boardCards.add(res.card)
                if (res.unknown != null) unkList.add(res.unknown)
            }
        }

        var oppCount = 0
        for (s in SEATS) {
            if (!s.isHero) {
                if (isBackPresent(screen, sw, sh, s.cx, s.cy)) {
                    oppCount++
                }
            }
        }

        val pot = readNumber(screen, sw, sh, POT_RECT)
        val heroBet = readNumber(screen, sw, sh, SEATS[0].pill) ?: 0L

        var maxBet = heroBet
        for (i in 1 until SEATS.size) {
            val b = readNumber(screen, sw, sh, SEATS[i].pill)
            if (b != null && b > maxBet) {
                maxBet = b
            }
        }

        val toCall = (maxBet - heroBet).coerceAtLeast(0L)
        val heroTurn = checkHeroTurn(screen, sw, sh)

        return State(
            hero = heroCards,
            board = boardCards,
            pot = pot,
            toCall = toCall,
            opponents = if (oppCount > 0) oppCount else 1,
            heroTurn = heroTurn,
            heroBet = heroBet,
            unknown = unkList.firstOrNull()
        )
    }

    data class CardRead(val card: Card?, val unknown: Unknown?)

    fun readCard(screen: IntArray, sw: Int, sh: Int, win: Rect, label: String): CardRead? {
        val l = win.left.coerceIn(0, sw - 1)
        val r = win.right.coerceIn(0, sw)
        val t = win.top.coerceIn(0, sh - 1)
        val b = win.bottom.coerceIn(0, sh)
        if (l >= r || t >= b) return null

        var whiteCount = 0
        val total = (r - l) * (b - t)
        for (y in t until b) {
            for (x in l until r) {
                val c = screen[y * sw + x]
                val red = (c shr 16) and 0xFF
                val green = (c shr 8) and 0xFF
                val blue = c and 0xFF
                if (red > 200 && green > 200 && blue > 200) whiteCount++
            }
        }
        if (whiteCount.toFloat() / total < 0.15f) return null

        val comps = glyphsIn(screen, sw, sh, win)
        if (comps.isEmpty()) return null

        val rankComp = comps.firstOrNull { it.h >= (comps.maxOf { c -> c.h } * 0.55f) } ?: return null
        val suitComp = comps.firstOrNull { it != rankComp && it.y0 > rankComp.y0 && it.x0 <= (rankComp.x0 + 30) }

        val rankNorm = normGlyph(screen, sw, sh, rankComp, 16, 24)
        val rankMatch = glyphs.match("rank", rankNorm)

        if (rankMatch == null) {
            return CardRead(null, Unknown("rank", rankNorm, label))
        }

        if (suitComp == null) return null

        val suitNorm = normGlyph(screen, sw, sh, suitComp, 20, 20)
        val isRed = suitComp.isRed
        val suitMatch = glyphs.matchSuit(suitNorm, isRed)

        if (suitMatch == null) {
            return CardRead(null, Unknown("suit", suitNorm, label))
        }

        val rLabel = rankMatch.label ?: return null
        val sLabel = suitMatch.label ?: return null
        val card = Card.from((rLabel + sLabel) ?: return null) ?: return null
        return CardRead(card, null)
    }

    data class Comp(val x0: Int, val y0: Int, val x1: Int, val y1: Int, val isRed: Boolean) {
        val w get() = x1 - x0 + 1
        val h get() = y1 - y0 + 1
    }

    fun glyphsIn(screen: IntArray, sw: Int, sh: Int, r: Rect): List<Comp> {
        val visited = BooleanArray((r.width()) * (r.height()))
        val comps = mutableListOf<Comp>()

        val rw = r.width()
        val rh = r.height()

        for (y in 0 until rh) {
            for (x in 0 until rw) {
                val idx = y * rw + x
                if (visited[idx]) continue
                visited[idx] = true

                val sx = r.left + x
                val sy = r.top + y
                if (sx >= sw || sy >= sh) continue
                val c = screen[sy * sw + sx]

                val red = (c shr 16) and 0xFF
                val green = (c shr 8) and 0xFF
                val blue = c and 0xFF

                val isBlack = red < 110 && green < 110 && blue < 110
                val isRedColor = red > 130 && green < 80 && blue < 80

                if (!isBlack && !isRedColor) continue

                var minX = sx
                var maxX = sx
                var minY = sy
                var maxY = sy

                val queueX = IntArray(rw * rh)
                val queueY = IntArray(rw * rh)
                var head = 0
                var tail = 0

                queueX[tail] = sx
                queueY[tail] = sy
                tail++

                while (head < tail) {
                    val cx = queueX[head]
                    val cy = queueY[head]
                    head++

                    val neighbors = arrayOf(
                        Pair(cx - 1, cy), Pair(cx + 1, cy),
                        Pair(cx, cy - 1), Pair(cx, cy + 1)
                    )

                    for (np in neighbors) {
                        val nx = np.first
                        val ny = np.second
                        if (nx < r.left || nx >= r.right || ny < r.top || ny >= r.bottom) continue
                        val nIdx = (ny - r.top) * rw + (nx - r.left)
                        if (visited[nIdx]) continue

                        val nc = screen[ny * sw + nx]
                        val nr = (nc shr 16) and 0xFF
                        val ng = (nc shr 8) and 0xFF
                        val nb = nc and 0xFF

                        val match = if (isRedColor) {
                            nr > 130 && ng < 80 && nb < 80
                        } else {
                            nr < 110 && ng < 110 && nb < 110
                        }

                        if (match) {
                            visited[nIdx] = true
                            minX = minOf(minX, nx)
                            maxX = maxOf(maxX, nx)
                            minY = minOf(minY, ny)
                            maxY = maxOf(maxY, ny)
                            if (tail < queueX.size) {
                                queueX[tail] = nx
                                queueY[tail] = ny
                                tail++
                            }
                        }
                    }
                }

                if ((maxX - minX + 1) >= 4 && (maxY - minY + 1) >= 6) {
                    comps.add(Comp(minX, minY, maxX, maxY, isRedColor))
                }
            }
        }
        return comps.sortedBy { it.y0 }
    }

    fun normGlyph(screen: IntArray, sw: Int, sh: Int, comp: Comp, outW: Int, outH: Int): Glyphs.Norm {
        val bits = BooleanArray(outW * outH)
        for (oy in 0 until outH) {
            val srcY = comp.y0 + (oy * comp.h) / outH
            for (ox in 0 until outW) {
                val srcX = comp.x0 + (ox * comp.w) / outW
                val c = screen[srcY * sw + srcX]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val ink = if (comp.isRed) (r > 130 && g < 80 && b < 80) else (r < 110 && g < 110 && b < 110)
                bits[oy * outW + ox] = ink
            }
        }
        val aspect = comp.w.toFloat() / comp.h.toFloat()
        return Glyphs.Norm(outW, outH, aspect, bits)
    }

    fun isBackPresent(screen: IntArray, sw: Int, sh: Int, cx: Int, cy: Int): Boolean {
        var red = 0
        var total = 0
        for (dy in -15..15) {
            for (dx in -15..15) {
                val x = cx + dx
                val y = cy + dy
                if (x in 0 until sw && y in 0 until sh) {
                    val c = screen[y * sw + x]
                    val r = (c shr 16) and 0xFF
                    val g = (c shr 8) and 0xFF
                    val b = c and 0xFF
                    if (r > 150 && g < 70 && b < 70) red++
                    total++
                }
            }
        }
        return total > 0 && (red.toFloat() / total) > 0.35f
    }

    fun checkHeroTurn(screen: IntArray, sw: Int, sh: Int): Boolean {
        var greenOrange = 0
        var total = 0
        val r = HERO_RING
        for (y in r.top..r.bottom) {
            for (x in r.left..r.right) {
                if (x in 0 until sw && y in 0 until sh) {
                    val c = screen[y * sw + x]
                    val red = (c shr 16) and 0xFF
                    val green = (c shr 8) and 0xFF
                    val blue = c and 0xFF
                    if (green > 160 && blue < 80) greenOrange++
                    if (red > 180 && green in 80..160 && blue < 50) greenOrange++
                    total++
                }
            }
        }
        return total > 0 && (greenOrange.toFloat() / total) > 0.08f
    }

    fun readNumber(screen: IntArray, sw: Int, sh: Int, r: Rect): Long? {
        val comps = glyphsIn(screen, sw, sh, r).sortedBy { it.x0 }
        if (comps.isEmpty()) return null
        val sb = StringBuilder()
        var mult = 1L
        for (c in comps) {
            val norm = normGlyph(screen, sw, sh, c, 16, 24)
            val m = glyphs.match("num", norm)
            if (m != null) {
                val ch = m.label
                if (ch in "0".."9") sb.append(ch)
                else if (ch == "K" || ch == "k") mult = 1_000L
                else if (ch == "M" || ch == "m") mult = 1_000_000L
            }
        }
        val s = sb.toString()
        if (s.isEmpty()) return null
        return (s.toLongOrNull() ?: return null) * mult
    }
}
