Alargue as janelas de leitura do rank. Altere as constantes:
```kotlin
        val HERO1 = Rect(1320, 716, 1408, 851)
        val HERO2 = Rect(1415, 706, 1492, 851)
```
e, ao criar a janela das cartas comunitárias, altere:
```kotlin
            val win = Rect(l - 3, BOARD_T + 3, l + 45, BOARD_T + 112)
```
para:
```kotlin
            val win = Rect(l - 3, BOARD_T + 3, l + 70, BOARD_T + 112)
```