package com.pokerdica.core

import java.util.Locale
import java.util.ArrayList

class Advice(val action: String, val strength: String, val lines: List<String>)

object Advisor {
    fun money(v: Long): String {
        return when {
            v >= 10000000L -> String.format(Locale.US, "%.1fM", v / 1000000.0)
            v >= 1000000L -> String.format(Locale.US, "%.2fM", v / 1000000.0)
            v >= 10000L -> String.format(Locale.US, "%.1fK", v / 1000.0).replace(".0K", "K")
            else -> v.toString()
        }
    }

    fun advise(eq: Double, opponents: Int, pot: Long?, toCall: Long?): Advice {
        val safePot = if (pot != null && pot > 0L) pot else 1000L
        val callAmount = if (toCall != null) toCall else 0L
        val potOdds = if (callAmount > 0L) callAmount.toDouble() / (safePot + callAmount).toDouble() else 0.0
        val sorteioBlefe = (1..100).random()
        val eqPct = String.format(Locale.US, "%.1f%%", eq * 100.0)

        // Trava de Sobrevivência: Aposta é muito alta pro tamanho do pote? (Caracteriza All-in ou agressão pesada)
        val overbet = callAmount >= (safePot * 0.8) 

        val action: String
        val desc: String

        if (overbet && eq < 0.65) {
            action = "FOLD"
            desc = "Fuga de All-in ($eqPct)"
        } else if (eq >= 0.68) {
            action = if (callAmount == 0L) "RAISE" else "CALL / ALL-IN"
            desc = "Monstro ($eqPct)"
        } else if (eq in 0.50..0.67) {
            if (callAmount == 0L) {
                action = "RAISE"
                desc = "Agressao ($eqPct)"
            } else if (!overbet && eq >= potOdds) {
                action = "CALL"
                desc = "Pago Seguro ($eqPct)"
            } else {
                action = "FOLD"
                desc = "Muito caro ($eqPct)"
            }
        } else if (callAmount == 0L && sorteioBlefe <= 15) {
            action = "RAISE (BLEFE)"
            desc = "Roubo ($eqPct)"
        } else if (callAmount == 0L) {
            action = "CHECK"
            desc = "Passivo ($eqPct)"
        } else if (callAmount > 0L && callAmount < (safePot / 4) && eq >= potOdds) {
            action = "CALL"
            desc = "Ta barato ($eqPct)"
        } else {
            action = "FOLD"
            desc = "Lixo ($eqPct)"
        }

        val infoLines = ArrayList<String>()
        infoLines.add("Chance: " + eqPct + " (" + opponents.toString() + " viloes)")
        if (callAmount > 0L) {
            infoLines.add("Pagar: " + money(callAmount) + " / Pote: " + money(safePot))
        } else {
            infoLines.add("Pote: " + money(safePot) + " | " + desc)
        }

        return Advice(action, desc, infoLines)
    }
}
