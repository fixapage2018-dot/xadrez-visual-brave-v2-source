package com.pokerdica.core

import java.util.Locale

class Advice(val action: String, val strength: String, val lines: List<String>)

object Advisor {
    fun money(v: Long): String = when {
        v >= 10_000_000 -> String.format(Locale.US, "%.1fM", v / 1_000_000.0)
        v >= 1_000_000 -> String.format(Locale.US, "%.2fM", v / 1_000_000.0)
        v >= 10_000 -> String.format(Locale.US, "%.1fK", v / 1000.0).replace(".0K", "K")
        else -> v.toString()
    }

    fun advise(eq: Double, opponents: Int, pot: Long?, toCall: Long?): Advice {
        val safePot = if (pot != null && pot > 0L) pot else 1000L
        val callAmount = toCall ?: 0L
        val potOdds = if (callAmount > 0L) callAmount.toDouble() / (safePot + callAmount).toDouble() else 0.0
        val sorteioBlefe = (1..100).random()
        val eqPct = String.format(Locale.US, "%.1f%%", eq * 100.0)

        val (action, desc) = when {
            eq >= 0.58 -> Pair("RAISE", "Forte ($eqPct)")
            eq in 0.44..0.57 -> {
                if (callAmount == 0L) Pair("RAISE", "Agressão ($eqPct)") else Pair("CALL", "Pago ($eqPct)")
            }
            callAmount == 0L && sorteioBlefe <= 22 -> Pair("RAISE (BLEFE)", "Roubo ($eqPct)")
            callAmount == 0L -> Pair("CHECK", "Passivo ($eqPct)")
            eq >= (potOdds * 0.88) -> Pair("CALL", "Pot Odds ($eqPct)")
            callAmount > 0L && callAmount < (safePot / 5) && sorteioBlefe <= 6 -> Pair("RAISE (BLEFE)", "Pressão ($eqPct)")
            else -> Pair("FOLD", "Fraca ($eqPct)")
        }

        val infoLines = mutableListOf<String>()
        infoLines.add("Chance: $eqPct ($opponents vilões)")
        if (callAmount > 0L) {
            infoLines.add("Pagar: ${money(callAmount)} / Pote: ${money(safePot)}")
        } else {
            infoLines.add("Pote: ${money(safePot)} | $desc")
        }

        return Advice(action, desc, infoLines)
    }
}
