package com.pokerdica.core

import java.util.Locale

class Advice(val action: String, val strength: String, val lines: List<String>)

object Advisor {
    fun money(v: Long): String = when {
        v >= 10_000_000 -> String.format(Locale.US, "%.1fM", v / 1_000_000.0)
        v >= 1_000_000 -> String.format(Locale.US, "%.2fM", v / 1_000_000.0)
        v >= 10_000 -> String.format(Locale.US, "%.1fK", v / 1000.0).replace(".0K", "K")
        else -> v.toString()
    }

    /**
     * eq = chance de ganhar (0..1) contra [opps] adversários; pot = pote total na mesa (com apostas da rodada);
     * toCall = quanto falta pra eu pagar (0 = posso dar check).
     */
    fun advise(eq: Double, opps: Int, pot: Long?, toCall: Long?): Advice {
        val fair = 1.0 / (opps + 1)
        val strength = when {
            eq >= fair + 0.25 -> "FORTE"
            eq >= fair + 0.08 -> "BOA"
            eq >= fair - 0.05 -> "MÉDIA"
            else -> "FRACA"
        }
        val raiseTh = fair + 0.25
        val lines = ArrayList<String>()
        lines.add(String.format(Locale.US, "Chance de ganhar: %.0f%%  (mão %s, %d adv.)", eq * 100, strength, opps))
        val needed: Double? = if (toCall != null && toCall > 0 && pot != null && pot > 0) toCall.toDouble() / (pot + toCall) else null
        if (pot != null && pot > 0) lines.add("Pote: ${money(pot)}" + (if (toCall != null && toCall > 0) "   Pagar: ${money(toCall)}" else ""))
        else if (toCall != null && toCall > 0) lines.add("Pagar: ${money(toCall)}")
        val action: String
        if (eq >= raiseTh) {
            action = "AUMENTAR (raise)"
        } else if (toCall == null || toCall <= 0) {
            action = "PASSAR (check)"
        } else if (needed != null) {
            lines.add(String.format(Locale.US, "Precisa de %.0f%% pra valer pagar", needed * 100))
            action = if (eq >= needed * 1.05) "PAGAR (call)" else "CORRER (fold)"
        } else {
            action = if (eq >= fair) "PAGAR (call)" else "CORRER (fold)"
        }
        return Advice(action, strength, lines)
    }
}
