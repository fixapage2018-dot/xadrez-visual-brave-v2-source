package com.pokerdica.core

import java.util.Locale
import java.util.ArrayList

class Advice(val action: String, val strength: String, val lines: List<String>)

object Advisor {
    fun money(v: Long): String {
        return when {
            v >= 10000000L -> String.format(Locale.US, "%.1fM", v / 1000000.0)
            v >= 1000000L -> String.format(Locale.US, "%.2fM", v / 1000000.0)
            v >= 10000L -> String.format(Locale.US, "%.1fK", v / 1000.0).replace(".0K", "K")
            else -> v.toString()
        }
    }

    fun advise(eq: Double, opponents: Int, pot: Long?, toCall: Long?): Advice {
        val safePot = if (pot != null && pot > 0L) pot else 1000L
        val callAmount = if (toCall != null) toCall else 0L
        val potOdds = if (callAmount > 0L) callAmount.toDouble() / (safePot + callAmount).toDouble() else 0.0
        val sorteioBlefe = (1..100).random()
        val eqPct = String.format(Locale.US, "%.1f%%", eq * 100.0)

        val action: String
        val desc: String

        if (eq >= 0.58) {
            action = "RAISE"
            desc = "Forte ($eqPct)"
        } else if (eq in 0.44..0.57) {
            if (callAmount == 0L) {
                action = "RAISE"
                desc = "Agressao ($eqPct)"
            } else {
                action = "CALL"
                desc = "Pago ($eqPct)"
            }
        } else if (callAmount == 0L && sorteioBlefe <= 22) {
            action = "RAISE (BLEFE)"
            desc = "Roubo ($eqPct)"
        } else if (callAmount == 0L) {
            action = "CHECK"
            desc = "Passivo ($eqPct)"
        } else if (eq >= (potOdds * 0.88)) {
            action = "CALL"
            desc = "Pot Odds ($eqPct)"
        } else if (callAmount > 0L && callAmount < (safePot / 5) && sorteioBlefe <= 6) {
            action = "RAISE (BLEFE)"
            desc = "Pressao ($eqPct)"
        } else {
            action = "FOLD"
            desc = "Fraca ($eqPct)"
        }

        val infoLines = ArrayList<String>()
        infoLines.add("Chance: " + eqPct + " (" + opponents.toString() + " viloes)")
        if (callAmount > 0L) {
            infoLines.add("Pagar: " + money(callAmount) + " / Pote: " + money(safePot))
        } else {
            infoLines.add("Pote: " + money(safePot) + " | " + desc)
        }

        return Advice(action, desc, infoLines)
    }
}
