package com.pokerdica.core

import java.util.Locale

class Advice(val action: String, val strength: String, val lines: List<String>)

object Advisor {
    fun money(v: Long): String = when {
        v >= 10_000_000 -> String.format(Locale.US, "%.1fM", v / 1_000_000.0)
        v >= 1_000_000 -> String.format(Locale.US, "%.2fM", v / 1_000_000.0)
        v >= 10_000 -> String.format(Locale.US, "%.1fK", v / 1000.0).replace(".0K", "K")
        else -> v.toString()
    }

    /**
     * eq = chance de ganhar (0..1) contra [opps] adversários; pot = pote total na mesa (com apostas da rodada);
     * toCall = quanto falta pra eu pagar (0 = posso dar check).
     */
    fun advise(equity: Float, toCall: Long, pot: Long?): String {
        val safePot = if (pot != null && pot > 0L) pot else 1000L
        val potOdds = if (toCall > 0L) toCall.toFloat() / (safePot + toCall).toFloat() else 0.0f
        val sorteioBlefe = (1..100).random()

        return when {
            // Mão monstro: Aumenta sem dó
            equity >= 0.62f -> "RAISE"

            // Mão boa: Aumenta na maioria das vezes
            equity in 0.48f..0.61f -> {
                if (toCall == 0L) "RAISE" else "CALL"
            }

            // Posição de Blefe / Roubo de pote:
            // Ninguém apostou (toCall == 0), mão fraca/média, mas 25% de chance de blefar agressivo
            toCall == 0L && sorteioBlefe <= 25 -> "RAISE (BLEFE)"

            // Check padrão quando ninguém apostou
            toCall == 0L -> "CHECK"

            // Situação com aposta na mesa:
            // Paga se o preço compensar ou se for semi-blefe com draw razoável
            equity >= (potOdds * 0.90f) -> "CALL"

            // Blefe surpresa pagando/aumentando aposta baixa (5% de chance de re-blefe)
            toCall > 0L && toCall < (safePot / 4) && sorteioBlefe <= 5 -> "RAISE (BLEFE)"

            else -> "FOLD"
        }
    }
}
