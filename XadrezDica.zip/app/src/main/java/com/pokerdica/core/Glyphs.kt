package com.pokerdica.core

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** Máscara normalizada de um símbolo (rank, naipe ou dígito) + proporção largura/altura. */
class Norm(val w: Int, val h: Int, val m: BooleanArray, val aspect: Float) {
    /** Buracos do símbolo (ex.: 8 tem 2, 6/9/0/4 têm 1, 3/5/7/2 nenhum). */
    val holes: Int = countHoles()

    private fun countHoles(): Int {
        val seen = BooleanArray(w * h)
        val st = IntArray(w * h)
        fun fill(start: Int) {
            var sp = 0; st[sp++] = start; seen[start] = true
            while (sp > 0) {
                val i = st[--sp]; val x = i % w; val y = i / w
                if (x > 0 && !m[i - 1] && !seen[i - 1]) { seen[i - 1] = true; st[sp++] = i - 1 }
                if (x < w - 1 && !m[i + 1] && !seen[i + 1]) { seen[i + 1] = true; st[sp++] = i + 1 }
                if (y > 0 && !m[i - w] && !seen[i - w]) { seen[i - w] = true; st[sp++] = i - w }
                if (y < h - 1 && !m[i + w] && !seen[i + w]) { seen[i + w] = true; st[sp++] = i + w }
            }
        }
        for (x in 0 until w) { if (!m[x] && !seen[x]) fill(x); val b = (h - 1) * w + x; if (!m[b] && !seen[b]) fill(b) }
        for (y in 0 until h) { val l = y * w; if (!m[l] && !seen[l]) fill(l); val r = y * w + w - 1; if (!m[r] && !seen[r]) fill(r) }
        var n = 0
        for (i in 0 until w * h) if (!m[i] && !seen[i]) {
            var cnt = 0; var sp = 0; st[sp++] = i; seen[i] = true
            while (sp > 0) {
                val j = st[--sp]; cnt++; val x = j % w; val y = j / w
                if (x > 0 && !m[j - 1] && !seen[j - 1]) { seen[j - 1] = true; st[sp++] = j - 1 }
                if (x < w - 1 && !m[j + 1] && !seen[j + 1]) { seen[j + 1] = true; st[sp++] = j + 1 }
                if (y > 0 && !m[j - w] && !seen[j - w]) { seen[j - w] = true; st[sp++] = j - w }
                if (y < h - 1 && !m[j + w] && !seen[j + w]) { seen[j + w] = true; st[sp++] = j + w }
            }
            if (cnt >= 3) n++
        }
        return n
    }

    fun toHex(): String {
        val sb = StringBuilder()
        var i = 0
        while (i < m.size) {
            var v = 0
            for (k in 0 until 4) { v = v shl 1; if (i + k < m.size && m[i + k]) v = v or 1 }
            sb.append("0123456789abcdef"[v]); i += 4
        }
        return sb.toString()
    }
}

class Tpl(val kind: String, val label: String, val norm: Norm)

class Hit(val label: String?, val score: Float, val margin: Float, val best: String?)

/** Banco de símbolos conhecidos. kind: "rank", "suit", "num". */
class Glyphs {
    val tpls = ArrayList<Tpl>()

    companion object {
        fun sizeOf(kind: String) = if (kind == "suit") intArrayOf(20, 20) else intArrayOf(16, 24)

        /** Recorta a caixa da máscara e reamostra pro tamanho fixo do tipo. */
        fun norm(kind: String, src: BooleanArray, w: Int, h: Int): Norm? {
            var x0 = w; var x1 = -1; var y0 = h; var y1 = -1
            for (y in 0 until h) for (x in 0 until w) if (src[y * w + x]) {
                if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
            }
            if (x1 < 0) return null
            val bw = x1 - x0 + 1; val bh = y1 - y0 + 1
            if (bw < 2 || bh < 4) return null
            val (tw, th) = sizeOf(kind).let { it[0] to it[1] }
            val out = BooleanArray(tw * th)
            for (ty in 0 until th) {
                val ya = y0 + ty * bh / th; val yb = max(ya + 1, y0 + (ty + 1) * bh / th)
                for (tx in 0 until tw) {
                    val xa = x0 + tx * bw / tw; val xb = max(xa + 1, x0 + (tx + 1) * bw / tw)
                    var on = 0; var tot = 0
                    for (y in ya until min(yb, y1 + 1)) for (x in xa until min(xb, x1 + 1)) { tot++; if (src[y * w + x]) on++ }
                    out[ty * tw + tx] = tot > 0 && on * 2 > tot
                }
            }
            return Norm(tw, th, out, bw.toFloat() / bh)
        }

        fun fromHex(kind: String, aspect: Float, hex: String): Norm {
            val (tw, th) = sizeOf(kind).let { it[0] to it[1] }
            val m = BooleanArray(tw * th)
            for (i in hex.indices) {
                val v = Character.digit(hex[i], 16)
                for (k in 0 until 4) { val idx = i * 4 + k; if (idx < m.size) m[idx] = (v shr (3 - k)) and 1 == 1 }
            }
            return Norm(tw, th, m, aspect)
        }
    }

    fun add(kind: String, label: String, n: Norm) { tpls.add(Tpl(kind, label, n)) }

    fun has(kind: String, label: String) = tpls.any { it.kind == kind && it.label == label }

    fun score(a: Norm, b: Norm): Float {
        var inter = 0; var uni = 0
        for (i in a.m.indices) {
            val x = a.m[i]; val y = b.m[i]
            if (x && y) inter++
            if (x || y) uni++
        }
        val iou = if (uni == 0) 0f else inter.toFloat() / uni
        val pen = abs(ln(a.aspect / b.aspect)) * 0.5f
        val holePen = if (a.w == 20) 0f else abs(a.holes - b.holes) * 0.25f
        return iou - pen - holePen
    }

    /** Melhor símbolo conhecido (só entre os de [kind]). label = null se não bateu bem o bastante. */
    var minScore = 0.6f
    var minMargin = 0.1f

    fun match(kind: String, n: Norm, minScore: Float = this.minScore, minMargin: Float = this.minMargin): Hit {
        var best: Tpl? = null; var bs = -9f
        val perLabel = HashMap<String, Float>()
        for (t in tpls) {
            if (t.kind != kind) continue
            val s = score(n, t.norm)
            val old = perLabel[t.label]
            if (old == null || s > old) perLabel[t.label] = s
            if (s > bs) { bs = s; best = t }
        }
        if (best == null) return Hit(null, 0f, 0f, null)
        var second = -9f
        for ((l, s) in perLabel) if (l != best.label && s > second) second = s
        val margin = if (second < -8f) 1f else bs - second
        val ok = bs >= minScore && margin >= minMargin
        return Hit(if (ok) best.label else null, bs, margin, best.label)
    }

    fun serialize(): String {
        val sb = StringBuilder()
        for (t in tpls) sb.append(t.kind).append(' ').append(t.label).append(' ')
            .append(String.format(java.util.Locale.US, "%.3f", t.norm.aspect)).append(' ').append(t.norm.toHex()).append('\n')
        return sb.toString()
    }

    fun load(text: String) {
        for (line in text.lines()) {
            val p = line.trim().split(' ')
            if (p.size != 4) continue
            try { add(p[0], p[1], fromHex(p[0], p[2].toFloat(), p[3])) } catch (e: Exception) { }
        }
    }
}
