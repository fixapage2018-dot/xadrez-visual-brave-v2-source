package com.pokerdica

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import com.pokerdica.core.Glyphs
import com.pokerdica.core.PokerSession
import com.pokerdica.core.Unknown

class CaptureService : Service() {
    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "pd"
        private const val TICK_MS = 250L
    }

    private var projection: MediaProjection? = null
    private var vdisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var statusView: StatusView? = null
    private var statusLp: WindowManager.LayoutParams? = null
    private var teachView: android.view.View? = null
    private var teachFor: Unknown? = null
    private lateinit var wm: WindowManager

    private var thread: HandlerThread? = null
    private var worker: Handler? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false

    private lateinit var glyphs: Glyphs
    private var seedCount = 0
    private lateinit var session: PokerSession

    private var capW = 0
    private var capH = 0
    private var dpi = 320
    private var full = IntArray(0)
    private var rowBuf = ByteArray(0)
    private var haveFrame = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        if (data == null || code == 0) { stopSelf(); return START_NOT_STICKY }
        startForegroundCompat()
        try {
            begin(code, data)
        } catch (e: Exception) {
            e.printStackTrace()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Poker Dica", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getService(
            this, 2, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Poker Dica rodando")
            .setContentText("Lendo a mesa e dando dicas")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Parar", pi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun loadGlyphs() {
        glyphs = Glyphs()
        try {
            assets.open("glyphs.txt").bufferedReader().use { glyphs.load(it.readText()) }
        } catch (e: Exception) { e.printStackTrace() }
        seedCount = glyphs.tpls.size
        try {
            val learned = getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("learned", null)
            if (learned != null) glyphs.load(learned)
        } catch (e: Exception) { }
    }

    private fun saveLearned() {
        val tmp = Glyphs()
        for (t in glyphs.tpls.drop(seedCount)) tmp.tpls.add(t)
        try { getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString("learned", tmp.serialize()).apply() } catch (e: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun realSize(): IntArray {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    private fun begin(code: Int, data: Intent) {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        loadGlyphs()
        session = PokerSession(glyphs) { saveLearned() }

        val rs = realSize()
        capW = rs[0]; capH = rs[1]; dpi = rs[2]

        // caixinha de status arrastável; começa no canto inferior esquerdo (fora da área que o app lê)
        val slp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        slp.gravity = Gravity.TOP or Gravity.START
        val sp = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        slp.x = sp.getInt("sx", 10)
        slp.y = sp.getInt("sy", 0)
        statusLp = slp
        val sv = StatusView(this, wm, slp) { keepOffTable() }
        sv.setText("Poker Dica: aguardando a mesa...")
        wm.addView(sv, slp)
        statusView = sv
        main.post { placeDefault() }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)
        val rd = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        reader = rd
        vdisplay = proj.createVirtualDisplay(
            "pd", capW, capH, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            rd.surface, null, null
        )

        running = true
        val t = HandlerThread("pd-capture")
        t.start()
        thread = t
        val w = Handler(t.looper)
        worker = w
        w.post(object : Runnable {
            override fun run() {
                if (!running) return
                try { tick() } catch (e: Exception) { e.printStackTrace() }
                if (running) w.postDelayed(this, TICK_MS)
            }
        })
    }

    /** Posição inicial: canto inferior esquerdo, onde o jogo só mostra o chat do dealer. */
    private fun placeDefault() {
        val sp = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (sp.contains("sx")) { keepOffTable(); return }
        val lp = statusLp ?: return
        lp.x = 10
        lp.y = (capH * 0.80f).toInt()
        try { statusView?.let { wm.updateViewLayout(it, lp) } } catch (e: Exception) { }
    }

    /** A captura enxerga tudo que está por cima: a caixinha não pode ficar em cima da mesa (leitura). */
    private fun keepOffTable() {
        val sv = statusView ?: return
        val lp = statusLp ?: return
        val w = if (sv.width > 0) sv.width else 600
        val h = if (sv.height > 0) sv.height else 200
        val sx = capW / 2400f; val sy = capH / 1080f
        val tl = 470 * sx; val tt = 0f; val tr = 2330 * sx; val tb = 980 * sy
        if (lp.x + w > tl && lp.x < tr && lp.y + h > tt && lp.y < tb) {
            lp.x = 10
            lp.y = (capH * 0.80f).toInt().coerceAtMost(capH - h)
            try { wm.updateViewLayout(sv, lp) } catch (e: Exception) { }
        }
    }

    /** Se a tela girou (retrato <-> paisagem), recria a captura no tamanho novo. */
    private fun ensureSize() {
        val rs = realSize()
        if (rs[0] == capW && rs[1] == capH) return
        capW = rs[0]; capH = rs[1]; dpi = rs[2]
        val old = reader
        val rd = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        try {
            vdisplay?.resize(capW, capH, dpi)
            vdisplay?.setSurface(rd.surface)
        } catch (e: Exception) { e.printStackTrace() }
        reader = rd
        try { old?.close() } catch (e: Exception) { }
        haveFrame = false
    }

    private fun grab(): Boolean {
        ensureSize()
        val img = reader?.acquireLatestImage()
        if (img != null) {
            try {
                val plane = img.planes[0]
                val buf = plane.buffer
                val rs = plane.rowStride
                val w = minOf(img.width, rs / 4)
                val h = img.height
                if (full.size != w * h) { full = IntArray(w * h); rowBuf = ByteArray(w * 4) }
                for (y in 0 until h) {
                    buf.position(y * rs)
                    buf.get(rowBuf, 0, w * 4)
                    var o = y * w
                    var i = 0
                    while (i < w * 4) {
                        full[o++] = ((rowBuf[i].toInt() and 255) shl 16) or
                            ((rowBuf[i + 1].toInt() and 255) shl 8) or (rowBuf[i + 2].toInt() and 255)
                        i += 4
                    }
                }
                frameW = w; frameH = h
                scaledDirty = true
                haveFrame = true
            } finally {
                img.close()
            }
        }
        return haveFrame
    }

    private var frameW = 0
    private var frameH = 0
    private var scaled = IntArray(0)
    private var scaledDirty = true

    /** O leitor foi medido em 2400x1080: se o celular tiver outro tamanho de tela deitada, reescala. */
    private fun frameForReader(): IntArray {
        if (frameW <= frameH || (frameW == 2400 && frameH == 1080)) return full
        if (scaled.size != 2400 * 1080) scaled = IntArray(2400 * 1080)
        if (scaledDirty) {
            for (y in 0 until 1080) {
                val sy = y * frameH / 1080
                for (x in 0 until 2400) scaled[y * 2400 + x] = full[sy * frameW + x * frameW / 2400]
            }
            scaledDirty = false
        }
        return scaled
    }

    private fun looksBlack(): Boolean {
        if (frameW == 0) return false
        var nz = 0
        for (k in 0 until 400) {
            val x = (k * 37) % frameW; val y = (k * 53) % frameH
            if (full[y * frameW + x] and 0xFFFFFF != 0) nz++
        }
        return nz == 0
    }

    private fun say(s: String) { main.post { statusView?.setText(s); keepOffTable() } }

    private fun tick() {
        if (!grab()) { say("Poker Dica: aguardando a captura de tela..."); return }
        if (looksBlack()) { say("Tela preta: o jogo bloqueou a captura (FLAG_SECURE).\nUse a versão de teste do jogo, sem o bloqueio."); return }
        val fr = frameForReader()
        val out = if (fr === full) session.tick(full, frameW, frameH) else session.tick(fr, 2400, 1080)
        say(out.text)
        val u = out.learn
        if (u != null) { if (teachFor !== u) main.post { showTeach(u) } } else if (teachFor != null) main.post { hideTeach() }
    }

    private fun showTeach(u: Unknown) {
        hideTeach()
        teachFor = u
        val labels: List<Pair<String, String>> = when (u.kind) {
            "rank" -> listOf("A", "K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2").map { it to it }
            "suit" -> listOf("♥" to "h", "♦" to "d", "♠" to "s", "♣" to "c")
            else -> listOf("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "K", "M").map { it to it }
        }
        val what = when (u.kind) { "rank" -> "Que VALOR de carta é esse?"; "suit" -> "Que NAIPE é esse?"; else -> "Que NÚMERO é esse?" }
        val v = TeachView(this, "$what (${u.where})", labels, { label ->
            worker?.post { session.learn(u, label) }
            main.post { hideTeach() }
        }, {
            worker?.post { session.ignore(u) }
            main.post { hideTeach() }
        })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (capH * 0.04f).toInt()
        try { wm.addView(v, lp); teachView = v } catch (e: Exception) { e.printStackTrace() }
    }

    private fun hideTeach() {
        teachFor = null
        try { teachView?.let { wm.removeView(it) } } catch (e: Exception) { }
        teachView = null
    }

    override fun onDestroy() {
        running = false
        thread?.quitSafely()
        try { vdisplay?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        try { teachView?.let { wm.removeView(it) } } catch (e: Exception) { }
        try { statusView?.let { wm.removeView(it) } } catch (e: Exception) { }
        super.onDestroy()
    }
}
