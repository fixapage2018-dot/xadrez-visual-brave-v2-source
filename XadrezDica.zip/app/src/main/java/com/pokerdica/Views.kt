package com.pokerdica

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Caixinha de status ARRASTÁVEL (a barra verde à esquerda é a alça). Só ela recebe toque. */
class StatusView(ctx: Context, private val wm: WindowManager, val lp: WindowManager.LayoutParams, private val onMoved: () -> Unit) : View(ctx) {
    private var text = ""
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 30f }
    private val bg = Paint().apply { color = Color.argb(215, 0, 0, 0) }
    private val grip = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 230, 70) }
    private var lines: List<String> = listOf("")
    private val lh = 40f
    private var dx = 0f
    private var dy = 0f
    private var sx = 0
    private var sy = 0

    fun setText(s: String) {
        if (s == text) return
        text = s
        lines = s.split("\n")
        requestLayout()
        invalidate()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        var w = 0f
        for (l in lines) w = maxOf(w, txt.measureText(l))
        val maxW = resources.displayMetrics.widthPixels - 40
        setMeasuredDimension(minOf((w + 90f).toInt(), maxW), (lines.size * lh + 28f).toInt())
    }

    override fun onDraw(c: Canvas) {
        c.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), 18f, 18f, bg)
        c.drawRoundRect(RectF(10f, 14f, 22f, height - 14f), 6f, 6f, grip)
        for ((i, l) in lines.withIndex()) c.drawText(l, 36f, 14f + (i + 1) * lh - 10f, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
            MotionEvent.ACTION_MOVE -> {
                lp.x = sx + (e.rawX - dx).toInt()
                lp.y = sy + (e.rawY - dy).toInt()
                try { wm.updateViewLayout(this, lp) } catch (ex: Exception) { }
            }
            MotionEvent.ACTION_UP -> {
                onMoved()
                try {
                    context.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
                        .putInt("sx", lp.x).putInt("sy", lp.y).apply()
                } catch (ex: Exception) { }
            }
        }
        return true
    }
}

/** Janelinha "que carta é essa?": botões com os valores possíveis. */
class TeachView(ctx: Context, title: String, labels: List<Pair<String, String>>, onPick: (String) -> Unit, onIgnore: () -> Unit) : LinearLayout(ctx) {
    init {
        orientation = VERTICAL
        setBackgroundColor(Color.argb(240, 20, 20, 40))
        setPadding(24, 20, 24, 20)
        addView(TextView(ctx).apply { text = title; setTextColor(Color.WHITE); textSize = 17f; setPadding(0, 0, 0, 12) })
        val grid = GridLayout(ctx).apply { columnCount = 7 }
        for ((shown, value) in labels) {
            grid.addView(Button(ctx).apply {
                text = shown
                textSize = 18f
                setPadding(8, 8, 8, 8)
                minWidth = 0; minimumWidth = 0
                setOnClickListener { onPick(value) }
            })
        }
        addView(grid)
        addView(Button(ctx).apply { text = "Ignorar"; setOnClickListener { onIgnore() } })
    }
}
