package com.xadrezdica

import android.content.Context

/** Onde o tabuleiro fica na tela (em pixels reais). Padrão = prints 1080x2400 do jogo, escalado pela largura. */
class Config(val x: Float, val y: Float, val cell: Float) {
    companion object {
        fun defaults(screenW: Int): Config {
            val s = screenW / 1080f
            return Config(18f * s, 651f * s, 130.5f * s)
        }

        fun load(ctx: Context, screenW: Int): Config {
            val d = defaults(screenW)
            val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
            return Config(p.getFloat("x", d.x), p.getFloat("y", d.y), p.getFloat("cell", d.cell))
        }

        fun save(ctx: Context, c: Config) {
            ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
                .putFloat("x", c.x).putFloat("y", c.y).putFloat("cell", c.cell).apply()
        }

        fun reset(ctx: Context) {
            ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().clear().apply()
        }
    }
}
