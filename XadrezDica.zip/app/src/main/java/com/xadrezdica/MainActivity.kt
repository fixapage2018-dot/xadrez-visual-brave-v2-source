package com.xadrezdica

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var etX: EditText
    private lateinit var etY: EditText
    private lateinit var etCell: EditText

    private fun screenW(): Int = resources.displayMetrics.widthPixels

    private fun tv(text: String, sp: Float = 15f): TextView = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setPadding(0, 12, 0, 12)
    }

    private fun btn(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
    }

    private fun field(hint: String): EditText = EditText(this).apply {
        this.hint = hint
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 60)
        }
        col.addView(tv("Xadrez Dica", 26f))
        col.addView(tv(
            "1) Abra o jogo na posição inicial (antes do primeiro lance).\n" +
            "2) Volte aqui, toque em INICIAR e permita a captura de tela.\n" +
            "3) Vá pro jogo: as bolinhas verdes aparecem na sua vez. Bolinha com anel branco = casa de destino."
        ))
        col.addView(btn("1. Permitir exibir sobre outros apps") { askOverlay() })
        col.addView(btn("2. INICIAR") { start() })
        col.addView(btn("Parar") { stopService(Intent(this, CaptureService::class.java)) })
        col.addView(btn("Recalibrar (troquei a skin)") {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_RECAL))
        })
        col.addView(tv("Posição do tabuleiro na tela (pixels). Só mexa se as bolinhas saírem no lugar errado:", 14f))
        val cfg = Config.load(this, screenW())
        etX = field("X (esquerda do tabuleiro)"); etX.setText(cfg.x.toString())
        etY = field("Y (topo do tabuleiro)"); etY.setText(cfg.y.toString())
        etCell = field("Tamanho de cada casa"); etCell.setText(cfg.cell.toString())
        col.addView(etX); col.addView(etY); col.addView(etCell)
        col.addView(btn("Salvar posição") { saveCfg() })
        col.addView(btn("Voltar ao padrão") {
            Config.reset(this)
            val d = Config.defaults(screenW())
            etX.setText(d.x.toString()); etY.setText(d.y.toString()); etCell.setText(d.cell.toString())
        })
        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    private fun saveCfg() {
        try {
            Config.save(this, Config(etX.text.toString().toFloat(), etY.text.toString().toFloat(), etCell.text.toString().toFloat()))
            Toast.makeText(this, "Salvo. Toque em Parar e INICIAR de novo.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Valor inválido", Toast.LENGTH_SHORT).show()
        }
    }

    private fun askOverlay() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primeiro permita exibir sobre outros apps", Toast.LENGTH_LONG).show()
            askOverlay()
            return
        }
        saveCfg()
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            startForegroundService(i)
            Toast.makeText(this, "Rodando. Abra o jogo.", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
