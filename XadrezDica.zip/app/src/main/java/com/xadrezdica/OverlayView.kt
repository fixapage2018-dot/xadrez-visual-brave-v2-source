package com.xadrezdica

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * Camada transparente por cima do jogo. As bolinhas ficam no canto superior direito da casa:
 * esse canto o leitor ignora, então as bolinhas nunca atrapalham o reconhecimento das peças.
 */
class OverlayView(ctx: Context) : View(ctx) {
    var cfg: Config = Config(0f, 0f, 100f)
    var status: String = ""
    var fromRow = -1
    var fromCol = -1
    var toRow = -1
    var toCol = -1

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 230, 70); style = Paint.Style.FILL }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 80, 20); style = Paint.Style.STROKE; strokeWidth = 5f
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 5f
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 38f }
    private val bg = Paint().apply { color = Color.argb(170, 0, 0, 0) }

    fun setHint(fr: Int, fc: Int, tr: Int, tc: Int) {
        fromRow = fr; fromCol = fc; toRow = tr; toCol = tc
        invalidate()
    }

    fun clearHint() {
        fromRow = -1; toRow = -1
        invalidate()
    }

    fun setStatusText(s: String) {
        if (s != status) { status = s; invalidate() }
    }

    override fun onDraw(c: Canvas) {
        if (status.isNotEmpty()) {
            val w = txt.measureText(status)
            val top = (cfg.y - 120f).coerceAtLeast(10f)
            c.drawRoundRect(RectF(20f, top, 60f + w, top + 70f), 18f, 18f, bg)
            c.drawText(status, 40f, top + 50f, txt)
        }
        if (fromRow >= 0) dot(c, fromRow, fromCol, false)
        if (toRow >= 0) dot(c, toRow, toCol, true)
    }

    private fun dot(c: Canvas, row: Int, col: Int, dest: Boolean) {
        val cx = cfg.x + (col + 0.80f) * cfg.cell
        val cy = cfg.y + (row + 0.19f) * cfg.cell
        val r = cfg.cell * 0.15f
        c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r, edge)
        if (dest) c.drawCircle(cx, cy, r * 0.55f, ring)   // destino tem um anel branco dentro
    }
}
