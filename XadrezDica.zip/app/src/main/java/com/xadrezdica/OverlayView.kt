package com.xadrezdica

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/**
 * Camada transparente por cima do jogo. As bolinhas ficam no canto superior direito da casa:
 * esse canto o leitor ignora, então as bolinhas nunca atrapalham o reconhecimento das peças.
 */
class OverlayView(ctx: Context) : View(ctx) {
    var cfg: Config = Config(0f, 0f, 100f)
    var fromRow = -1
    var fromCol = -1
    var toRow = -1
    var toCol = -1

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 230, 70); style = Paint.Style.FILL }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 80, 20); style = Paint.Style.STROKE; strokeWidth = 5f
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 5f
    }

    fun setHint(fr: Int, fc: Int, tr: Int, tc: Int) {
        fromRow = fr; fromCol = fc; toRow = tr; toCol = tc
        invalidate()
    }

    fun clearHint() {
        fromRow = -1; toRow = -1
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        if (fromRow >= 0) dot(c, fromRow, fromCol, false)
        if (toRow >= 0) dot(c, toRow, toCol, true)
    }

    private fun dot(c: Canvas, row: Int, col: Int, dest: Boolean) {
        val cx = cfg.x + (col + 0.80f) * cfg.cell
        val cy = cfg.y + (row + 0.19f) * cfg.cell
        val r = cfg.cell * 0.15f
        c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r, edge)
        if (dest) c.drawCircle(cx, cy, r * 0.55f, ring)   // destino tem um anel branco dentro
    }
}

/**
 * Caixinha de status ARRASTÁVEL (janela própria, só ela recebe toque; o resto da tela continua livre).
 * Fica no topo por padrão, longe do tabuleiro. Lembre de não deixar em cima do tabuleiro:
 * a captura de tela enxerga tudo que está desenhado por cima.
 */
class StatusView(ctx: Context, private val wm: android.view.WindowManager, private val lp: android.view.WindowManager.LayoutParams) : View(ctx) {
    private var text = ""
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 30f }
    private val bg = Paint().apply { color = Color.argb(200, 0, 0, 0) }
    private val grip = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 230, 70) }
    private var lines: List<String> = listOf("")
    private val lh = 44f
    private var dx = 0f
    private var dy = 0f
    private var sx = 0
    private var sy = 0

    fun setText(s: String) {
        if (s == text) return
        text = s
        lines = s.split("\n")
        requestLayout()
        invalidate()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        var w = 0f
        for (l in lines) w = maxOf(w, txt.measureText(l))
        val maxW = resources.displayMetrics.widthPixels - 40
        setMeasuredDimension(minOf((w + 90f).toInt(), maxW), (lines.size * lh + 28f).toInt())
    }

    override fun onDraw(c: Canvas) {
        c.drawRoundRect(android.graphics.RectF(0f, 0f, width.toFloat(), height.toFloat()), 18f, 18f, bg)
        c.drawRoundRect(android.graphics.RectF(10f, 14f, 22f, height - 14f), 6f, 6f, grip)   // "alça" de arrastar
        for ((i, l) in lines.withIndex()) c.drawText(l, 36f, 14f + (i + 1) * lh - 10f, txt)
    }

    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.action) {
            android.view.MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
            android.view.MotionEvent.ACTION_MOVE -> {
                lp.x = sx + (e.rawX - dx).toInt()
                lp.y = sy + (e.rawY - dy).toInt()
                try { wm.updateViewLayout(this, lp) } catch (ex: Exception) { }
            }
            android.view.MotionEvent.ACTION_UP -> {
                try {
                    context.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
                        .putInt("sx", lp.x).putInt("sy", lp.y).apply()
                } catch (ex: Exception) { }
            }
        }
        return true
    }
}
