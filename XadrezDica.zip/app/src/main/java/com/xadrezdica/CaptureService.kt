package com.xadrezdica

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import com.xadrezdica.core.FenCheck
import com.xadrezdica.core.Session
import com.xadrezdica.core.UciEngine
import com.xadrezdica.core.parseSquare
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.ceil
import kotlin.math.roundToInt

class CaptureService : Service() {
    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_RECAL = "recal"
        const val ACTION_STOP = "stop"
        const val ACTION_HINT = "hint"
        private const val CHANNEL = "xd"
        private const val TICK_MS = 200L
        private const val MOVE_TIME_MS = 700
    }

    private var projection: MediaProjection? = null
    private var vdisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private var statusView: StatusView? = null
    private var statusLp: WindowManager.LayoutParams? = null
    private var waitTicks = 0
    private var presetIdx = 0
    private lateinit var wm: WindowManager

    private var thread: HandlerThread? = null
    private var worker: Handler? = null
    private val main = Handler(Looper.getMainLooper())
    private val engineExec = Executors.newSingleThreadExecutor()
    private lateinit var engine: UciEngine
    private val gen = AtomicInteger(0)

    @Volatile private var running = false
    private val session = Session()
    private var cfg = Config(0f, 0f, 100f)
    private var screenW = 0
    private var screenH = 0
    private var region = 0
    private var pix = IntArray(0)
    private var rowBuf = ByteArray(0)
    private var haveFrame = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RECAL -> { session.forceRecal = true; return START_NOT_STICKY }
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_HINT -> {
                worker?.post {
                    session.hintFen()?.let { requestHint(it, 0) }
                }
                return START_NOT_STICKY
            }
        }
        if (running) return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        if (data == null || code == 0) { stopSelf(); return START_NOT_STICKY }

        startForegroundCompat()
        try {
            begin(code, data)
        } catch (e: Exception) {
            e.printStackTrace()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Xadrez Dica", NotificationManager.IMPORTANCE_LOW))
        fun action(label: String, act: String, req: Int): Notification.Action {
            val pi = PendingIntent.getService(
                this, req, Intent(this, CaptureService::class.java).setAction(act),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_rotate), label, pi).build()
        }
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Xadrez Dica rodando")
            .setContentText("Lendo o tabuleiro e dando dicas")
            .setOngoing(true)
            .addAction(action("Nova dica", ACTION_HINT, 3))
            .addAction(action("Recalibrar", ACTION_RECAL, 1))
            .addAction(action("Parar", ACTION_STOP, 2))
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun begin(code: Int, data: Intent) {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        cfg = Config.load(this, screenW)
        region = ceil(8 * cfg.cell.toDouble() - 0.01).toInt()
        pix = IntArray(region * region)
        rowBuf = ByteArray(region * 4)

        engine = UciEngine(applicationInfo.nativeLibraryDir + "/libstockfish.so")

        val ov = OverlayView(this)
        ov.cfg = cfg
        val lp = WindowManager.LayoutParams(
            screenW, screenH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(ov, lp)
        overlay = ov

        // caixinha de status: janela separada, arrastável, começa no topo (longe do tabuleiro)
        val slp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        slp.gravity = Gravity.TOP or Gravity.START
        val sp = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        slp.x = sp.getInt("sx", 20)
        slp.y = sp.getInt("sy", (cfg.y + 8 * cfg.cell + 0.02f * screenH).toInt())
        statusLp = slp
        val sv = StatusView(this, wm, slp)
        sv.setText("Xadrez Dica: aguardando a posição inicial...")
        wm.addView(sv, slp)
        statusView = sv

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)
        val rd = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        reader = rd
        vdisplay = proj.createVirtualDisplay(
            "xd", screenW, screenH, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            rd.surface, null, null
        )

        running = true
        val t = HandlerThread("xd-capture")
        t.start()
        thread = t
        val w = Handler(t.looper)
        worker = w
        w.post(object : Runnable {
            override fun run() {
                if (!running) return
                try { tick() } catch (e: Exception) { e.printStackTrace() }
                if (running) w.postDelayed(this, TICK_MS)
            }
        })
    }

    private var full = IntArray(0)
    private var fullW = 0
    private var fullH = 0
    private var fullRow = ByteArray(0)

    /** Guarda o quadro inteiro (assim, trocar a região do tabuleiro não depende de chegar quadro novo). */
    private fun grabRegion(): Boolean {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            try {
                val plane = img.planes[0]
                val buf = plane.buffer
                val rs = plane.rowStride
                val w = minOf(img.width, rs / 4)
                val h = img.height
                if (full.size != w * h) { full = IntArray(w * h); fullRow = ByteArray(w * 4) }
                fullW = w; fullH = h
                for (y in 0 until h) {
                    buf.position(y * rs)
                    buf.get(fullRow, 0, w * 4)
                    var o = y * w
                    var i = 0
                    while (i < w * 4) {
                        full[o++] = ((fullRow[i].toInt() and 255) shl 16) or
                            ((fullRow[i + 1].toInt() and 255) shl 8) or (fullRow[i + 2].toInt() and 255)
                        i += 4
                    }
                }
                haveFrame = true
            } finally {
                img.close()
            }
        }
        if (!haveFrame) return false
        val bx = cfg.x.roundToInt()
        val by = cfg.y.roundToInt()
        if (bx < 0 || by < 0 || bx + region > fullW || by + region > fullH) return false
        for (y in 0 until region) System.arraycopy(full, (by + y) * fullW + bx, pix, y * region, region)
        return true
    }

    private fun tick() {
        if (!grabRegion()) {
            if (!haveFrame) say("Aguardando captura de tela...")
            else say("Tabuleiro fora da tela: ajuste a posição no app")
            return
        }
        val out = session.tick(pix, region, cfg.cell.toDouble())
        if (out.clearHint) {
            gen.incrementAndGet()
            main.post { overlay?.clearHint() }
        }
        val diag = "\n[tela ${fullW}x${fullH} | tab x=${cfg.x.roundToInt()} y=${cfg.y.roundToInt()} casa=${cfg.cell} | pixel central #${Integer.toHexString(pix[pix.size / 2] and 0xFFFFFF)}]"
        out.message?.let { say(if (it.startsWith("Aguardando a posição inicial")) it + diag else it) }
        if (out.message?.startsWith("Aguardando a posição inicial") == true) {
            if (++waitTicks >= 20) { waitTicks = 0; rotatePreset() }
        } else if (out.message != null) waitTicks = 0
        out.requestFen?.let { fen -> requestHint(fen, 0) }
    }

    private fun say(s: String) {
        main.post { statusView?.setText(s); keepOffBoard() }
    }

    /** A captura enxerga tudo que está por cima: a caixinha nunca pode ficar em cima do tabuleiro. */
    private fun keepOffBoard() {
        val sv = statusView ?: return
        val lp = statusLp ?: return
        val h = if (sv.height > 0) sv.height else 200
        val bTop = cfg.y; val bBot = cfg.y + 8 * cfg.cell
        if (lp.y + h > bTop && lp.y < bBot) {
            val below = (bBot + 0.01f * screenH).toInt()
            val above = (bTop - h - 0.01f * screenH).toInt()
            lp.y = if (below + h <= screenH) below else maxOf(0, above)
            try { wm.updateViewLayout(sv, lp) } catch (e: Exception) { }
        }
    }

    /** Se não achou a posição inicial por ~4 s, tenta o outro layout conhecido do tabuleiro. */
    private fun rotatePreset() {
        val sc = screenW / 1080f
        val presets = arrayOf(floatArrayOf(0f, 792f, 135f), floatArrayOf(18f, 651f, 130.5f))
        presetIdx = (presetIdx + 1) % presets.size
        val q = presets[presetIdx]
        cfg = Config(q[0] * sc, q[1] * sc, q[2] * sc)
        region = ceil(8 * cfg.cell.toDouble() - 0.01).toInt()
        pix = IntArray(region * region)
        rowBuf = ByteArray(region * 4)
        overlay?.cfg = cfg
    }

    private fun requestHint(fenIn: String, attempt: Int) {
        // confere a posição lida antes de mandar pro motor
        var fen = fenIn
        var why = FenCheck.problem(fen)
        if (why != null) {
            val flipped = FenCheck.flipTurn(fen)
            if (FenCheck.problem(flipped) == null) { fen = flipped; why = null }
        }
        if (why != null) {
            say("Leitura inválida: $why\n$fenIn")
            scheduleRetry(attempt)
            return
        }
        val my = gen.incrementAndGet()
        val fenFinal = fen
        engineExec.execute {
            if (gen.get() != my || !running) return@execute
            val mv = engine.bestMove(fenFinal, MOVE_TIME_MS)
            if (mv == null) {
                if (gen.get() == my) {
                    say("Stockfish falhou: ${engine.lastError}\n$fenFinal")
                    scheduleRetry(attempt)
                }
                return@execute
            }
            if (gen.get() != my || !running) return@execute
            val from = com.xadrezdica.core.parseSquare(mv.substring(0, 2))
            val to = com.xadrezdica.core.parseSquare(mv.substring(2, 4))
            val fr = session.rowOfSquare(from)
            val fc = session.colOfSquare(from)
            val tr = session.rowOfSquare(to)
            val tc = session.colOfSquare(to)
            main.post {
                if (gen.get() == my) {
                    overlay?.setHint(fr, fc, tr, tc)
                    statusView?.setText("Sua vez: $mv")
                }
            }
        }
    }

    /** Falhou? Tenta de novo sozinho (até 4 vezes), relendo a posição atual. */
    private fun scheduleRetry(attempt: Int) {
        if (attempt >= 4 || !running) return
        val g = gen.get()
        worker?.postDelayed({
            if (!running || gen.get() != g) return@postDelayed
            session.hintFen()?.let { requestHint(it, attempt + 1) }
        }, 2500L)
    }

    override fun onDestroy() {
        running = false
        gen.incrementAndGet()
        try { engine.kill() } catch (e: Exception) { }
        engineExec.shutdownNow()
        thread?.quitSafely()
        try { vdisplay?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        try { overlay?.let { wm.removeView(it) } } catch (e: Exception) { }
        try { statusView?.let { wm.removeView(it) } } catch (e: Exception) { }
        super.onDestroy()
    }
}
