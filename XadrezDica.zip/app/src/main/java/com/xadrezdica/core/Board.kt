package com.xadrezdica.core

/*
 * Convenções:
 *  - casa (sq) = rank * 8 + file, a1 = 0, h1 = 7, a8 = 56, h8 = 63
 *  - peça (código) = cor * 6 + tipo   (cor 0 = branca, 1 = preta; tipo 0=P 1=N 2=B 3=R 4=Q 5=K)
 *  - -1 = casa vazia, -2 = leitura inválida
 *  - (linha, coluna) da tela: linha 0 = topo. O jogador SEMPRE fica embaixo.
 */

const val PAWN = 0
const val KNIGHT = 1
const val BISHOP = 2
const val ROOK = 3
const val QUEEN = 4
const val KING = 5

fun squareOf(row: Int, col: Int, meWhite: Boolean): Int =
    if (meWhite) (7 - row) * 8 + col else row * 8 + (7 - col)

fun rowOf(sq: Int, meWhite: Boolean): Int =
    if (meWhite) 7 - sq / 8 else sq / 8

fun colOf(sq: Int, meWhite: Boolean): Int =
    if (meWhite) sq % 8 else 7 - sq % 8

private val BACK_RANK = intArrayOf(ROOK, KNIGHT, BISHOP, QUEEN, KING, BISHOP, KNIGHT, ROOK)

fun initialPlacement(): IntArray {
    val p = IntArray(64) { -1 }
    for (f in 0..7) {
        p[f] = 0 * 6 + BACK_RANK[f]
        p[8 + f] = 0 * 6 + PAWN
        p[48 + f] = 1 * 6 + PAWN
        p[56 + f] = 1 * 6 + BACK_RANK[f]
    }
    return p
}

fun squareName(sq: Int): String = "" + ('a' + sq % 8) + ('1' + sq / 8)

fun parseSquare(s: String): Int = (s[1] - '1') * 8 + (s[0] - 'a')
