package com.xadrezdica.core

import kotlin.math.abs

/** Confere se um FEN é uma posição legal "o bastante" pro Stockfish não engasgar. */
object FenCheck {
    private const val LETTERS = "PNBRQKpnbrqk"

    private fun board(fen: String): IntArray? {
        val b = IntArray(64) { -1 }
        val ranks = fen.split(" ")[0].split("/")
        if (ranks.size != 8) return null
        for ((i, row) in ranks.withIndex()) {
            val rank = 7 - i
            var file = 0
            for (ch in row) {
                if (ch.isDigit()) file += ch - '0'
                else {
                    val v = LETTERS.indexOf(ch)
                    if (v < 0 || file > 7) return null
                    b[rank * 8 + file] = v
                    file++
                }
            }
            if (file != 8) return null
        }
        return b
    }

    private fun attacked(b: IntArray, sq: Int, byWhite: Boolean): Boolean {
        val base = if (byWhite) 0 else 6
        val f = sq % 8
        val r = sq / 8
        // peões
        val pr = if (byWhite) r - 1 else r + 1
        if (pr in 0..7) for (df in intArrayOf(-1, 1)) {
            val pf = f + df
            if (pf in 0..7 && b[pr * 8 + pf] == base + PAWN) return true
        }
        // cavalos
        for ((dr, df) in listOf(1 to 2, 2 to 1, -1 to 2, -2 to 1, 1 to -2, 2 to -1, -1 to -2, -2 to -1)) {
            val nr = r + dr; val nf = f + df
            if (nr in 0..7 && nf in 0..7 && b[nr * 8 + nf] == base + KNIGHT) return true
        }
        // rei
        for (dr in -1..1) for (df in -1..1) {
            if (dr == 0 && df == 0) continue
            val nr = r + dr; val nf = f + df
            if (nr in 0..7 && nf in 0..7 && b[nr * 8 + nf] == base + KING) return true
        }
        // linhas e diagonais
        for ((dr, df) in listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1, 1 to 1, 1 to -1, -1 to 1, -1 to -1)) {
            val diag = dr != 0 && df != 0
            var nr = r + dr; var nf = f + df
            while (nr in 0..7 && nf in 0..7) {
                val v = b[nr * 8 + nf]
                if (v >= 0) {
                    if (v / 6 == (if (byWhite) 0 else 1)) {
                        val t = v % 6
                        if (t == QUEEN || (diag && t == BISHOP) || (!diag && t == ROOK)) return true
                    }
                    break
                }
                nr += dr; nf += df
            }
        }
        return false
    }

    /** null = ok; senão o motivo. */
    fun problem(fen: String): String? {
        val b = board(fen) ?: return "FEN ilegível"
        var wk = -1; var bk = -1
        var wc = 0; var bc = 0; var wp = 0; var bp = 0
        for (s in 0 until 64) {
            val v = b[s]
            if (v < 0) continue
            if (v == 5) { if (wk >= 0) return "2 reis brancos"; wk = s }
            if (v == 11) { if (bk >= 0) return "2 reis pretos"; bk = s }
            if (v / 6 == 0) { wc++; if (v == 0) wp++ } else { bc++; if (v == 6) bp++ }
            if (v % 6 == PAWN && (s < 8 || s >= 56)) return "peão na primeira/última fileira"
        }
        if (wk < 0 || bk < 0) return "falta um rei"
        if (wc > 16 || bc > 16 || wp > 8 || bp > 8) return "peças demais"
        if (abs(wk % 8 - bk % 8) <= 1 && abs(wk / 8 - bk / 8) <= 1) return "reis colados"
        val whiteToMove = fen.split(" ").getOrNull(1) == "w"
        // quem NÃO tem a vez não pode estar em xeque
        if (whiteToMove && attacked(b, bk, true)) return "rei preto em xeque com a vez das brancas"
        if (!whiteToMove && attacked(b, wk, false)) return "rei branco em xeque com a vez das pretas"
        return null
    }

    fun flipTurn(fen: String): String {
        val p = fen.split(" ").toMutableList()
        if (p.size > 1) p[1] = if (p[1] == "w") "b" else "w"
        return p.joinToString(" ")
    }
}
