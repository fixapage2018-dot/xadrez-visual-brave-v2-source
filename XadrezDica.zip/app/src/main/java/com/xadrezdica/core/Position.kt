package com.xadrezdica.core

class Move(val from: Int, val to: Int, val promo: Int)   // promo: -1 ou KNIGHT..QUEEN

/**
 * Posição de xadrez completa com geração de lances legais.
 * Código da peça = cor*6 + tipo (cor 0 = branca). -1 = casa vazia. Casa = rank*8 + file (a1 = 0).
 */
class Position(
    val b: IntArray,
    val whiteToMove: Boolean,
    val wK: Boolean, val wQ: Boolean, val bK: Boolean, val bQ: Boolean,
    val ep: Int            // casa "de passagem" do en passant, ou -1
) {
    companion object {
        fun start() = Position(initialPlacement(), true, true, true, true, true, -1)

        fun fromFen(fen: String): Position {
            val parts = fen.split(" ")
            val b = IntArray(64) { -1 }
            for ((i, row) in parts[0].split("/").withIndex()) {
                var file = 0
                for (ch in row) {
                    if (ch.isDigit()) file += ch - '0'
                    else { b[(7 - i) * 8 + file] = "PNBRQKpnbrqk".indexOf(ch); file++ }
                }
            }
            val c = parts.getOrElse(2) { "-" }
            val ep = parts.getOrElse(3) { "-" }.let { if (it == "-") -1 else parseSquare(it) }
            return Position(b, parts[1] == "w", 'K' in c, 'Q' in c, 'k' in c, 'q' in c, ep)
        }

        private val KN = intArrayOf(1, 2, 2, 1, -1, 2, -2, 1, 1, -2, 2, -1, -1, -2, -2, -1)
        private val KG = intArrayOf(-1, -1, -1, 0, -1, 1, 0, -1, 0, 1, 1, -1, 1, 0, 1, 1)
        private val DIAG = intArrayOf(1, 1, 1, -1, -1, 1, -1, -1)
        private val ORTH = intArrayOf(1, 0, -1, 0, 0, 1, 0, -1)

        fun attacked(b: IntArray, sq: Int, byWhite: Boolean): Boolean {
            val base = if (byWhite) 0 else 6
            val f = sq % 8
            val r = sq / 8
            val pr = if (byWhite) r - 1 else r + 1
            if (pr in 0..7) {
                if (f > 0 && b[pr * 8 + f - 1] == base + PAWN) return true
                if (f < 7 && b[pr * 8 + f + 1] == base + PAWN) return true
            }
            var i = 0
            while (i < KN.size) {
                val nr = r + KN[i]; val nf = f + KN[i + 1]
                if (nr in 0..7 && nf in 0..7 && b[nr * 8 + nf] == base + KNIGHT) return true
                i += 2
            }
            i = 0
            while (i < KG.size) {
                val nr = r + KG[i]; val nf = f + KG[i + 1]
                if (nr in 0..7 && nf in 0..7 && b[nr * 8 + nf] == base + KING) return true
                i += 2
            }
            for (k in 0..1) {
                val dirs = if (k == 0) DIAG else ORTH
                var j = 0
                while (j < dirs.size) {
                    var nr = r + dirs[j]; var nf = f + dirs[j + 1]
                    while (nr in 0..7 && nf in 0..7) {
                        val v = b[nr * 8 + nf]
                        if (v >= 0) {
                            if (v / 6 == (if (byWhite) 0 else 1)) {
                                val t = v % 6
                                if (t == QUEEN || (k == 0 && t == BISHOP) || (k == 1 && t == ROOK)) return true
                            }
                            break
                        }
                        nr += dirs[j]; nf += dirs[j + 1]
                    }
                    j += 2
                }
            }
            return false
        }
    }

    private fun kingSq(white: Boolean): Int {
        val k = if (white) 5 else 11
        for (s in 0 until 64) if (b[s] == k) return s
        return -1
    }

    fun inCheck(white: Boolean): Boolean {
        val k = kingSq(white)
        return k >= 0 && attacked(b, k, !white)
    }

    private fun addPawn(res: ArrayList<Move>, from: Int, to: Int, promo: Boolean) {
        if (promo) {
            res.add(Move(from, to, QUEEN)); res.add(Move(from, to, ROOK))
            res.add(Move(from, to, BISHOP)); res.add(Move(from, to, KNIGHT))
        } else res.add(Move(from, to, -1))
    }

    fun legalMoves(): List<Move> {
        val res = ArrayList<Move>(48)
        val me = if (whiteToMove) 0 else 1
        for (s in 0 until 64) {
            val v = b[s]
            if (v < 0 || v / 6 != me) continue
            val t = v % 6
            val f = s % 8
            val r = s / 8
            when (t) {
                PAWN -> {
                    val dir = if (me == 0) 1 else -1
                    val startRank = if (me == 0) 1 else 6
                    val promoRank = if (me == 0) 7 else 0
                    val r1 = r + dir
                    if (r1 in 0..7) {
                        val s1 = r1 * 8 + f
                        if (b[s1] < 0) {
                            addPawn(res, s, s1, r1 == promoRank)
                            if (r == startRank) {
                                val s2 = (r + 2 * dir) * 8 + f
                                if (b[s2] < 0) res.add(Move(s, s2, -1))
                            }
                        }
                        for (df in intArrayOf(-1, 1)) {
                            val nf = f + df
                            if (nf !in 0..7) continue
                            val s3 = r1 * 8 + nf
                            val tv = b[s3]
                            if (tv >= 0 && tv / 6 != me) addPawn(res, s, s3, r1 == promoRank)
                            else if (tv < 0 && s3 == ep) res.add(Move(s, s3, -1))
                        }
                    }
                }
                KNIGHT, KING -> {
                    val offs = if (t == KNIGHT) KN else KG
                    var i = 0
                    while (i < offs.size) {
                        val nr = r + offs[i]; val nf = f + offs[i + 1]
                        i += 2
                        if (nr !in 0..7 || nf !in 0..7) continue
                        val tv = b[nr * 8 + nf]
                        if (tv < 0 || tv / 6 != me) res.add(Move(s, nr * 8 + nf, -1))
                    }
                    if (t == KING) castling(res, me)
                }
                else -> {
                    val dirsList = when (t) { BISHOP -> listOf(DIAG); ROOK -> listOf(ORTH); else -> listOf(DIAG, ORTH) }
                    for (dirs in dirsList) {
                        var j = 0
                        while (j < dirs.size) {
                            var nr = r + dirs[j]; var nf = f + dirs[j + 1]
                            while (nr in 0..7 && nf in 0..7) {
                                val tv = b[nr * 8 + nf]
                                if (tv < 0) res.add(Move(s, nr * 8 + nf, -1))
                                else { if (tv / 6 != me) res.add(Move(s, nr * 8 + nf, -1)); break }
                                nr += dirs[j]; nf += dirs[j + 1]
                            }
                            j += 2
                        }
                    }
                }
            }
        }
        val out = ArrayList<Move>(res.size)
        for (m in res) if (!make(m).inCheck(me == 0)) out.add(m)
        return out
    }

    private fun castling(res: ArrayList<Move>, me: Int) {
        val white = me == 0
        val base = if (white) 0 else 56
        val king = if (white) 5 else 11
        val rook = if (white) 3 else 9
        if (b[base + 4] != king) return
        val enemyWhite = !white
        if (attacked(b, base + 4, enemyWhite)) return
        val ks = if (white) wK else bK
        val qs = if (white) wQ else bQ
        if (ks && b[base + 7] == rook && b[base + 5] < 0 && b[base + 6] < 0 &&
            !attacked(b, base + 5, enemyWhite) && !attacked(b, base + 6, enemyWhite)
        ) res.add(Move(base + 4, base + 6, -1))
        if (qs && b[base] == rook && b[base + 1] < 0 && b[base + 2] < 0 && b[base + 3] < 0 &&
            !attacked(b, base + 3, enemyWhite) && !attacked(b, base + 2, enemyWhite)
        ) res.add(Move(base + 4, base + 2, -1))
    }

    fun make(m: Move): Position {
        val nb = b.copyOf()
        val v = nb[m.from]
        val me = v / 6
        val t = v % 6
        nb[m.from] = -1
        if (t == PAWN && m.to == ep && b[m.to] < 0 && m.to % 8 != m.from % 8) {
            nb[(m.from / 8) * 8 + m.to % 8] = -1      // captura en passant
        }
        nb[m.to] = if (m.promo >= 0) me * 6 + m.promo else v
        if (t == KING && kotlin.math.abs(m.to - m.from) == 2) {      // roque: move a torre
            val base = if (me == 0) 0 else 56
            if (m.to > m.from) { nb[base + 5] = nb[base + 7]; nb[base + 7] = -1 }
            else { nb[base + 3] = nb[base]; nb[base] = -1 }
        }
        var k1 = wK; var q1 = wQ; var k2 = bK; var q2 = bQ
        for (sq in intArrayOf(m.from, m.to)) {
            when (sq) {
                4 -> { k1 = false; q1 = false }
                7 -> k1 = false
                0 -> q1 = false
                60 -> { k2 = false; q2 = false }
                63 -> k2 = false
                56 -> q2 = false
            }
        }
        val newEp = if (t == PAWN && kotlin.math.abs(m.to - m.from) == 16) (m.from + m.to) / 2 else -1
        return Position(nb, !whiteToMove, k1, q1, k2, q2, newEp)
    }

    fun fen(): String {
        val sb = StringBuilder()
        val letters = "PNBRQKpnbrqk"
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val v = b[rank * 8 + file]
                if (v < 0) empty++
                else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(letters[v])
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 0) sb.append('/')
        }
        sb.append(if (whiteToMove) " w " else " b ")
        val c = StringBuilder()
        if (wK) c.append('K'); if (wQ) c.append('Q'); if (bK) c.append('k'); if (bQ) c.append('q')
        sb.append(if (c.isEmpty()) "-" else c.toString())
        sb.append(' ')
        var epOut = "-"
        if (ep >= 0) {
            val pawn = (if (whiteToMove) 0 else 6) + PAWN
            for (m in legalMoves()) {
                if (m.to == ep && b[m.from] == pawn && b[m.to] < 0 && m.to % 8 != m.from % 8) { epOut = squareName(ep); break }
            }
        }
        sb.append(epOut).append(" 0 1")
        return sb.toString()
    }
}
