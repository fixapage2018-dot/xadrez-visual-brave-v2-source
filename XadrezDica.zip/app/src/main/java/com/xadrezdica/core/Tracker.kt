package com.xadrezdica.core

/**
 * Segue a partida pelas REGRAS: a cada mudança na tela (quais casas estão ocupadas e por qual cor),
 * procura o lance (ou 2-3 lances) legal que explica a mudança. O formato da peça só é usado
 * pra desempatar e pra saber em que a promoção virou.
 *
 * Como o formato da peça pode enganar (dama x bispo x torre...), a promoção cria várias hipóteses
 * (dama, torre, bispo, cavalo). As que não conseguem explicar os lances seguintes são descartadas.
 */
class Tracker(start: Position, val meWhite: Boolean) {
    enum class Result { SAME, CHANGED, UNEXPLAINED }

    private class Hyp(val pos: Position, val score: Double)

    private var hyps: List<Hyp> = listOf(Hyp(start, 0.0))

    val pos: Position get() = hyps[0].pos

    fun myTurn(): Boolean = pos.whiteToMove == meWhite
    fun fen(): String = pos.fen()
    fun placementEquals(p: IntArray) = pos.b.contentEquals(p)
    fun allFens(): List<String> = hyps.map { it.pos.fen() }

    fun reset(p: Position) { hyps = listOf(Hyp(p, 0.0)) }

    private fun matches(b: IntArray, obs: IntArray): Boolean {
        for (s in 0 until 64) {
            val v = b[s]
            if ((if (v < 0) -1 else v / 6) != obs[s]) return false
        }
        return true
    }

    private fun gain(before: IntArray, after: IntArray, score: (Int, Int) -> Double): Double {
        var g = 0.0
        for (s in 0 until 64) {
            val a = after[s]
            if (a >= 0 && a != before[s]) {
                g += score(s, a)
                if (a % 6 == QUEEN && before[s] >= 0 && before[s] % 6 == PAWN) g += 0.15   // promoção: dama é a mais provável
            }
        }
        return g
    }

    private fun key(p: Position): String {
        val sb = StringBuilder(80)
        for (v in p.b) sb.append((v + 2).toChar())
        sb.append(if (p.whiteToMove) 'w' else 'b')
        sb.append(if (p.wK) 'K' else '-').append(if (p.wQ) 'Q' else '-')
        sb.append(if (p.bK) 'k' else '-').append(if (p.bQ) 'q' else '-')
        sb.append(p.ep)
        return sb.toString()
    }

    /** obs: -1 vazia, 0 peça branca, 1 peça preta (64 casas, a1 = 0). score(casa, códigoDePeça) = semelhança 0..1. */
    fun update(obs: IntArray, deep: Boolean, score: (Int, Int) -> Double): Result {
        if (matches(hyps[0].pos.b, obs)) return Result.SAME

        val out = HashMap<String, Hyp>()
        fun offer(base: Hyp, p: Position) {
            val h = Hyp(p, base.score + gain(base.pos.b, p.b, score))
            val k = key(p)
            val old = out[k]
            if (old == null || h.score > old.score) out[k] = h
        }

        for (h in hyps) {
            for (m in h.pos.legalMoves()) {
                val p1 = h.pos.make(m)
                if (matches(p1.b, obs)) offer(h, p1)
            }
        }
        if (out.isEmpty()) {
            for (h in hyps) for (m in h.pos.legalMoves()) {
                val p1 = h.pos.make(m)
                for (m2 in p1.legalMoves()) {
                    val p2 = p1.make(m2)
                    if (matches(p2.b, obs)) offer(h, p2)
                }
            }
        }
        if (out.isEmpty() && deep) {
            for (h in hyps) for (m in h.pos.legalMoves()) {
                val p1 = h.pos.make(m)
                for (m2 in p1.legalMoves()) {
                    val p2 = p1.make(m2)
                    for (m3 in p2.legalMoves()) {
                        val p3 = p2.make(m3)
                        if (matches(p3.b, obs)) offer(h, p3)
                    }
                }
            }
        }
        if (out.isEmpty()) return Result.UNEXPLAINED
        hyps = out.values.sortedByDescending { it.score }.take(16)
        return Result.CHANGED
    }
}
