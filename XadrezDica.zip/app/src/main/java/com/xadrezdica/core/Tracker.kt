package com.xadrezdica.core

/**
 * Segue a partida pelas REGRAS: a cada mudança na tela (quais casas estão ocupadas e por qual cor),
 * procura o lance (ou 2-3 lances) legal que explica a mudança. O formato da peça só é usado
 * pra desempatar e pra saber em que a promoção virou.
 *
 * - Promoção cria várias hipóteses (dama, torre, bispo, cavalo); as que não explicam os lances seguintes caem.
 * - Guarda os últimos estados: se a tela mostrar algo que só faz sentido "voltando no tempo" (peça arrastada
 *   e solta em outro lugar, animação, lance desfeito), ele volta e refaz o caminho em vez de se perder.
 */
class Tracker(start: Position, val meWhite: Boolean) {
    enum class Result { SAME, CHANGED, UNEXPLAINED }

    private class Hyp(val pos: Position, val score: Double)

    private var hyps: List<Hyp> = listOf(Hyp(start, 0.0))
    private val history = ArrayList<List<Hyp>>()      // estados ANTES de cada mudança aceita (do mais antigo ao mais novo)

    /** true se a última atualização precisou voltar no tempo e refazer lances. */
    var corrected = false
        private set

    val pos: Position get() = hyps[0].pos

    fun myTurn(): Boolean = pos.whiteToMove == meWhite
    fun fen(): String = pos.fen()
    fun placementEquals(p: IntArray) = pos.b.contentEquals(p)
    fun allFens(): List<String> = hyps.map { it.pos.fen() }

    fun reset(p: Position) { hyps = listOf(Hyp(p, 0.0)); history.clear() }

    private fun matches(b: IntArray, obs: IntArray): Boolean {
        for (s in 0 until 64) {
            val v = b[s]
            if ((if (v < 0) -1 else v / 6) != obs[s]) return false
        }
        return true
    }

    private fun gain(before: IntArray, after: IntArray, score: (Int, Int) -> Double): Double {
        var g = 0.0
        for (s in 0 until 64) {
            val a = after[s]
            if (a >= 0 && a != before[s]) {
                g += score(s, a)
                if (a % 6 == QUEEN && before[s] >= 0 && before[s] % 6 == PAWN) g += 0.15   // promoção: dama é a mais provável
            }
        }
        return g
    }

    private fun key(p: Position): String {
        val sb = StringBuilder(80)
        for (v in p.b) sb.append((v + 2).toChar())
        sb.append(if (p.whiteToMove) 'w' else 'b')
        sb.append(if (p.wK) 'K' else '-').append(if (p.wQ) 'Q' else '-')
        sb.append(if (p.bK) 'k' else '-').append(if (p.bQ) 'q' else '-')
        sb.append(p.ep)
        return sb.toString()
    }

    /** Hipóteses que, a partir de [base], chegam em [obs] com 1..maxDepth lances; null se nenhuma. */
    private fun explain(base: List<Hyp>, obs: IntArray, maxDepth: Int, score: (Int, Int) -> Double): List<Hyp>? {
        val out = HashMap<String, Hyp>()
        fun offer(h: Hyp, p: Position) {
            val n = Hyp(p, h.score + gain(h.pos.b, p.b, score))
            val k = key(p)
            val old = out[k]
            if (old == null || n.score > old.score) out[k] = n
        }
        for (h in base) for (m in h.pos.legalMoves()) {
            val p1 = h.pos.make(m)
            if (matches(p1.b, obs)) offer(h, p1)
        }
        if (out.isEmpty() && maxDepth >= 2) {
            for (h in base) for (m in h.pos.legalMoves()) {
                val p1 = h.pos.make(m)
                for (m2 in p1.legalMoves()) {
                    val p2 = p1.make(m2)
                    if (matches(p2.b, obs)) offer(h, p2)
                }
            }
        }
        if (out.isEmpty() && maxDepth >= 3) {
            for (h in base) for (m in h.pos.legalMoves()) {
                val p1 = h.pos.make(m)
                for (m2 in p1.legalMoves()) {
                    val p2 = p1.make(m2)
                    for (m3 in p2.legalMoves()) {
                        val p3 = p2.make(m3)
                        if (matches(p3.b, obs)) offer(h, p3)
                    }
                }
            }
        }
        if (out.isEmpty()) return null
        return out.values.sortedByDescending { it.score }.take(16)
    }

    /**
     * obs: -1 vazia, 0 peça branca, 1 peça preta (64 casas, a1 = 0). score(casa, códigoDePeça) = semelhança 0..1.
     * deep: permite explicar com 3 lances. lookBack: permite voltar no tempo (mais caro; o chamador espaça as tentativas).
     */
    fun update(obs: IntArray, deep: Boolean, lookBack: Boolean = true, score: (Int, Int) -> Double): Result {
        corrected = false
        if (matches(hyps[0].pos.b, obs)) return Result.SAME

        val direct = explain(hyps, obs, if (deep) 3 else 2, score)
        if (direct != null) {
            history.add(hyps)
            while (history.size > 5) history.removeAt(0)
            hyps = direct
            return Result.CHANGED
        }
        if (!lookBack) return Result.UNEXPLAINED

        // Voltando no tempo: do estado mais recente pro mais antigo
        for (i in history.indices.reversed()) {
            val h = history[i]
            if (matches(h[0].pos.b, obs)) {            // a tela voltou a um estado anterior (lance desfeito / peça devolvida)
                hyps = h
                while (history.size > i) history.removeAt(history.size - 1)
                corrected = true
                return Result.CHANGED
            }
            val ex = explain(h, obs, 2, score)
            if (ex != null) {
                hyps = ex
                while (history.size > i + 1) history.removeAt(history.size - 1)
                corrected = true
                return Result.CHANGED
            }
        }
        return Result.UNEXPLAINED
    }
}
