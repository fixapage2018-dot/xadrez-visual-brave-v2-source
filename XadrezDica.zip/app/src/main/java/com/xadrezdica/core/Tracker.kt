package com.xadrezdica.core

import kotlin.math.abs

/**
 * Acompanha a partida só olhando as posições lidas na tela: deduz de quem é a vez,
 * direitos de roque e en passant, e monta o FEN que vai pro Stockfish.
 */
class Tracker(
    placement: IntArray,
    var turnWhite: Boolean?,          // null = não sei de quem é a vez
    val meWhite: Boolean,
    epRaw: Int = -1,
    epPushed: Int = -1
) {
    enum class Result { SAME, CHANGED, IGNORED }

    var placement: IntArray = placement.copyOf()
        private set
    private var wK = true
    private var wQ = true
    private var bK = true
    private var bQ = true
    private var epRaw = epRaw
    private var epPushed = epPushed

    fun myTurn(): Boolean? = turnWhite?.let { it == meWhite }

    fun placementEquals(p: IntArray) = placement.contentEquals(p)

    private fun commit(cur: IntArray, turn: Boolean?, ep: Int, pushed: Int) {
        placement = cur.copyOf()
        turnWhite = turn
        epRaw = ep
        epPushed = pushed
        wK = wK && cur[4] == 5 && cur[7] == 3
        wQ = wQ && cur[4] == 5 && cur[0] == 3
        bK = bK && cur[60] == 11 && cur[63] == 9
        bQ = bQ && cur[60] == 11 && cur[56] == 9
    }

    /** hlTurnWhite = de quem é a vez segundo o destaque do último lance (se o jogo destaca). */
    fun update(cur: IntArray, hlTurnWhite: Boolean?): Result {
        if (cur.contentEquals(placement)) return Result.SAME
        var wk = 0
        var bk = 0
        for (v in cur) { if (v == 5) wk++; if (v == 11) bk++ }
        if (wk != 1 || bk != 1) return Result.IGNORED

        val arr = arrayOf(ArrayList<Int>(), ArrayList<Int>())
        val dep = arrayOf(ArrayList<Int>(), ArrayList<Int>())
        for (s in 0 until 64) {
            val p = placement[s]
            val q = cur[s]
            if (p == q) continue
            if (q >= 0) arr[q / 6].add(s)
            if (p >= 0) dep[p / 6].add(s)
        }
        val aw = arr[0].size
        val ab = arr[1].size
        if (aw == 0 && ab == 0) return Result.IGNORED          // só sumiram peças: provável animação
        if (aw > 0 && ab > 0) {                                 // 2+ lances entre duas leituras
            commit(cur, hlTurnWhite ?: turnWhite, -1, -1)
            return Result.CHANGED
        }
        val m = if (aw > 0) 0 else 1
        val a = arr[m]
        val d = dep[m]
        var from = -1
        var to = -1
        if (a.size == 2 && d.size == 2) {
            // roque: rei + torre
            val king = m * 6 + 5
            val rook = m * 6 + 3
            val kTo = a.firstOrNull { cur[it] == king } ?: return Result.IGNORED
            val kFrom = d.firstOrNull { placement[it] == king } ?: return Result.IGNORED
            if (a.none { cur[it] == rook } || d.none { placement[it] == rook }) return Result.IGNORED
            from = kFrom; to = kTo
        } else if (a.size == 1 && d.size == 1) {
            from = d[0]; to = a[0]
        } else {
            return Result.IGNORED
        }
        val nextWhite = (m == 1)
        val movedPawn = placement[from] % 6 == PAWN && placement[from] >= 0
        if (movedPawn && abs(to - from) == 16) commit(cur, nextWhite, (from + to) / 2, to)
        else commit(cur, nextWhite, -1, -1)
        return Result.CHANGED
    }

    /** Perdeu o fio da meada: adota a posição lida como verdade. */
    fun resync(cur: IntArray, hlTurnWhite: Boolean?) {
        commit(cur, hlTurnWhite, -1, -1)
    }

    fun fen(): String? {
        val white = turnWhite ?: return null
        val sb = StringBuilder()
        val letters = "PNBRQKpnbrqk"
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val v = placement[rank * 8 + file]
                if (v < 0) {
                    empty++
                } else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(letters[v])
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 0) sb.append('/')
        }
        sb.append(if (white) " w " else " b ")
        val cast = StringBuilder()
        if (wK) cast.append('K')
        if (wQ) cast.append('Q')
        if (bK) cast.append('k')
        if (bQ) cast.append('q')
        sb.append(if (cast.isEmpty()) "-" else cast.toString())
        sb.append(' ')
        sb.append(if (epValid(white)) squareName(epRaw) else "-")
        sb.append(" 0 1")
        return sb.toString()
    }

    /** en passant só entra no FEN se existe peão adversário do lado pra capturar. */
    private fun epValid(whiteToMove: Boolean): Boolean {
        if (epRaw < 0 || epPushed < 0) return false
        val myPawn = (if (whiteToMove) 0 else 6) + PAWN
        val file = epPushed % 8
        if (file > 0 && placement[epPushed - 1] == myPawn) return true
        if (file < 7 && placement[epPushed + 1] == myPawn) return true
        return false
    }
}
