package com.xadrezdica.core

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.Timer
import java.util.TimerTask

/** Conversa com o Stockfish (ou qualquer motor UCI) por um processo externo. */
class UciEngine(private val path: String) {
    @Volatile private var proc: Process? = null
    private var out: BufferedWriter? = null
    private var inp: BufferedReader? = null

    /** Motivo da última falha, em português, pra mostrar na tela. */
    @Volatile var lastError: String = ""
        private set

    private fun send(s: String) {
        val w = out ?: throw IOException("motor fechado")
        w.write(s)
        w.write("\n")
        w.flush()
    }

    private fun exitInfo(): String {
        val p = proc ?: return "sem processo"
        return try {
            if (p.waitFor(300, java.util.concurrent.TimeUnit.MILLISECONDS)) {
                val c = p.exitValue()
                val nome = when (c) {
                    137 -> " (morto pelo Android)"
                    139 -> " (travou/segfault)"
                    132 -> " (CPU sem suporte)"
                    else -> ""
                }
                "encerrou com código $c$nome"
            } else "processo vivo mas mudo"
        } catch (e: Exception) {
            "estado desconhecido"
        }
    }

    /** Lê linhas até uma começar com [prefix]. Se passar do tempo, mata o processo (nunca trava). */
    private fun readUntil(prefix: String, timeoutMs: Long): String? {
        val p = proc ?: return null
        val r = inp ?: return null
        val timer = Timer(true)
        val timedOut = java.util.concurrent.atomic.AtomicBoolean(false)
        timer.schedule(object : TimerTask() {
            override fun run() { timedOut.set(true); p.destroyForcibly() }
        }, timeoutMs)
        try {
            while (true) {
                val line = r.readLine()
                if (line == null) {
                    lastError = if (timedOut.get()) "motor travou (sem resposta em ${timeoutMs / 1000}s)" else "motor ${exitInfo()}"
                    return null
                }
                if (line.startsWith(prefix)) return line
            }
        } catch (e: IOException) {
            lastError = if (timedOut.get()) "motor travou (sem resposta em ${timeoutMs / 1000}s)" else "motor ${exitInfo()}"
            return null
        } finally {
            timer.cancel()
        }
    }

    @Synchronized
    fun ensureStarted(): Boolean {
        val cur = proc
        if (cur != null && cur.isAlive) return true
        close()
        try {
            val f = File(path)
            if (!f.exists()) { lastError = "arquivo do Stockfish não está no APK"; return false }
            val np = ProcessBuilder(path).redirectErrorStream(true).start()
            proc = np
            out = BufferedWriter(OutputStreamWriter(np.outputStream))
            inp = BufferedReader(InputStreamReader(np.inputStream))
            send("uci")
            if (readUntil("uciok", 30000) == null) { close(); return false }
            send("setoption name Threads value 2")
            send("setoption name Hash value 32")
            send("isready")
            if (readUntil("readyok", 30000) == null) { close(); return false }
            return true
        } catch (e: Exception) {
            lastError = "não consegui abrir o motor: ${e.message}"
            close()
            return false
        }
    }

    private fun tryOnce(fen: String, moveTimeMs: Int): String? {
        if (!ensureStarted()) return null
        try {
            send("ucinewgame")
            send("isready")
            if (readUntil("readyok", 10000) == null) { close(); return null }
            send("position fen $fen")
            send("go movetime $moveTimeMs")
            val line = readUntil("bestmove", moveTimeMs + 5000L)
            if (line == null) { close(); return null }
            val mv = line.split(" ").getOrNull(1)
            if (mv == null || mv == "(none)" || mv.length < 4) {
                lastError = "sem lance possível (posição lida inválida ou fim de jogo)"
                return null
            }
            return mv
        } catch (e: Exception) {
            lastError = "erro falando com o motor: ${e.message}"
            close()
            return null
        }
    }

    /** Melhor lance (ex.: "e2e4", "e7e8q") pra posição FEN, ou null se não deu. Se o motor morreu, reinicia e tenta de novo. */
    @Synchronized
    fun bestMove(fen: String, moveTimeMs: Int): String? {
        val first = tryOnce(fen, moveTimeMs)
        if (first != null) return first
        if (lastError.startsWith("sem lance") || lastError.startsWith("arquivo")) return null
        close()
        return tryOnce(fen, moveTimeMs)
    }

    /** Mata o processo sem esperar (pode ser chamado de qualquer thread). */
    fun kill() {
        proc?.destroyForcibly()
    }

    @Synchronized
    fun close() {
        try { out?.write("quit\n"); out?.flush() } catch (e: Exception) { }
        proc?.destroyForcibly()
        proc = null
        out = null
        inp = null
    }
}
