package com.xadrezdica.core

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.Timer
import java.util.TimerTask

/** Conversa com o Stockfish (ou qualquer motor UCI) por um processo externo. */
class UciEngine(private val path: String) {
    @Volatile private var proc: Process? = null
    private var out: BufferedWriter? = null
    private var inp: BufferedReader? = null

    private fun send(s: String) {
        val w = out ?: throw IOException("motor fechado")
        w.write(s)
        w.write("\n")
        w.flush()
    }

    /** Lê linhas até uma começar com [prefix]. Se passar do tempo, mata o processo (nunca trava). */
    private fun readUntil(prefix: String, timeoutMs: Long): String? {
        val p = proc ?: return null
        val r = inp ?: return null
        val timer = Timer(true)
        timer.schedule(object : TimerTask() {
            override fun run() { p.destroyForcibly() }
        }, timeoutMs)
        try {
            while (true) {
                val line = r.readLine() ?: return null
                if (line.startsWith(prefix)) return line
            }
        } catch (e: IOException) {
            return null
        } finally {
            timer.cancel()
        }
    }

    @Synchronized
    fun ensureStarted(): Boolean {
        val cur = proc
        if (cur != null && cur.isAlive) return true
        close()
        try {
            if (!File(path).exists()) return false
            val np = ProcessBuilder(path).redirectErrorStream(true).start()
            proc = np
            out = BufferedWriter(OutputStreamWriter(np.outputStream))
            inp = BufferedReader(InputStreamReader(np.inputStream))
            send("uci")
            if (readUntil("uciok", 30000) == null) { close(); return false }
            send("setoption name Threads value 2")
            send("setoption name Hash value 32")
            send("isready")
            if (readUntil("readyok", 30000) == null) { close(); return false }
            return true
        } catch (e: Exception) {
            close()
            return false
        }
    }

    /** Melhor lance (ex.: "e2e4", "e7e8q") pra posição FEN, ou null se não deu. */
    @Synchronized
    fun bestMove(fen: String, moveTimeMs: Int): String? {
        if (!ensureStarted()) return null
        try {
            send("position fen $fen")
            send("go movetime $moveTimeMs")
            val line = readUntil("bestmove", moveTimeMs + 5000L)
            if (line == null) { close(); return null }
            val mv = line.split(" ").getOrNull(1)
            return if (mv == null || mv == "(none)" || mv.length < 4) null else mv
        } catch (e: Exception) {
            close()
            return null
        }
    }

    /** Mata o processo sem esperar (pode ser chamado de qualquer thread). */
    fun kill() {
        proc?.destroyForcibly()
    }

    @Synchronized
    fun close() {
        try { out?.write("quit\n"); out?.flush() } catch (e: Exception) { }
        proc?.destroyForcibly()
        proc = null
        out = null
        inp = null
    }
}
