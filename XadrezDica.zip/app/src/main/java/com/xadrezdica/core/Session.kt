package com.xadrezdica.core

import kotlin.math.abs

/**
 * Cérebro do app: recebe os pixels do tabuleiro a cada "tick" e decide
 * (a) quando calibrar com as peças da skin atual,
 * (b) qual lance foi jogado (pelas regras do xadrez),
 * (c) quando pedir uma dica ao Stockfish.
 *
 * Não presume nada sobre a cor das peças: só separa "peças de baixo" (jogador) de "peças de cima"
 * (adversário). Quem é branco e quem é preto é descoberto pelo 1º lance (as brancas sempre começam).
 * Não depende do Android.
 */
class Session {
    class Out(val message: String? = null, val requestFen: String? = null, val clearHint: Boolean = false)

    /**
     * moverGroup: -1 = ainda ninguém jogou; 0 = o lado de baixo já jogou o 1º lance; 1 = o de cima jogou.
     * gp = peças por grupo no tabuleiro canônico (jogador embaixo). placeA/placeB = posição na orientação
     * "jogador = brancas" / "jogador = pretas".
     */
    private class StartMatch(
        val moverGroup: Int, val gp: IntArray,
        val placeA: IntArray?, val placeB: IntArray?, val epA: Int, val epB: Int,
        val priorMeWhite: Boolean, val confident: Boolean
    )

    val analyzer = BoardAnalyzer()
    var templates: Templates? = null
        private set
    private var trackers: List<Tracker> = emptyList()
    private var confident = true
    var forceRecal = false

    /** Hipótese principal da partida (a primeira da lista). */
    val tracker: Tracker? get() = trackers.firstOrNull()
    val meWhite: Boolean get() = trackers.firstOrNull()?.meWhite ?: true

    // Quem joga de pretas vê o tabuleiro espelhado (rei à ESQUERDA da dama). Guardamos o quadro do começo
    // pra remontar os moldes das peças quando descobrimos a cor.
    private var calibFeats: Array<CellFeat>? = null
    private var calibGp: IntArray? = null
    private var tplBlackLayout = false

    private var lastHash = 0
    private var lastFeats: Array<CellFeat>? = null
    private var lastGrp: IntArray? = null
    private var stable = 0
    private var startStable = 0
    private var unexplained = 0
    private var tentative = false      // posição "adivinhada" numa ressincronização: sem dicas até um lance ser explicado
    private var pendingHint = false    // pedir dica só depois que a tela ficou parada alguns instantes

    /** FEN pra pedir dica agora, ou null se não for a sua vez / ainda não sei sua cor. */
    fun hintFen(): String? {
        val tr = tracker ?: return null
        if (!tr.myTurn()) return null
        if (trackers.size > 1 && !confident) return null
        if (tentative) return null
        return tr.fen()
    }

    fun tick(pix: IntArray, stride: Int, cell: Double): Out {
        val h = pix.contentHashCode()
        var feats: Array<CellFeat> = lastFeats ?: analyzer.analyzeAll(pix, stride, cell).also { lastFeats = it; lastHash = h }
        if (h != lastHash) {
            feats = analyzer.analyzeAll(pix, stride, cell)
            lastFeats = feats
            lastHash = h
        }

        var sm = matchStart(feats)
        // Skin de pouco contraste? Se estamos esperando o início, tenta limiares mais sensíveis/menos sensíveis.
        if (sm == null && (trackers.isEmpty() || unexplained >= 3)) {
            val keep = analyzer.bgDist2
            for (t in intArrayOf(30, 20, 60, 80, 45)) {
                if (t * t == keep) continue
                analyzer.bgDist2 = t * t
                val f2 = analyzer.analyzeAll(pix, stride, cell)
                val s2 = matchStart(f2)
                if (s2 != null) { feats = f2; lastFeats = f2; sm = s2; break }
            }
            if (sm == null) analyzer.bgDist2 = keep
        }
        if (sm != null) {
            val needCal = templates == null || trackers.isEmpty() || forceRecal || trackers.none { placementMatches(it, sm!!) }
            if (needCal) {
                startStable++
                return if (startStable >= 2) {
                    startStable = 0
                    calibrate(feats, sm)
                } else Out()
            }
        } else {
            startStable = 0
        }

        val tpl = templates
        if (tpl == null || trackers.isEmpty()) return Out(message = "Aguardando a posição inicial da partida...")

        // O que a tela mostra, casa por casa: vazia, peça do grupo de baixo (0) ou do de cima (1)
        val grp = IntArray(64)
        for (i in 0 until 64) {
            val f = feats[i]
            grp[i] = if (!f.occupied) -1 else analyzer.colorOf(f, tpl)
        }
        val lg = lastGrp
        if (lg != null && lg.contentEquals(grp)) stable++ else { stable = 0; lastGrp = grp }
        if (stable < 2) return Out()       // a tela precisa ficar igual por ~0,4 s (ignora animação / peça arrastada)

        val feat = feats
        val deep = unexplained >= 6 && unexplained % 4 == 2     // 3 lances é caro: só de vez em quando
        val lookBack = unexplained % 3 == 0
        val results = ArrayList<Pair<Tracker, Tracker.Result>>()
        val obsOf = HashMap<Tracker, IntArray>()
        for (tr in trackers) {
            val obs = IntArray(64) { -1 }
            for (r in 0..7) for (c in 0..7) {
                val g = grp[r * 8 + c]
                if (g >= 0) obs[squareOf(r, c, tr.meWhite)] = if (tr.meWhite) g else 1 - g
            }
            obsOf[tr] = obs
            val res = tr.update(obs, deep, lookBack) { sq, code ->
                val group = if (tr.meWhite) code / 6 else 1 - code / 6
                analyzer.similarity(feat[rowOf(sq, tr.meWhite) * 8 + colOf(sq, tr.meWhite)], tpl, group * 6 + code % 6)
            }
            results.add(tr to res)
        }

        val explained = results.filter { it.second != Tracker.Result.UNEXPLAINED }
        if (explained.isEmpty()) {
            unexplained++
            pendingHint = false
            if (unexplained == 1) return Out(clearHint = true)          // a tela mudou e não bate com a posição: a dica antiga não vale mais
            if (unexplained == 10) return Out(message = "Não entendi a mudança no tabuleiro (peça arrastada? animação? popup?). Aguardando...")
            if (unexplained >= 40) {       // ~8 s sem entender a tela: tenta reconstruir pela leitura das peças
                unexplained = 0
                return resync(feat, tpl, trackers[0], obsOf[trackers[0]]!!)
            }
            return Out()
        }
        unexplained = 0
        val changed = explained.filter { it.second == Tracker.Result.CHANGED }
        if (changed.isEmpty()) {
            // nada mudou: se falta pedir a dica, pede agora que a tela está parada
            if (pendingHint && stable >= 3) {
                pendingHint = false
                hintFen()?.let { return Out(requestFen = it) }
            }
            return Out()
        }
        // Só ficam as hipóteses que explicaram a tela (resolve "qual é a minha cor" no 1º lance)
        val keepList = explained.map { it.first }
        if (keepList.size < trackers.size) {
            trackers = keepList
            confident = true
            // descobriu que joga de pretas: remonta os moldes com rei/dama do jeito certo
            if (!trackers[0].meWhite && !tplBlackLayout) {
                val cf = calibFeats
                val gp = calibGp
                if (cf != null && gp != null) {
                    analyzer.buildTemplates(cf, swapKQ(gp))?.let { templates = it; tplBlackLayout = true }
                }
            }
        }
        tentative = false            // um lance foi explicado pelas regras: a posição é confiável de novo
        pendingHint = true
        val tr = trackers[0]
        return Out(clearHint = true, message = if (tr.myTurn()) "Sua vez" else "Vez do adversário")
    }

    private fun placementMatches(tr: Tracker, sm: StartMatch): Boolean = when (sm.moverGroup) {
        0 -> tr.meWhite && sm.placeA != null && tr.placementEquals(sm.placeA)
        1 -> !tr.meWhite && sm.placeB != null && tr.placementEquals(sm.placeB)
        else -> tr.placementEquals(initialPlacement())
    }

    private fun resync(feats: Array<CellFeat>, tpl: Templates, tr: Tracker, obs: IntArray): Out {
        val b = analyzer.classifyBoard(feats, tpl, tr.meWhite, obs)
            ?: return Out(message = "Não consegui ler o tabuleiro (algo na frente?)")
        val hl = turnFromHighlight(feats, obs, tr.meWhite)
        val turns = if (hl != null) listOf(hl) else listOf(true, false)
        for (white in turns) {
            val p = Position(
                b, white,
                b[4] == 5 && b[7] == 3, b[4] == 5 && b[0] == 3,
                b[60] == 11 && b[63] == 9, b[60] == 11 && b[56] == 9, -1
            )
            if (FenCheck.problem(p.fen()) == null) {
                tr.reset(p)
                trackers = listOf(tr)
                confident = true
                tentative = true         // palpite pelo desenho das peças: só volta a dar dica depois de um lance explicado
                pendingHint = false
                return Out(message = "Ressincronizado (palpite). Sem dica até o próximo lance.", clearHint = true)
            }
        }
        return Out(message = "Perdi o fio da partida. Comece/reinicie a partida pra recalibrar.")
    }

    private fun calibrate(feats: Array<CellFeat>, sm: StartMatch): Out {
        val blackLayout = sm.moverGroup == 1          // o lado de cima jogou primeiro => quem está embaixo joga de pretas
        val tpl = analyzer.buildTemplates(feats, if (blackLayout) swapKQ(sm.gp) else sm.gp)
            ?: return Out(message = "Não consegui calibrar (peças dos dois lados muito parecidas?)")
        templates = tpl
        calibFeats = feats
        calibGp = sm.gp
        tplBlackLayout = blackLayout
        forceRecal = false
        tentative = false
        pendingHint = false
        lastGrp = null
        stable = 0
        unexplained = 0
        confident = sm.confident
        when (sm.moverGroup) {
            0 -> trackers = listOf(Tracker(Position(sm.placeA!!, false, true, true, true, true, sm.epA), true))
            1 -> trackers = listOf(Tracker(Position(sm.placeB!!, false, true, true, true, true, sm.epB), false))
            else -> {
                val a = Tracker(Position.start(), true)     // eu sou as brancas
                val b = Tracker(Position.start(), false)    // eu sou as pretas
                trackers = if (sm.priorMeWhite) listOf(a, b) else listOf(b, a)
                confident = sm.confident
            }
        }
        val tr = trackers[0]
        val lado = if (tr.meWhite) "brancas" else "pretas"
        val single = trackers.size == 1
        val fen = hintFen()
        return when {
            fen != null -> Out(message = "Calibrado — você joga de $lado. Sua vez", requestFen = fen, clearHint = true)
            single -> Out(message = "Calibrado — você joga de $lado. Vez do adversário", clearHint = true)
            else -> Out(message = "Calibrado — aguardando o 1º lance pra saber sua cor", clearHint = true)
        }
    }

    /** Casa destacada em amarelo (último lance) com peça em cima: a cor dela diz quem jogou por último. */
    private fun turnFromHighlight(feats: Array<CellFeat>, obs: IntArray, meWhite: Boolean): Boolean? {
        for (r in 0..7) for (c in 0..7) {
            val f = feats[r * 8 + c]
            if (!f.occupied) continue
            if (f.bgR > 200 && f.bgG in 140..235 && f.bgB < 120 && f.bgR - f.bgB > 110) {
                val o = obs[squareOf(r, c, meWhite)]
                if (o >= 0) return o == 1      // preta moveu por último -> vez das brancas
            }
        }
        return null
    }

    /** Casa (linha, coluna) -> posição na tela, pra desenhar a bolinha. */
    fun rowOfSquare(sq: Int) = rowOf(sq, meWhite)
    fun colOfSquare(sq: Int) = colOf(sq, meWhite)

    /** Troca rei e dama no mapa de peças (layout de quem joga de pretas: R N B K Q B N R). */
    private fun swapKQ(gp: IntArray): IntArray {
        val o = gp.copyOf()
        o[3] = gp[4]; o[4] = gp[3]
        o[59] = gp[60]; o[60] = gp[59]
        return o
    }

    private fun matchStart(feats: Array<CellFeat>): StartMatch? {
        // ocupação no tabuleiro canônico (jogador embaixo): casa = squareOf(linha, coluna, true)
        val occ = BooleanArray(64)
        var topN = 0
        var botN = 0
        var topL = 0.0
        var botL = 0.0
        for (r in 0..7) for (c in 0..7) {
            val f = feats[r * 8 + c]
            occ[squareOf(r, c, true)] = f.occupied
            if (!f.occupied) continue
            val lum = f.r * 0.3 + f.g * 0.59 + f.b * 0.11
            if (r < 4) { topN++; topL += lum } else { botN++; botL += lum }
        }
        if (topN < 15 || botN < 15 || topN > 16 || botN > 16) return null
        topL /= topN; botL /= botN

        val start = initialPlacement()      // brancas (grupo 0) embaixo, nas casas 0..15; pretas em cima
        val gone = ArrayList<Int>()
        val appeared = ArrayList<Int>()
        for (s in 0 until 64) {
            if (start[s] >= 0 && !occ[s]) gone.add(s)
            if (start[s] < 0 && occ[s]) appeared.add(s)
        }
        val gp = IntArray(64) { if (start[it] < 0) -1 else (if (it < 32) 0 else 1) * 6 + start[it] % 6 }

        // Quem é as brancas? Pelo brilho do adversário (peças de cima) e, se ajudar, pela diferença entre os lados.
        val oppWhite = topL > 120
        val priorMeWhite = !oppWhite
        val byDiff = abs(topL - botL) >= 40 && ((botL > topL) == priorMeWhite)
        val conf = byDiff

        if (gone.isEmpty() && appeared.isEmpty()) {
            return StartMatch(-1, gp, null, null, -1, -1, priorMeWhite, conf)
        }
        if (gone.size == 1 && appeared.size == 1) {
            val g = gone[0]
            val a = appeared[0]
            val mover = if (g < 16) 0 else 1                    // 0 = lado de baixo, 1 = lado de cima
            val gg = if (mover == 0) g else 63 - g              // põe o lance na visão "quem joga está embaixo, avançando pra cima"
            val aa = if (mover == 0) a else 63 - a
            val piece = start[gg]
            val dx = abs(aa % 8 - gg % 8)
            val dy = aa / 8 - gg / 8
            val ok = when (piece % 6) {
                PAWN -> dx == 0 && (dy == 1 || dy == 2)
                KNIGHT -> (dx == 1 && abs(dy) == 2) || (dx == 2 && abs(dy) == 1)
                else -> false
            }
            if (!ok) return null
            val pl = start.copyOf()
            pl[gg] = -1
            pl[aa] = piece
            val dbl = piece % 6 == PAWN && dy == 2
            val ep = if (dbl) (gg + aa) / 2 else -1
            val g2 = gp.copyOf()
            g2[a] = g2[g]
            g2[g] = -1
            return if (mover == 0) StartMatch(0, g2, pl, null, ep, -1, true, true)
            else StartMatch(1, g2, null, pl, -1, ep, false, true)
        }
        return null
    }
}
