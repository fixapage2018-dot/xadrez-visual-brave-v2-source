package com.xadrezdica.core

import kotlin.math.abs

/**
 * Cérebro do app: recebe os pixels do tabuleiro a cada "tick" e decide
 * (a) quando calibrar com as peças da skin atual,
 * (b) qual lance foi jogado,
 * (c) quando pedir uma dica ao Stockfish.
 * Também não depende do Android.
 */
class Session {
    class Out(val message: String? = null, val requestFen: String? = null, val clearHint: Boolean = false)

    private class StartMatch(val meWhite: Boolean, val placement: IntArray, val whiteJustMoved: Boolean,
                             val epRaw: Int, val epPushed: Int)

    val analyzer = BoardAnalyzer()
    var templates: Templates? = null
        private set
    var tracker: Tracker? = null
        private set
    var meWhite = true
        private set
    var forceRecal = false

    private var lastHash = 0
    private var lastFeats: Array<CellFeat>? = null
    private var lastCur: IntArray? = null
    private var stable = 0
    private var startStable = 0
    private var ignored = 0

    fun tick(pix: IntArray, stride: Int, cell: Double): Out {
        val h = pix.contentHashCode()
        var feats = lastFeats
        if (feats == null || h != lastHash) {
            feats = analyzer.analyzeAll(pix, stride, cell)
            lastFeats = feats
            lastHash = h
        }

        // Posição inicial (ou inicial + 1 lance das brancas, caso você jogue de pretas)?
        val sm = matchStart(feats)
        val tr0 = tracker
        if (sm != null) {
            val needCal = templates == null || tr0 == null || forceRecal || !tr0.placementEquals(sm.placement)
            if (needCal) {
                startStable++
                return if (startStable >= 2) {
                    startStable = 0
                    calibrate(feats, sm)
                } else Out()
            }
        } else {
            startStable = 0
        }

        val tpl = templates
        val tr = tracker
        if (tpl == null || tr == null) {
            return Out(message = "Aguardando a posição inicial da partida...")
        }

        val cur = IntArray(64)
        for (r in 0..7) for (c in 0..7) {
            val code = analyzer.classify(feats[r * 8 + c], tpl)
            if (code == -2) { stable = 0; return Out() }
            cur[squareOf(r, c, meWhite)] = code
        }
        val lc = lastCur
        if (lc != null && lc.contentEquals(cur)) {
            stable++
        } else {
            stable = 0
            lastCur = cur
        }
        if (stable < 1) return Out()
        if (cur.contentEquals(tr.placement)) { ignored = 0; return Out() }

        val hl = turnFromHighlight(feats, cur)
        return when (tr.update(cur, hl)) {
            Tracker.Result.SAME -> Out()
            Tracker.Result.CHANGED -> {
                ignored = 0
                if (tr.myTurn() == true) Out(requestFen = tr.fen(), clearHint = true, message = "Sua vez")
                else Out(clearHint = true, message = "Vez do adversário")
            }
            Tracker.Result.IGNORED -> {
                ignored++
                if (ignored >= 25) {      // ~5 s sem conseguir explicar a mudança: ressincroniza
                    ignored = 0
                    tr.resync(cur, hl)
                    if (tr.myTurn() == true) Out(requestFen = tr.fen(), clearHint = true, message = "Ressincronizado — sua vez")
                    else Out(clearHint = true, message = "Ressincronizado")
                } else Out()
            }
        }
    }

    private fun calibrate(feats: Array<CellFeat>, sm: StartMatch): Out {
        val tpl = analyzer.buildTemplates(feats, sm.meWhite, sm.placement)
            ?: return Out(message = "Não consegui calibrar (peças das duas cores muito parecidas?)")
        templates = tpl
        meWhite = sm.meWhite
        val tr = Tracker(sm.placement, !sm.whiteJustMoved, sm.meWhite, sm.epRaw, sm.epPushed)
        tracker = tr
        lastCur = null
        stable = 0
        ignored = 0
        forceRecal = false
        val lado = if (sm.meWhite) "brancas" else "pretas"
        return if (tr.myTurn() == true)
            Out(message = "Calibrado — você joga de $lado. Sua vez", requestFen = tr.fen(), clearHint = true)
        else
            Out(message = "Calibrado — você joga de $lado. Vez do adversário", clearHint = true)
    }

    /** Casa destacada em amarelo (último lance) com peça em cima: a cor dela diz quem jogou por último. */
    private fun turnFromHighlight(feats: Array<CellFeat>, cur: IntArray): Boolean? {
        for (r in 0..7) for (c in 0..7) {
            val f = feats[r * 8 + c]
            if (!f.occupied) continue
            if (f.bgR > 200 && f.bgG in 140..235 && f.bgB < 120 && f.bgR - f.bgB > 110) {
                val code = cur[squareOf(r, c, meWhite)]
                if (code >= 0) return code / 6 == 1     // preta moveu por último -> vez das brancas
            }
        }
        return null
    }

    /** Casa (linha, coluna) -> posição na tela, pra desenhar a bolinha. */
    fun rowOfSquare(sq: Int) = rowOf(sq, meWhite)
    fun colOfSquare(sq: Int) = colOf(sq, meWhite)

    private fun matchStart(feats: Array<CellFeat>): StartMatch? {
        var topL = 0.0; var topN = 0; var botL = 0.0; var botN = 0
        for (r in 0..7) for (c in 0..7) {
            val f = feats[r * 8 + c]
            if (!f.occupied) continue
            val lum = f.r * 0.3 + f.g * 0.59 + f.b * 0.11
            if (r < 4) { topL += lum; topN++ } else { botL += lum; botN++ }
        }
        if (topN < 15 || botN < 15 || topN > 16 || botN > 16) return null
        topL /= topN; botL /= botN
        if (abs(topL - botL) < 40) return null
        val mw = botL > topL

        val start = initialPlacement()
        val occ = BooleanArray(64)
        for (r in 0..7) for (c in 0..7) occ[squareOf(r, c, mw)] = feats[r * 8 + c].occupied
        val gone = ArrayList<Int>()
        val appeared = ArrayList<Int>()
        for (s in 0 until 64) {
            if (start[s] >= 0 && !occ[s]) gone.add(s)
            if (start[s] < 0 && occ[s]) appeared.add(s)
        }
        if (gone.isEmpty() && appeared.isEmpty()) return StartMatch(mw, start, false, -1, -1)
        if (gone.size == 1 && appeared.size == 1) {
            val a = gone[0]
            val b = appeared[0]
            val piece = start[a]
            if (piece / 6 != 0) return null                       // só as brancas podem ter jogado
            val dx = abs(b % 8 - a % 8)
            val dy = b / 8 - a / 8
            val ok = when (piece % 6) {
                PAWN -> dx == 0 && (dy == 1 || dy == 2)
                KNIGHT -> (dx == 1 && abs(dy) == 2) || (dx == 2 && abs(dy) == 1)
                else -> false
            }
            if (!ok) return null
            val pl = start.copyOf()
            pl[a] = -1
            pl[b] = piece
            val dbl = piece % 6 == PAWN && dy == 2
            return StartMatch(mw, pl, true, if (dbl) (a + b) / 2 else -1, if (dbl) b else -1)
        }
        return null
    }
}
