package com.xadrezdica.core

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** O que o app enxerga numa casa do tabuleiro. */
class CellFeat(
    val occupied: Boolean,
    val mask: BooleanArray?,          // silhueta M x M (só se ocupada)
    val r: Float, val g: Float, val b: Float,   // cor média do miolo da peça
    val bgR: Int, val bgG: Int, val bgB: Int    // cor de fundo da casa
)

/** Silhuetas (12) e cor média das peças das duas cores (RGB), aprendidas da skin atual. */
class Templates(val masks: Array<BooleanArray>, val rgb: Array<FloatArray>)

/**
 * Lê as 64 casas a partir dos pixels (RGB empacotado em Int) do tabuleiro.
 * Não usa nada do Android: roda igual no celular e no PC (por isso dá pra testar).
 */
class BoardAnalyzer {
    companion object {
        const val M = 40
        const val BG_DIST2 = 45 * 45
        const val BASE_CELL = 130.5
        const val MIN_IOU = 0.45
    }

    private var cs = 0
    private var mask = BooleanArray(0)
    private var tmpA = BooleanArray(0)
    private var tmpB = BooleanArray(0)
    private var reach = BooleanArray(0)
    private var integral = IntArray(0)
    private var queue = IntArray(0)
    private var qt = 0
    private val hr = IntArray(256)
    private val hg = IntArray(256)
    private val hb = IntArray(256)
    private val votes = IntArray(M * M)

    private fun ensure(size: Int) {
        if (size == cs) return
        cs = size
        mask = BooleanArray(size * size)
        tmpA = BooleanArray(size * size)
        tmpB = BooleanArray(size * size)
        reach = BooleanArray(size * size)
        queue = IntArray(size * size)
        integral = IntArray((size + 1) * (size + 1))
    }

    fun analyzeAll(pix: IntArray, stride: Int, cell: Double): Array<CellFeat> {
        ensure(cell.toInt())
        return Array(64) { i ->
            val ox = ((i % 8) * cell).roundToInt()
            val oy = ((i / 8) * cell).roundToInt()
            analyzeCell(pix, stride, ox, oy)
        }
    }

    private fun addPix(p: Int) {
        hr[(p shr 16) and 255]++
        hg[(p shr 8) and 255]++
        hb[p and 255]++
    }

    private fun median(h: IntArray, total: Int): Int {
        var acc = 0
        val half = (total + 1) / 2
        for (v in 0..255) {
            acc += h[v]
            if (acc >= half) return v
        }
        return 255
    }

    private fun seed(i: Int) {
        if (!mask[i] && !reach[i]) {
            reach[i] = true
            queue[qt++] = i
        }
    }

    /** erosão (erode=true) ou dilatação de caixa (2r+1)x(2r+1), via imagem integral. */
    private fun boxFilter(src: BooleanArray, dst: BooleanArray, r: Int, erode: Boolean) {
        val n = cs
        val w = n + 1
        for (x in 0..n) integral[x] = 0
        for (y in 0 until n) {
            var rowSum = 0
            integral[(y + 1) * w] = 0
            for (x in 0 until n) {
                if (src[y * n + x]) rowSum++
                integral[(y + 1) * w + x + 1] = integral[y * w + x + 1] + rowSum
            }
        }
        for (y in 0 until n) {
            val y0 = max(0, y - r)
            val y1 = min(n - 1, y + r)
            for (x in 0 until n) {
                val x0 = max(0, x - r)
                val x1 = min(n - 1, x + r)
                val s = integral[(y1 + 1) * w + x1 + 1] - integral[y0 * w + x1 + 1] -
                    integral[(y1 + 1) * w + x0] + integral[y0 * w + x0]
                dst[y * n + x] = if (erode) s == (y1 - y0 + 1) * (x1 - x0 + 1) else s > 0
            }
        }
    }

    private fun analyzeCell(pix: IntArray, stride: Int, ox: Int, oy: Int): CellFeat {
        val n = cs
        val sc = n / BASE_CELL

        // 1) cor de fundo = mediana da moldura da casa (funciona com casa destacada de amarelo)
        java.util.Arrays.fill(hr, 0)
        java.util.Arrays.fill(hg, 0)
        java.util.Arrays.fill(hb, 0)
        val ring = max(2, (4 * sc).roundToInt())
        var cnt = 0
        for (y in 0 until n) {
            val row = (oy + y) * stride + ox
            if (y < ring || y >= n - ring) {
                for (x in 0 until n) { addPix(pix[row + x]); cnt++ }
            } else {
                for (x in 0 until ring) { addPix(pix[row + x]); cnt++ }
                for (x in n - ring until n) { addPix(pix[row + x]); cnt++ }
            }
        }
        val bgR = median(hr, cnt)
        val bgG = median(hg, cnt)
        val bgB = median(hb, cnt)

        // 2) máscara = o que difere do fundo (ignora cantos: número da linha, letra da coluna e onde ficam as bolinhas)
        val tl = (0.27 * n).toInt()
        val brStart = n - (0.31 * n).toInt()
        val trSize = (0.37 * n).toInt()
        val trStart = n - trSize
        for (y in 0 until n) {
            val row = (oy + y) * stride + ox
            for (x in 0 until n) {
                val p = pix[row + x]
                val dr = ((p shr 16) and 255) - bgR
                val dg = ((p shr 8) and 255) - bgG
                val db = (p and 255) - bgB
                var m = dr * dr + dg * dg + db * db > BG_DIST2
                if (m) {
                    if (y < tl && x < tl) m = false
                    else if (y >= brStart && x >= brStart) m = false
                    else if (y < trSize && x >= trStart) m = false
                }
                mask[y * n + x] = m
            }
        }
        boxFilter(mask, tmpA, 1, true)
        boxFilter(tmpA, mask, 1, false)

        // 3) preenche a silhueta (tudo que não é "fundo alcançável pela borda")
        java.util.Arrays.fill(reach, false)
        qt = 0
        for (x in 0 until n) { seed(x); seed((n - 1) * n + x) }
        for (y in 0 until n) { seed(y * n); seed(y * n + n - 1) }
        var qh = 0
        while (qh < qt) {
            val i = queue[qh++]
            val x = i % n
            val y = i / n
            if (x > 0) seed(i - 1)
            if (x < n - 1) seed(i + 1)
            if (y > 0) seed(i - n)
            if (y < n - 1) seed(i + n)
        }
        var area = 0
        for (i in 0 until n * n) {
            val f = !reach[i]
            tmpA[i] = f
            if (f) area++
        }
        val minArea = (600 * sc * sc).toInt()
        if (area < minArea) return CellFeat(false, null, 0f, 0f, 0f, bgR, bgG, bgB)

        // 4) cor média do miolo (sem a borda preta do contorno)
        boxFilter(tmpA, tmpB, max(1, (6 * sc).roundToInt()), true)
        var sr = 0L; var sg = 0L; var sb = 0L; var k = 0
        for (y in 0 until n) {
            val row = (oy + y) * stride + ox
            for (x in 0 until n) {
                if (tmpB[y * n + x]) {
                    val p = pix[row + x]
                    sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255; k++
                }
            }
        }
        if (k == 0) {
            for (y in 0 until n) {
                val row = (oy + y) * stride + ox
                for (x in 0 until n) {
                    if (tmpA[y * n + x]) {
                        val p = pix[row + x]
                        sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255; k++
                    }
                }
            }
        }

        // 5) silhueta reduzida pra M x M
        java.util.Arrays.fill(votes, 0)
        for (y in 0 until n) {
            val ty = y * M / n
            for (x in 0 until n) {
                if (tmpA[y * n + x]) votes[ty * M + x * M / n]++
            }
        }
        val block = (n.toDouble() / M) * (n.toDouble() / M)
        val small = BooleanArray(M * M) { votes[it] > block / 2 }
        return CellFeat(true, small, sr.toFloat() / k, sg.toFloat() / k, sb.toFloat() / k, bgR, bgG, bgB)
    }

    /**
     * Aprende as silhuetas e as cores das duas cores de peça a partir de uma posição conhecida
     * (a inicial, ou a inicial + 1 lance das brancas). feats = 64 casas na ordem (linha*8+coluna) da tela.
     */
    fun buildTemplates(feats: Array<CellFeat>, meWhite: Boolean, placement: IntArray): Templates? {
        val counts = Array(12) { IntArray(M * M) }
        val nPieces = IntArray(12)
        val sum = Array(2) { DoubleArray(3) }
        val nCol = IntArray(2)
        for (row in 0..7) for (col in 0..7) {
            val code = placement[squareOf(row, col, meWhite)]
            if (code < 0) continue
            val f = feats[row * 8 + col]
            val m = f.mask ?: return null
            for (i in 0 until M * M) if (m[i]) counts[code][i]++
            nPieces[code]++
            val color = code / 6
            sum[color][0] += f.r.toDouble(); sum[color][1] += f.g.toDouble(); sum[color][2] += f.b.toDouble()
            nCol[color]++
        }
        for (c in 0..11) if (nPieces[c] == 0) return null
        val rgb = Array(2) { c -> FloatArray(3) { (sum[c][it] / nCol[c]).toFloat() } }
        val d = (rgb[0][0] - rgb[1][0]).let { it * it } + (rgb[0][1] - rgb[1][1]).let { it * it } +
            (rgb[0][2] - rgb[1][2]).let { it * it }
        if (d < 60f * 60f) return null   // cores das duas equipes parecidas demais
        val masks = Array(12) { c -> BooleanArray(M * M) { counts[c][it] * 2 > nPieces[c] } }
        return Templates(masks, rgb)
    }

    /** -1 = vazia, -2 = leitura duvidosa (peça no meio de animação, popup em cima etc.), senão o código da peça. */
    fun classify(f: CellFeat, t: Templates): Int {
        if (!f.occupied) return -1
        val m = f.mask ?: return -2
        val d0 = sq(f.r - t.rgb[0][0]) + sq(f.g - t.rgb[0][1]) + sq(f.b - t.rgb[0][2])
        val d1 = sq(f.r - t.rgb[1][0]) + sq(f.g - t.rgb[1][1]) + sq(f.b - t.rgb[1][2])
        val color = if (d0 <= d1) 0 else 1
        var best = -1
        var bestIou = -1.0
        for (type in 0..5) {
            val tm = t.masks[color * 6 + type]
            var inter = 0
            var union = 0
            for (i in 0 until M * M) {
                val a = m[i]
                val b = tm[i]
                if (a && b) inter++
                if (a || b) union++
            }
            val iou = inter.toDouble() / max(1, union)
            if (iou > bestIou) { bestIou = iou; best = type }
        }
        return if (bestIou < MIN_IOU) -2 else color * 6 + best
    }

    /** 0 = peça da cor branca, 1 = da cor preta (pela cor média da peça; muito mais confiável que o formato). */
    fun colorOf(f: CellFeat, t: Templates): Int {
        val d0 = sq(f.r - t.rgb[0][0]) + sq(f.g - t.rgb[0][1]) + sq(f.b - t.rgb[0][2])
        val d1 = sq(f.r - t.rgb[1][0]) + sq(f.g - t.rgb[1][1]) + sq(f.b - t.rgb[1][2])
        return if (d0 <= d1) 0 else 1
    }

    /** Semelhança (0..1) do formato da casa com o da peça [code]. Só desempata e escolhe a promoção. */
    fun similarity(f: CellFeat, t: Templates, code: Int): Double {
        val m = f.mask ?: return 0.0
        val tm = t.masks[code]
        var inter = 0
        var union = 0
        for (i in 0 until M * M) {
            val a = m[i]
            val b = tm[i]
            if (a && b) inter++
            if (a || b) union++
        }
        return inter.toDouble() / max(1, union)
    }

    private fun sq(v: Float) = v * v
}
