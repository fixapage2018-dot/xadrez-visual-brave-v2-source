package com.xadrezdica.core

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** O que o app enxerga numa casa do tabuleiro. */
class CellFeat(
    val occupied: Boolean,
    val mask: BooleanArray?,          // silhueta M x M (só se ocupada)
    val r: Float, val g: Float, val b: Float,   // cor média do miolo da peça
    val bgR: Int, val bgG: Int, val bgB: Int    // cor de fundo da casa
)

/** Silhuetas (12) e cor média das peças das duas cores (RGB), aprendidas da skin atual. */
class Templates(val masks: Array<BooleanArray>, val rgb: Array<FloatArray>)

/**
 * Lê as 64 casas a partir dos pixels (RGB empacotado em Int) do tabuleiro.
 * Não usa nada do Android: roda igual no celular e no PC (por isso dá pra testar).
 */
class BoardAnalyzer {
    companion object {
        const val M = 40
        const val BASE_CELL = 130.5
        const val MIN_IOU = 0.45
    }

    /** Quão diferente do fundo um pixel precisa ser pra contar como peça (ao quadrado). Ajustável por skin. */
    var bgDist2 = 45 * 45
    private var cs = 0
    private var mask = BooleanArray(0)
    private var tmpA = BooleanArray(0)
    private var tmpB = BooleanArray(0)
    private var reach = BooleanArray(0)
    private var integral = IntArray(0)
    private var queue = IntArray(0)
    private var qt = 0
    private val hr = IntArray(256)
    private val hg = IntArray(256)
    private val hb = IntArray(256)
    private val votes = IntArray(M * M)

    private fun ensure(size: Int) {
        if (size == cs) return
        cs = size
        mask = BooleanArray(size * size)
        tmpA = BooleanArray(size * size)
        tmpB = BooleanArray(size * size)
        reach = BooleanArray(size * size)
        queue = IntArray(size * size)
        integral = IntArray((size + 1) * (size + 1))
    }

    fun analyzeAll(pix: IntArray, stride: Int, cell: Double): Array<CellFeat> {
        ensure(cell.toInt())
        return Array(64) { i ->
            val ox = ((i % 8) * cell).roundToInt()
            val oy = ((i / 8) * cell).roundToInt()
            analyzeCell(pix, stride, ox, oy)
        }
    }

    private fun addPix(p: Int) {
        hr[(p shr 16) and 255]++
        hg[(p shr 8) and 255]++
        hb[p and 255]++
    }

    private fun median(h: IntArray, total: Int): Int {
        var acc = 0
        val half = (total + 1) / 2
        for (v in 0..255) {
            acc += h[v]
            if (acc >= half) return v
        }
        return 255
    }

    private fun seed(i: Int) {
        if (!mask[i] && !reach[i]) {
            reach[i] = true
            queue[qt++] = i
        }
    }

    /** erosão (erode=true) ou dilatação de caixa (2r+1)x(2r+1), via imagem integral. */
    private fun boxFilter(src: BooleanArray, dst: BooleanArray, r: Int, erode: Boolean) {
        val n = cs
        val w = n + 1
        for (x in 0..n) integral[x] = 0
        for (y in 0 until n) {
            var rowSum = 0
            integral[(y + 1) * w] = 0
            for (x in 0 until n) {
                if (src[y * n + x]) rowSum++
                integral[(y + 1) * w + x + 1] = integral[y * w + x + 1] + rowSum
            }
        }
        for (y in 0 until n) {
            val y0 = max(0, y - r)
            val y1 = min(n - 1, y + r)
            for (x in 0 until n) {
                val x0 = max(0, x - r)
                val x1 = min(n - 1, x + r)
                val s = integral[(y1 + 1) * w + x1 + 1] - integral[y0 * w + x1 + 1] -
                    integral[(y1 + 1) * w + x0] + integral[y0 * w + x0]
                dst[y * n + x] = if (erode) s == (y1 - y0 + 1) * (x1 - x0 + 1) else s > 0
            }
        }
    }

    private fun analyzeCell(pix: IntArray, stride: Int, ox: Int, oy: Int): CellFeat {
        val n = cs
        val sc = n / BASE_CELL

        // 1) cor de fundo = mediana da moldura da casa (funciona com casa destacada de amarelo)
        java.util.Arrays.fill(hr, 0)
        java.util.Arrays.fill(hg, 0)
        java.util.Arrays.fill(hb, 0)
        val ring = max(2, (4 * sc).roundToInt())
        var cnt = 0
        for (y in 0 until n) {
            val row = (oy + y) * stride + ox
            if (y < ring || y >= n - ring) {
                for (x in 0 until n) { addPix(pix[row + x]); cnt++ }
            } else {
                for (x in 0 until ring) { addPix(pix[row + x]); cnt++ }
                for (x in n - ring until n) { addPix(pix[row + x]); cnt++ }
            }
        }
        val bgR = median(hr, cnt)
        val bgG = median(hg, cnt)
        val bgB = median(hb, cnt)

        // 2) máscara = o que difere do fundo (ignora cantos: número da linha, letra da coluna e onde ficam as bolinhas)
        val tl = (0.27 * n).toInt()
        val brStart = n - (0.31 * n).toInt()
        val trSize = (0.37 * n).toInt()
        val trStart = n - trSize
        for (y in 0 until n) {
            val row = (oy + y) * stride + ox
            for (x in 0 until n) {
                val p = pix[row + x]
                val dr = ((p shr 16) and 255) - bgR
                val dg = ((p shr 8) and 255) - bgG
                val db = (p and 255) - bgB
                var m = dr * dr + dg * dg + db * db > bgDist2
                if (m) {
                    if (y < tl && x < tl) m = false
                    else if (y >= brStart && x >= brStart) m = false
                    else if (y < trSize && x >= trStart) m = false
                }
                mask[y * n + x] = m
            }
        }
        // fecha falhas no contorno (traço fino/antialiasing): dilata 2px antes de preencher
        boxFilter(mask, tmpA, 2, false)
        System.arraycopy(tmpA, 0, mask, 0, n * n)

        // 3) preenche a silhueta (tudo que não é "fundo alcançável pela borda")
        java.util.Arrays.fill(reach, false)
        qt = 0
        for (x in 0 until n) { seed(x); seed((n - 1) * n + x) }
        for (y in 0 until n) { seed(y * n); seed(y * n + n - 1) }
        var qh = 0
        while (qh < qt) {
            val i = queue[qh++]
            val x = i % n
            val y = i / n
            if (x > 0) seed(i - 1)
            if (x < n - 1) seed(i + 1)
            if (y > 0) seed(i - n)
            if (y < n - 1) seed(i + n)
        }
        var area = 0
        for (i in 0 until n * n) {
            val f = !reach[i]
            tmpA[i] = f
            if (f) area++
        }
        // peça ocupa >= ~10% da casa; marcas de "casa possível" / bolinhas (~4%) não contam como peça
        val minArea = (0.10 * n * n).toInt()
        if (area < minArea) return CellFeat(false, null, 0f, 0f, 0f, bgR, bgG, bgB)

        // 4) cor média do miolo (sem a borda preta do contorno)
        boxFilter(tmpA, tmpB, max(1, (6 * sc).roundToInt()), true)
        var sr = 0L; var sg = 0L; var sb = 0L; var k = 0
        for (y in 0 until n) {
            val row = (oy + y) * stride + ox
            for (x in 0 until n) {
                if (tmpB[y * n + x]) {
                    val p = pix[row + x]
                    sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255; k++
                }
            }
        }
        if (k == 0) {
            for (y in 0 until n) {
                val row = (oy + y) * stride + ox
                for (x in 0 until n) {
                    if (tmpA[y * n + x]) {
                        val p = pix[row + x]
                        sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255; k++
                    }
                }
            }
        }

        // 5) silhueta reduzida pra M x M
        java.util.Arrays.fill(votes, 0)
        for (y in 0 until n) {
            val ty = y * M / n
            for (x in 0 until n) {
                if (tmpA[y * n + x]) votes[ty * M + x * M / n]++
            }
        }
        val block = (n.toDouble() / M) * (n.toDouble() / M)
        val small = BooleanArray(M * M) { votes[it] > block / 2 }
        return CellFeat(true, small, sr.toFloat() / k, sg.toFloat() / k, sb.toFloat() / k, bgR, bgG, bgB)
    }

    /**
     * Aprende as silhuetas e as cores a partir da posição inicial (ou inicial + 1 lance).
     * gp = peça de cada casa no tabuleiro "canônico" (jogador embaixo): código = grupo*6 + tipo,
     * grupo 0 = peças de baixo, grupo 1 = peças de cima. Não presume nada sobre branco/preto.
     */
    fun buildTemplates(feats: Array<CellFeat>, gp: IntArray): Templates? {
        val counts = Array(12) { IntArray(M * M) }
        val nPieces = IntArray(12)
        val sum = Array(2) { DoubleArray(3) }
        val nCol = IntArray(2)
        for (row in 0..7) for (col in 0..7) {
            val code = gp[squareOf(row, col, true)]
            if (code < 0) continue
            val f = feats[row * 8 + col]
            val m = f.mask ?: return null
            for (i in 0 until M * M) if (m[i]) counts[code][i]++
            nPieces[code]++
            val g = code / 6
            sum[g][0] += f.r.toDouble(); sum[g][1] += f.g.toDouble(); sum[g][2] += f.b.toDouble()
            nCol[g]++
        }
        for (c in 0..11) if (nPieces[c] == 0) return null
        val rgb = Array(2) { g -> FloatArray(3) { (sum[g][it] / nCol[g]).toFloat() } }
        val d = sq(rgb[0][0] - rgb[1][0]) + sq(rgb[0][1] - rgb[1][1]) + sq(rgb[0][2] - rgb[1][2])
        if (d < 30f * 30f) return null   // cores dos dois lados parecidas demais
        val masks = Array(12) { c -> BooleanArray(M * M) { counts[c][it] * 2 > nPieces[c] } }
        return Templates(masks, rgb)
    }

    /** Grupo da peça na casa: 0 = parece as peças de baixo (jogador), 1 = parece as de cima (adversário). Pela cor média. */
    fun colorOf(f: CellFeat, t: Templates): Int {
        val d0 = sq(f.r - t.rgb[0][0]) + sq(f.g - t.rgb[0][1]) + sq(f.b - t.rgb[0][2])
        val d1 = sq(f.r - t.rgb[1][0]) + sq(f.g - t.rgb[1][1]) + sq(f.b - t.rgb[1][2])
        return if (d0 <= d1) 0 else 1
    }

    /** Semelhança (0..1) do formato da casa com o da peça [code] (grupo*6+tipo). Só desempata e escolhe a promoção. */
    fun similarity(f: CellFeat, t: Templates, code: Int): Double {
        val m = f.mask ?: return 0.0
        val tm = t.masks[code]
        var inter = 0
        var union = 0
        for (i in 0 until M * M) {
            val a = m[i]
            val b = tm[i]
            if (a && b) inter++
            if (a || b) union++
        }
        return inter.toDouble() / max(1, union)
    }

    /**
     * Lê a posição inteira escolhendo o tipo de cada peça com as regras do xadrez como freio:
     * exatamente 1 rei por cor, no máximo 1 dama / 2 torres / 2 bispos / 2 cavalos / 8 peões (sem peão na 1a/8a fileira).
     * obs: -1 vazia, 0 branca, 1 preta (por casa, a1 = 0), na orientação meWhite. Devolve null se não der pra ler.
     */
    fun classifyBoard(feats: Array<CellFeat>, t: Templates, meWhite: Boolean, obs: IntArray): IntArray? {
        val out = IntArray(64) { -1 }
        for (color in 0..1) {
            val group = if (meWhite) color else 1 - color
            val sqs = (0 until 64).filter { obs[it] == color }
            if (sqs.isEmpty()) return null
            val score = HashMap<Int, DoubleArray>()
            for (sq in sqs) {
                val f = feats[rowOf(sq, meWhite) * 8 + colOf(sq, meWhite)]
                score[sq] = DoubleArray(6) { similarity(f, t, group * 6 + it) }
            }
            var king = -1
            var kBest = -1e9
            for (sq in sqs) {
                val sc = score[sq]!!
                var other = 0.0
                for (ty in 0..4) other = max(other, sc[ty])
                val m = sc[KING] - other
                if (m > kBest) { kBest = m; king = sq }
            }
            out[king] = color * 6 + KING
            val cap = intArrayOf(8, 2, 2, 2, 1, 0)
            val rest = sqs.filter { it != king }
            val order = rest.sortedByDescending { sq ->
                val sorted = (0..4).map { score[sq]!![it] }.sortedDescending()
                sorted[0] - sorted[1]
            }
            for (sq in order) {
                val sc = score[sq]!!
                val rank = sq / 8
                var placed = false
                for (ty in (0..4).sortedByDescending { sc[it] }) {
                    if (cap[ty] <= 0) continue
                    if (ty == PAWN && (rank == 0 || rank == 7)) continue
                    cap[ty]--
                    out[sq] = color * 6 + ty
                    placed = true
                    break
                }
                if (!placed) out[sq] = color * 6 + QUEEN
            }
        }
        return out
    }

    private fun sq(v: Float) = v * v
}
