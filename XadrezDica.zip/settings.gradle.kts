rootProject.name = "XadrezDica"
include(":app")
