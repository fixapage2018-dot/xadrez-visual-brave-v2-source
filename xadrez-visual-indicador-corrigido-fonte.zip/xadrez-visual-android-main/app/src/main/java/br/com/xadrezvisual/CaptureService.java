package br.com.xadrezvisual;
import android.app.*;import android.content.*;import android.content.pm.ServiceInfo;import android.content.res.Configuration;import android.graphics.*;import android.hardware.display.*;import android.media.*;import android.media.projection.*;import android.os.*;import android.view.*;import android.widget.*;import java.nio.*;import java.util.concurrent.*;
public class CaptureService extends Service {
 final Handler main=new Handler(Looper.getMainLooper());final ExecutorService worker=Executors.newSingleThreadExecutor();WindowManager wm;MediaProjection projection;ImageReader reader;VirtualDisplay display;Engine engine;Vision vision;android.content.SharedPreferences prefs;
 LinearLayout panel;TextView status;View selector;Ring ringA,ringB;WindowManager.LayoutParams panelParams;Rect region;Board board;boolean whiteBottom;volatile boolean active=false,stopped=false;boolean busy=false,selecting=false;int width,height,density,percent,stable=0;volatile int generation=0;String last="",suggestion="",analyzed="",rejected="";long retryAt=0;boolean calibrated=false;boolean snappedRegion=false;boolean compact=false;boolean detectingSide=false;int expandedWidth=0;
 final Runnable tick=new Runnable(){public void run(){if(stopped)return;if(active&&!busy&&!selecting&&region!=null){busy=true;final int gen=generation;main.postDelayed(()->{if(stopped)return;worker.execute(()->processFrame(gen));},90);}main.postDelayed(this,400);}};
 @Override public IBinder onBind(Intent i){return null;}
 @Override public int onStartCommand(Intent intent,int flags,int id){if(intent!=null&&"STOP".equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}if(projection!=null){whiteBottom=prefs.getBoolean("white",true);percent=prefs.getInt("percent",80);generation++;active=false;hideRings();analyzed="";suggestion="";setStatus("Configuração atualizada. Nova ou ▶ para continuar.");return START_NOT_STICKY;}
  prefs=getSharedPreferences("chess",0);wm=getSystemService(WindowManager.class);whiteBottom=prefs.getBoolean("white",true);percent=prefs.getInt("percent",80);
  NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("capture","Captura autorizada",NotificationManager.IMPORTANCE_LOW));PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,CaptureService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE);PendingIntent open=PendingIntent.getActivity(this,2,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(this,"capture").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("Xadrez Visual: captura ativa").setContentText("Análise local. Toque em Parar para encerrar.").setContentIntent(open).addAction(new Notification.Action.Builder(null,"Parar",stop).build()).setOngoing(true).build();startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
  try{if(intent==null||!intent.hasExtra("data"))throw new IllegalStateException("Autorize a captura novamente");android.util.DisplayMetrics metrics=new android.util.DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(metrics);width=metrics.widthPixels;height=metrics.heightPixels;density=metrics.densityDpi;
   try{board=new Board(prefs.getString("fen",Board.INITIAL));}catch(Exception e){board=new Board(Board.INITIAL);}
   reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,3);
   MediaProjectionManager manager=getSystemService(MediaProjectionManager.class);projection=manager.getMediaProjection(intent.getIntExtra("code",-1),intent.getParcelableExtra("data"));
   projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){setStatus("Captura encerrada pelo Android. Abra o app para iniciar novamente.");stopSelf();}@Override public void onCapturedContentResize(int w,int h){if(w!=width||h!=height){setStatus("Tamanho da tela mudou. Inicie a captura novamente.");stopSelf();}}},main);
   display=projection.createVirtualDisplay("XadrezVisual",width,height,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,main);
   makePanel();vision=new Vision(this);if(prefs.getInt("screenW",0)==width&&prefs.getInt("screenH",0)==height){int l=prefs.getInt("left",0),t=prefs.getInt("top",0),s=prefs.getInt("size",0);if(s>=160&&l>=0&&t>=0&&l+s<=width&&t+s<=height)region=new Rect(l,t,l+s,t+s);}
   setStatus("Área salva • Nova partida detecta a cor inferior; ▶ retoma a posição salva");main.post(tick);
  }catch(Exception e){setStatus("Não iniciou: "+e.getMessage());stopSelf();}return START_NOT_STICKY;
 }
 int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 WindowManager.LayoutParams params(int w,int h,boolean touches){WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|(touches?0:WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.LEFT;p.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;if(!touches)p.alpha=1.0f;return p;}
 void makePanel(){panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(5),dp(3),dp(5),dp(3));panel.setBackgroundColor(Color.rgb(15,43,59));status=new TextView(this);status.setTextColor(Color.WHITE);status.setTextSize(12);status.setMaxLines(3);panel.addView(status);LinearLayout row=new LinearLayout(this);panel.addView(row);button(row,"Área",this::selectArea);button(row,"Cor/posição",this::chooseSide);button(row,"Nova partida",this::newGame);button(row,"▶/Ⅱ",()->{active=!active;generation++;stable=0;last="";analyzed="";suggestion="";rejected="";hideRings();setStatus(active?"Retomando posição salva…":"Pausado");});LinearLayout row2=new LinearLayout(this);panel.addView(row2);button(row2,"Minimizar / expandir",this::toggleCompact);button(row2,"Fechar painel",this::stopSelf);
  panelParams=params(Math.min(width-dp(16),dp(360)),WindowManager.LayoutParams.WRAP_CONTENT,true);panelParams.x=dp(8);panelParams.y=dp(80);expandedWidth=panelParams.width;wm.addView(panel,panelParams);
  status.setOnTouchListener(new View.OnTouchListener(){float x,y;int px,py;boolean moved;public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==0){x=e.getRawX();y=e.getRawY();px=panelParams.x;py=panelParams.y;moved=false;return true;}else if(e.getAction()==2){float dx=e.getRawX()-x,dy=e.getRawY()-y;if(Math.abs(dx)>dp(4)||Math.abs(dy)>dp(4))moved=true;panelParams.x=Math.max(0,Math.min(width-panel.getWidth(),px+Math.round(dx)));panelParams.y=Math.max(0,Math.min(height-panel.getHeight(),py+Math.round(dy)));wm.updateViewLayout(panel,panelParams);return true;}else if(e.getAction()==1){if(!moved&&compact)toggleCompact();return true;}return true;}});
 }
 void toggleCompact(){
  if(panel==null||panelParams==null)return;
  compact=!compact;
  if(compact){
   status.setText("XV • "+(active?"CAPTURA ATIVA":"PAUSADO")+"  ·  toque ↗");
   for(int i=1;i<panel.getChildCount();i++)panel.getChildAt(i).setVisibility(View.GONE);
   panelParams.width=dp(150);
   status.setMaxLines(1);
   status.setTextSize(11);
  }else{
   for(int i=1;i<panel.getChildCount();i++)panel.getChildAt(i).setVisibility(View.VISIBLE);
   panelParams.width=expandedWidth>0?expandedWidth:Math.min(width-dp(16),dp(360));
   status.setMaxLines(3);
   status.setTextSize(12);
   setStatus(active?"Captura ativa":"Pausado");
  }
  wm.updateViewLayout(panel,panelParams);
 }
 void button(LinearLayout row,String title,Runnable r){Button b=new Button(this);b.setText(title);b.setTextSize(12);b.setMinWidth(0);b.setMinimumWidth(0);row.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));b.setOnClickListener(v->r.run());}
 void chooseSide(){
  if(panel==null||compact)return;
  // Use controls inside the existing overlay instead of opening a second overlay window.
  View old=panel.findViewWithTag("sideChoices");
  if(old!=null){panel.removeView(old);return;}
  LinearLayout choices=new LinearLayout(this);choices.setTag("sideChoices");choices.setOrientation(LinearLayout.VERTICAL);choices.setPadding(dp(8),dp(4),dp(8),dp(4));
  TextView colorLabel=new TextView(this);colorLabel.setTextColor(Color.WHITE);colorLabel.setText("Cor das suas peças:");choices.addView(colorLabel);
  RadioGroup colors=new RadioGroup(this);colors.setOrientation(RadioGroup.HORIZONTAL);
  RadioButton white=new RadioButton(this);white.setId(View.generateViewId());white.setTextColor(Color.WHITE);white.setText("Brancas");
  RadioButton black=new RadioButton(this);black.setId(View.generateViewId());black.setTextColor(Color.WHITE);black.setText("Pretas");colors.addView(white);colors.addView(black);colors.check(prefs.getBoolean("myWhite",true)?white.getId():black.getId());choices.addView(colors);
  TextView posLabel=new TextView(this);posLabel.setTextColor(Color.WHITE);posLabel.setText("Suas peças ficam:");choices.addView(posLabel);
  RadioGroup positions=new RadioGroup(this);positions.setOrientation(RadioGroup.HORIZONTAL);
  RadioButton bottom=new RadioButton(this);bottom.setId(View.generateViewId());bottom.setTextColor(Color.WHITE);bottom.setText("Embaixo");
  RadioButton top=new RadioButton(this);top.setId(View.generateViewId());top.setTextColor(Color.WHITE);top.setText("Em cima");positions.addView(bottom);positions.addView(top);positions.check(prefs.getBoolean("myBottom",true)?bottom.getId():top.getId());choices.addView(positions);
  LinearLayout actions=new LinearLayout(this);Button confirm=new Button(this);confirm.setText("Salvar");Button cancel=new Button(this);cancel.setText("Cancelar");actions.addView(confirm,new LinearLayout.LayoutParams(0,dp(44),1));actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(44),1));choices.addView(actions);
  confirm.setOnClickListener(v->{boolean myWhite=colors.getCheckedRadioButtonId()==white.getId();boolean myBottom=positions.getCheckedRadioButtonId()==bottom.getId();whiteBottom=(myWhite&&myBottom)||(!myWhite&&!myBottom);prefs.edit().putBoolean("myWhite",myWhite).putBoolean("myBottom",myBottom).putBoolean("white",whiteBottom).apply();panel.removeView(choices);newGame();});
  cancel.setOnClickListener(v->panel.removeView(choices));panel.addView(choices);
 }
 void newGame(){generation++;if(vision!=null)vision.reset();snappedRegion=false;whiteBottom=prefs.getBoolean("white",true);board=new Board(Board.INITIAL);calibrated=false;detectingSide=false;last="";stable=0;analyzed="";suggestion="";rejected="";active=true;hideRings();setStatus("Nova partida: orientação "+(whiteBottom?"brancas embaixo":"pretas embaixo")+". Lendo o tabuleiro…");}
 void selectArea(){active=false;generation++;if(vision!=null)vision.reset();hideRings();if(selecting)return;selecting=true;panel.setVisibility(View.GONE);selector=new View(this){Paint p=new Paint(3);float x=-1,y=-1;@Override protected void onDraw(Canvas c){c.drawColor(0x44000000);p.setColor(Color.WHITE);p.setTextSize(dp(18));c.drawText(x<0?"Toque no canto SUPERIOR ESQUERDO":"Toque no canto INFERIOR DIREITO",dp(16),dp(100),p);if(x>=0){p.setColor(Color.GREEN);c.drawCircle(x,y,dp(6),p);}}@Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;if(x<0){x=e.getX();y=e.getY();invalidate();return true;}int l=Math.round(x),t=Math.round(y),w=Math.round(e.getX()-x),h=Math.round(e.getY()-y);if(w<160||h<160||Math.abs(w-h)>Math.max(w,h)*.08||l<0||t<0){x=-1;invalidate();return true;}int s=Math.min(w,h);region=new Rect(l,t,l+s,t+s);snappedRegion=false;prefs.edit().putInt("left",l).putInt("top",t).putInt("size",s).putInt("screenW",width).putInt("screenH",height).apply();wm.removeView(this);selector=null;selecting=false;panel.setVisibility(View.VISIBLE);setStatus("Área salva. Toque em Nova partida no início da próxima partida.");return true;}};wm.addView(selector,params(width,height,true));}
 void processFrame(int gen){Bitmap image=null;String message="",move="";Board next=board;boolean save=false;try{
   if(stopped||gen!=generation||!active)return;
   Image frame=reader.acquireLatestImage();if(frame==null){message="Aguardando imagem da tela…";return;}
   try{Image.Plane plane=frame.getPlanes()[0];int stride=plane.getPixelStride(),row=plane.getRowStride();if(stride!=4)throw new IllegalStateException("Formato de captura incompatível");Bitmap padded=Bitmap.createBitmap(row/stride,height,Bitmap.Config.ARGB_8888);padded.copyPixelsFromBuffer(plane.getBuffer());image=Bitmap.createBitmap(padded,0,0,width,height);if(padded!=image)padded.recycle();}finally{frame.close();}
   if(region==null||region.right>image.getWidth()||region.bottom>image.getHeight())throw new IllegalStateException("Selecione Área novamente");
   // The floating controls must stay outside the chessboard.
   Rect controls=new Rect(panelParams.x,panelParams.y,panelParams.x+panel.getWidth(),panelParams.y+panel.getHeight());if(Rect.intersects(region,controls)){message="Arraste o painel para FORA do tabuleiro";return;}
   int[] ringSq=null;if(suggestion!=null&&suggestion.length()>=4&&ringA!=null&&ringA.getVisibility()==View.VISIBLE){try{ringSq=new int[]{Board.index(suggestion.substring(0,2)),Board.index(suggestion.substring(2,4))};}catch(RuntimeException ignored){ringSq=null;}}
   BoardReader.Result rd=vision.read(image,region,whiteBottom,!snappedRegion,!calibrated,ringSq!=null?board.labels():null,ringSq);
   if(rd.rect!=null&&rd.status!=BoardReader.Status.NO_GRID&&rd.status!=BoardReader.Status.BAD_AREA&&!snappedRegion){
    Rect fitted=new Rect(rd.rect[0],rd.rect[1],rd.rect[2],rd.rect[3]);
    if(fitted.width()>=160&&Math.abs(fitted.width()-fitted.height())<=Math.max(fitted.width(),fitted.height())*0.08f){region=fitted;prefs.edit().putInt("left",region.left).putInt("top",region.top).putInt("size",Math.min(region.width(),region.height())).putInt("screenW",width).putInt("screenH",height).apply();}
    snappedRegion=true;
   }
   if(!rd.ok()&&rd.status!=BoardReader.Status.UNCERTAIN){last="";stable=0;message=rd.message;return;}
   String observed=rd.labels;if(observed.equals(last))stable++;else{last=observed;stable=1;}
   if(!rd.ok()||stable<2){message=!rd.ok()?rd.message:"Aguardando peças pararem…";return;}
   if(!calibrated&&Board.whiteLooksOnTop(observed)){whiteBottom=!whiteBottom;prefs.edit().putBoolean("white",whiteBottom).putBoolean("myBottom",true).putBoolean("myWhite",whiteBottom).apply();last="";stable=0;message="Orientação corrigida: você joga de "+(whiteBottom?"brancas":"pretas")+" (peças embaixo). Lendo de novo…";return;}
   String invalid=Board.invalidReason(observed);
   if(invalid!=null){message="Posição lida é inválida ("+invalid+"). Confira área e peças cobertas";return;}
   String sideNote="";
   if(!observed.equals(board.labels())){String key=board.fen()+observed;next=key.equals(rejected)?null:board.recover(observed);
    if(next==null){boolean[] guess=new boolean[1];Board fresh=Board.fromObserved(observed,whiteBottom,guess);if(fresh==null){rejected=key;message="Posição lida é impossível (rei em xeque dos dois lados). Confira área e peças";return;}next=fresh;sideNote=guess[0]?" • lado a jogar não identificável pela imagem: assumida a sua vez":"";sideNote+=" • roque desativado (sem histórico)";}
    rejected="";}
   save=true;
   if(next.legal().isEmpty()){message=next.inCheck(next.white)?"Xeque-mate • Nova para outra partida":"Empate por afogamento • Nova para outra partida";return;}
   if(next.white!=whiteBottom){message="Vez do adversário";return;}
   if(!next.fen().equals(analyzed)||suggestion.isEmpty()){
    if(System.currentTimeMillis()<retryAt){message="Motor reiniciando…";return;}
    if(engine==null)engine=new Engine(getApplicationInfo().nativeLibraryDir+"/libstockfish.so");
    move=engine.best(next,percent);
   }else move=suggestion;
   message=(move.length()>4?"Sua vez • promoção: "+move.substring(4).toUpperCase():"Sua vez • siga os círculos verdes")+sideNote;
  }catch(Exception e){message="Falha: "+e.getMessage()+" • tentando novamente";retryAt=System.currentTimeMillis()+2000;if(engine!=null){engine.close();engine=null;}}
  finally{if(image!=null)image.recycle();final String msg=message,chosen=move;final Board result=next;final boolean persist=save;main.post(()->{busy=false;if(stopped||gen!=generation||!active)return;if(persist&&result!=null){board=result;calibrated=true;prefs.edit().putString("fen",board.fen()).apply();}suggestion=chosen;analyzed=chosen.isEmpty()?"":board.fen();setStatus(msg);if(!chosen.isEmpty())drawMove(chosen);else hideRings();});}
 }
 void setStatus(String msg){if(prefs!=null)prefs.edit().putString("status",msg).apply();if(status!=null)status.setText(msg);}
 void hideRings(){if(ringA!=null)ringA.setVisibility(View.INVISIBLE);if(ringB!=null)ringB.setVisibility(View.INVISIBLE);}
 void drawMove(String move){if(region==null||move.length()<4)return;if(ringA==null){ringA=new Ring();ringB=new Ring();wm.addView(ringA,params(1,1,false));wm.addView(ringB,params(1,1,false));}place(ringA,Board.index(move.substring(0,2)));place(ringB,Board.index(move.substring(2,4)));}
 void place(Ring ring,int square){int i=whiteBottom?square:63-square;float cell=region.width()/8f;int size=Math.round(cell*.86f);WindowManager.LayoutParams p=params(size,size,false);p.x=Math.round(region.left+(i%8+.5f)*cell-size/2f);p.y=Math.round(region.top+(i/8+.5f)*cell-size/2f);wm.updateViewLayout(ring,p);ring.setVisibility(View.VISIBLE);}
 class Ring extends View{Paint p=new Paint(3);Ring(){super(CaptureService.this);setLayerType(View.LAYER_TYPE_HARDWARE,null);}@Override protected void onDraw(Canvas c){float cx=getWidth()/2f,cy=getHeight()/2f,r=Math.min(getWidth(),getHeight())/2f-dp(5);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(Color.BLACK);p.setStrokeWidth(dp(8));c.drawCircle(cx,cy,r,p);p.setColor(Color.rgb(70,255,20));p.setStrokeWidth(dp(5));c.drawCircle(cx,cy,r,p);p.setStyle(Paint.Style.FILL);p.setColor(0x5530FF20);c.drawCircle(cx,cy,r-dp(3),p);p.setColor(Color.BLACK);c.drawCircle(cx,cy,dp(5),p);p.setColor(Color.rgb(255,255,255));c.drawCircle(cx,cy,dp(2),p);}}
 @Override public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c);if(prefs!=null){setStatus("Tela girada. Inicie a captura novamente e selecione Área.");stopSelf();}}
 @Override public void onDestroy(){stopped=true;active=false;generation++;main.removeCallbacksAndMessages(null);if(engine!=null)engine.close();worker.shutdownNow();if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null){projection.stop();projection=null;}for(View v:new View[]{selector,ringA,ringB,panel})if(v!=null)try{wm.removeView(v);}catch(Exception ignored){}stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
