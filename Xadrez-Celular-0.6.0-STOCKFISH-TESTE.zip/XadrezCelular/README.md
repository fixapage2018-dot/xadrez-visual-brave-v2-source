# Xadrez Celular 0.6.0 — Stockfish em integração inicial

## Estado real desta versão
- Mantém o painel flutuante e a captura de tela/permissões da versão anterior.
- Adiciona integração UCI com o binário oficial Stockfish 19 para Android ARM64, baixado durante o workflow do GitHub Actions.
- Adiciona um campo FEN para testar o motor e mostrar a melhor jogada calculada.
- O motor é executado em segundo plano para não bloquear a interface.

## Ainda NÃO concluído
- Reconhecimento automático de peças na captura de tela.
- Calibração dos quatro cantos do tabuleiro a partir da imagem do jogo.
- Conversão visual da posição para FEN.
- Setas/origem/destino das jogadas calculadas sobre o jogo.

Não considere as dicas automáticas pela imagem prontas. O jogo ainda não foi identificado e não existe um modelo validado para as peças 3D personalizadas. Esta versão separa o teste do motor da etapa de visão computacional.

## Gerar APK
1. Envie os arquivos do projeto para o GitHub.
2. Abra **Actions → Build Android APK → Run workflow**.
3. Aguarde o workflow baixar o Stockfish oficial, montar o APK e publicar o artefato `xadrez-celular-apk`.
4. Baixe o artefato e instale o APK no Android ARM64.

## Testar o motor
Abra o app e use a posição FEN inicial já preenchida. Toque em **Calcular melhor jogada**. O resultado esperado é um lance UCI legal, como `e2e4`, `d2d4` ou outro lance de abertura válido. O lance exato pode variar conforme o tempo de análise.

## Nota de compatibilidade
O workflow empacota o binário Android ARM64 universal da release oficial Stockfish 19. O APK pode ficar grande devido à rede neural NNUE. A execução do binário e o carregamento da rede ainda precisam ser confirmados em dispositivo real; não foi possível executar um teste Android neste ambiente.
