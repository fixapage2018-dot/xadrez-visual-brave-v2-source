package br.com.xadrezcelular

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.media.projection.MediaProjectionManager
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val captureRequest = 501
    private val startFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    private lateinit var fenInput: EditText
    private lateinit var resultText: TextView
    private lateinit var analyseButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 24, 22, 24); setBackgroundColor(Color.rgb(18, 22, 29))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply { text = "♟ Xadrez Celular"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(Color.WHITE) }
        val desc = TextView(this).apply {
            text = "Versão de desenvolvimento: motor Stockfish + calibração visual em etapas.\n\nA leitura automática de peças 3D personalizadas ainda não está concluída. Por enquanto, teste o motor com uma posição FEN; a captura de tela e o reconhecimento serão ligados ao motor depois de validados."
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.LTGRAY); setPadding(0, 16, 0, 18)
        }
        fun button(s: String, action: () -> Unit) = Button(this).apply { text = s; setOnClickListener { action() } }
        val perm = button("1. Permitir painel flutuante") {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else Toast.makeText(this, "Permissão já liberada", Toast.LENGTH_SHORT).show()
        }
        val start = button("2. Iniciar captura e painel") { requestCapture() }
        val stop = button("Parar painel") { stopService(Intent(this, CaptureService::class.java)) }
        val fenTitle = TextView(this).apply { text = "Teste real do Stockfish (FEN)"; textSize = 18f; setTextColor(Color.WHITE); setPadding(0, 20, 0, 8) }
        fenInput = EditText(this).apply {
            setText(startFen); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setHint("Cole aqui a posição FEN")
            textSize = 13f; setSingleLine(false); minLines = 3; maxLines = 4
            setPadding(12, 10, 12, 10); setBackgroundColor(Color.rgb(35, 42, 52))
        }
        analyseButton = button("Calcular melhor jogada") { analysePosition() }
        val resetFen = button("Voltar à posição inicial") { fenInput.setText(startFen); resultText.text = "Aguardando análise." }
        resultText = TextView(this).apply { text = "O resultado da análise aparecerá aqui."; textSize = 14f; setTextColor(Color.rgb(115, 255, 155)); setPadding(4, 14, 4, 14) }
        content.addView(title, fullWidth()); content.addView(desc, fullWidth())
        for (v in listOf(perm, start, stop)) { content.addView(v, fullWidth()); addGap(content, 5) }
        content.addView(fenTitle, fullWidth()); content.addView(fenInput, fullWidth())
        content.addView(analyseButton, fullWidth()); content.addView(resetFen, fullWidth()); content.addView(resultText, fullWidth())
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)); setContentView(root)
    }

    private fun fullWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun addGap(root: LinearLayout, dp: Int) { root.addView(TextView(this), LinearLayout.LayoutParams(1, (dp * resources.displayMetrics.density).toInt())) }

    private fun analysePosition() {
        val fen = fenInput.text.toString().trim()
        analyseButton.isEnabled = false
        resultText.text = "Iniciando Stockfish..."
        thread(name = "stockfish-analysis") {
            try {
                val result = StockfishEngine(this).bestMove(fen)
                runOnUiThread {
                    resultText.text = "MELHOR JOGADA: ${result.bestMove}\n\nMotor: Stockfish\n${result.info}\n\nEsta análise é real para a FEN informada; ainda não vem do reconhecimento automático da tela."
                    analyseButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread { resultText.text = "Falha na análise: ${e.message ?: "erro desconhecido"}"; analyseButton.isEnabled = true }
            }
        }
    }

    private fun requestCapture() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Libere a permissão de sobreposição primeiro", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode); putExtra(CaptureService.EXTRA_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        }
    }
}
