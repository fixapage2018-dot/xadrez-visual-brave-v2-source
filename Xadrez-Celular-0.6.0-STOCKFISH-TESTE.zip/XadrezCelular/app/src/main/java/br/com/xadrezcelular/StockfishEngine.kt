package br.com.xadrezcelular

import android.content.Context
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.TimeUnit

/** UCI bridge. The official Android Stockfish archive is unpacked from assets at first use. */
class StockfishEngine(private val context: Context) {
    data class Result(val bestMove: String, val info: String)

    @Synchronized
    fun bestMove(fen: String, moveTimeMs: Int = 1200): Result {
        require(validFenShape(fen)) { "FEN inválido. Confira as 8 fileiras, lado a jogar e direitos de roque." }
        val engine = prepareEngine()
        val process = ProcessBuilder(engine.absolutePath)
            .directory(engine.parentFile)
            .redirectErrorStream(true)
            .start()
        val writer = OutputStreamWriter(process.outputStream)
        val reader = BufferedReader(InputStreamReader(process.inputStream))
        try {
            writer.write("uci\n"); writer.flush()
            waitForLine(reader, "uciok", 8000)
            writer.write("isready\n"); writer.flush()
            waitForLine(reader, "readyok", 8000)
            writer.write("position fen $fen\n")
            writer.write("go movetime ${moveTimeMs.coerceIn(250, 5000)}\n")
            writer.flush()
            var best = ""
            var info = "Stockfish está calculando..."
            val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(12)
            while (System.nanoTime() < deadline) {
                val line = reader.readLine() ?: break
                if (line.startsWith("info ") && line.contains(" depth ")) info = line.take(220)
                if (line.startsWith("bestmove ")) {
                    best = line.split(Regex("\\s+" )).getOrElse(1) { "" }
                    break
                }
            }
            if (best.isBlank() || best == "(none)" || best == "0000") throw IllegalStateException("Stockfish não encontrou uma jogada. A posição pode estar terminada ou inválida.")
            return Result(best, info)
        } finally {
            try { writer.write("quit\n"); writer.flush() } catch (_: Exception) {}
            try { process.destroy() } catch (_: Exception) {}
            try { if (!process.waitFor(300, TimeUnit.MILLISECONDS)) process.destroyForcibly() } catch (_: Exception) {}
        }
    }

    private fun waitForLine(reader: BufferedReader, expected: String, seconds: Long) {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(seconds)
        while (System.nanoTime() < deadline) {
            val line = reader.readLine() ?: break
            if (line.contains(expected)) return
        }
        throw IllegalStateException("O motor Stockfish não respondeu: $expected")
    }

    private fun prepareEngine(): File {
        val dir = File(context.filesDir, "stockfish")
        if (!dir.exists()) dir.mkdirs()
        val engine = dir.listFiles()?.firstOrNull { it.isFile && it.name.startsWith("stockfish") && !it.name.endsWith(".nnue") }
        if (engine != null && engine.canExecute()) return engine
        // Workflow places the official archive contents in app/src/main/assets/stockfish/.
        val assetNames = context.assets.list("stockfish") ?: emptyArray()
        if (assetNames.isEmpty()) throw IllegalStateException("Stockfish não veio no APK. Execute o workflow atualizado no GitHub Actions.")
        for (name in assetNames) {
            val out = File(dir, name)
            if (!out.exists() || out.length() == 0L) context.assets.open("stockfish/$name").use { input -> out.outputStream().use(input::copyTo) }
        }
        val executable = dir.listFiles()?.firstOrNull { it.isFile && it.name.startsWith("stockfish") && !it.name.endsWith(".nnue") }
            ?: throw IllegalStateException("Não encontrei o executável Stockfish no pacote.")
        if (!executable.setExecutable(true, true) && !executable.canExecute()) throw IllegalStateException("Não foi possível preparar o executável Stockfish.")
        return executable
    }

    private fun validFenShape(fen: String): Boolean {
        val fields = fen.trim().split(Regex("\\s+"))
        if (fields.size !in 4..6 || fields[1] !in listOf("w", "b")) return false
        val ranks = fields[0].split("/")
        if (ranks.size != 8) return false
        if (ranks.any { rank -> rank.sumOf { if (it in '1'..'8') it.digitToInt() else if (it in "pnbrqkPNBRQK") 1 else 99 } != 8 }) return false
        return fields[0].count { it == 'K' } == 1 && fields[0].count { it == 'k' } == 1
    }
}
