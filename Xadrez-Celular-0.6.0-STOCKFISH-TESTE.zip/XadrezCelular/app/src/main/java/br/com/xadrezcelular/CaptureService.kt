package br.com.xadrezcelular

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "resultData"
        private const val CHANNEL_ID = "xadrez_overlay_v2"
        private const val NOTIFICATION_ID = 42
    }
    private var wm: WindowManager? = null
    private var panel: View? = null
    private var grid: BoardGrid? = null
    private var mini: View? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var miniLp: WindowManager.LayoutParams? = null
    private var gridLp: WindowManager.LayoutParams? = null
    private var gridShown = false

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, makeNotification())
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Libere a permissão de sobreposição primeiro.", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startScreenCapture(intent)
        showCompactPanel()
        return START_NOT_STICKY
    }

    private fun startScreenCapture(intent: Intent?) {
        try {
            val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
            @Suppress("DEPRECATION")
            val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java) else intent?.getParcelableExtra(EXTRA_DATA)
            if (code == 0 || data == null) return
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(code, data)
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm?.defaultDisplay?.getRealMetrics(metrics)
            val w = metrics.widthPixels.coerceAtLeast(1); val h = metrics.heightPixels.coerceAtLeast(1)
            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader?.setOnImageAvailableListener({ r -> try { r.acquireLatestImage()?.close() } catch (_: Exception) {} }, null)
            display = projection?.createVirtualDisplay("XadrezCelular", w, h, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
        } catch (_: Exception) { }
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
    private fun baseParams(w: Int, h: Int) = WindowManager.LayoutParams(w, h, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)

    private fun showCompactPanel() {
        if (panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(8, 6, 8, 6)
            background = rounded(Color.rgb(25, 31, 40), Color.rgb(66, 190, 120))
        }
        val header = TextView(this).apply { text = "♟ XADREZ  ·  ⋮⋮"; textSize = 13f; setTextColor(Color.WHITE); setPadding(5, 4, 5, 7) }
        val status = TextView(this).apply { text = "Grade desligada"; textSize = 10f; setTextColor(Color.LTGRAY); setPadding(4, 0, 4, 4) }
        fun btn(label: String, click: () -> Unit) = Button(this).apply { text = label; textSize = 10f; minHeight = 36; minimumHeight = 36; setPadding(2, 0, 2, 0); setOnClickListener { click() } }
        var toggle: Button? = null
        toggle = btn("Mostrar grade", { if (gridShown) { hideGrid(); status.text = "Grade desligada"; toggle?.text = "Mostrar grade" } else { showGrid(); status.text = "Grade 8×8 visível"; toggle?.text = "Ocultar grade" } })
        val smaller = btn("−", { grid?.resize(-12f) })
        val bigger = btn("+", { grid?.resize(12f) })
        val up = btn("↑", { grid?.move(0f, -12f) })
        val down = btn("↓", { grid?.move(0f, 12f) })
        val left = btn("←", { grid?.move(-12f, 0f) })
        val right = btn("→", { grid?.move(12f, 0f) })
        val minimize = btn("Minimizar", { minimizePanel() })
        val close = btn("Fechar", { stopSelf() })
        root.addView(header); root.addView(status); root.addView(toggle)
        root.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(smaller, weight()); addView(bigger, weight()); addView(minimize, weight()) })
        root.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(left, weight()); addView(up, weight()); addView(down, weight()); addView(right, weight()) })
        root.addView(close)
        attachDrag(header, root, { panelLp })
        val lp = baseParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.TOP or Gravity.START; x = 12; y = 100 }
        try { wm?.addView(root, lp); panel = root; panelLp = lp } catch (_: Exception) { stopSelf() }
    }
    private fun weight() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
    private fun rounded(fill: Int, stroke: Int) = GradientDrawable().apply { setColor(fill); cornerRadius = 16f; setStroke(2, stroke) }

    private fun attachDrag(handle: View, target: View, getLp: () -> WindowManager.LayoutParams?) {
        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = getLp() ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
                    MotionEvent.ACTION_MOVE -> { p.x=ox+(e.rawX-sx).toInt(); p.y=oy+(e.rawY-sy).toInt(); try { wm?.updateViewLayout(target,p) } catch (_: Exception) {}; return true }
                    MotionEvent.ACTION_UP -> return true
                }
                return false
            }
        })
    }

    private fun showGrid() {
        if (grid != null) { gridShown = true; grid?.visibilityOn(true); return }
        val m = DisplayMetrics(); @Suppress("DEPRECATION") wm?.defaultDisplay?.getRealMetrics(m)
        val size = (minOf(m.widthPixels, m.heightPixels) * 0.62f).toInt().coerceAtLeast(220)
        val view = BoardGrid(this, size.toFloat())
        val lp = baseParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT).apply { gravity = Gravity.TOP or Gravity.START }
        // The full-screen canvas itself is non-touchable; only the compact controls receive taps.
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm?.addView(view, lp); grid = view; gridLp = lp; gridShown = true; view.post { view.centerBoard() } } catch (_: Exception) { }
    }
    private fun hideGrid() { gridShown = false; grid?.visibilityOn(false) }

    private fun minimizePanel() {
        val old = panel ?: return
        try { wm?.removeView(old) } catch (_: Exception) {}
        panel = null
        val b = TextView(this).apply {
            text = "♟"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(Color.rgb(25,31,40), Color.rgb(66,190,120))
        }
        val lp = baseParams(48,48).apply { gravity = Gravity.TOP or Gravity.START; x=12; y=120 }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(v:View,e:MotionEvent):Boolean {
                val p=miniLp
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p?.x ?: 12; oy=p?.y ?: 120; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> { val dx=e.rawX-sx; val dy=e.rawY-sy; if(kotlin.math.abs(dx)>5 || kotlin.math.abs(dy)>5) moved=true; if(moved && p!=null) { p.x=ox+dx.toInt(); p.y=oy+dy.toInt(); try { wm?.updateViewLayout(b,p) } catch (_:Exception){} }; return true }
                    MotionEvent.ACTION_UP -> { if(!moved) restorePanel(); return true }
                }
                return false
            }
        })
        try { wm?.addView(b,lp); mini=b; miniLp=lp } catch (_: Exception) { stopSelf() }
    }
    private fun restorePanel() {
        val b=mini; if (b != null) try { wm?.removeView(b) } catch (_: Exception) {}
        mini=null; miniLp=null; showCompactPanel()
    }

    private class BoardGrid(context: Context, initialSize: Float) : View(context) {
        private val p=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(62,255,120); strokeWidth=2.5f; style=Paint.Style.STROKE }
        private var size=initialSize; private var x=0f; private var y=0f; private var shown=false
        fun centerBoard() { x=((width-size)/2f).coerceAtLeast(0f); y=((height-size)/2f).coerceAtLeast(0f); invalidate() }
        fun move(dx:Float,dy:Float) { x=(x+dx).coerceIn(0f,(width-size).coerceAtLeast(0f)); y=(y+dy).coerceIn(0f,(height-size).coerceAtLeast(0f)); invalidate() }
        fun resize(d:Float) { size=(size+d).coerceIn(200f,minOf(width.toFloat(),height.toFloat())); x=x.coerceIn(0f,(width-size).coerceAtLeast(0f)); y=y.coerceIn(0f,(height-size).coerceAtLeast(0f)); invalidate() }
        fun visibilityOn(v:Boolean) { shown=v; invalidate() }
        override fun onDraw(c:Canvas) { super.onDraw(c); if(!shown)return; c.drawRect(x,y,x+size,y+size,p); for(i in 1..7){ val a=x+size*i/8f; val b=y+size*i/8f; c.drawLine(a,y,a,y+size,p); c.drawLine(x,b,x+size,b,p) } }
    }

    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) { val c=NotificationChannel(CHANNEL_ID,"Xadrez Celular",NotificationManager.IMPORTANCE_LOW); (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c) } }
    private fun makeNotification(): Notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this,CHANNEL_ID).setContentTitle("Xadrez Celular ativo").setContentText("Painel compacto de calibração").setSmallIcon(android.R.drawable.ic_menu_view).build() else @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("Xadrez Celular ativo").setContentText("Painel compacto de calibração").setSmallIcon(android.R.drawable.ic_menu_view).build()
    override fun onDestroy() { try { display?.release() } catch (_:Exception){}; try { reader?.close() } catch (_:Exception){}; try { projection?.stop() } catch (_:Exception){}; try { panel?.let { wm?.removeView(it) } } catch (_:Exception){}; try { mini?.let { wm?.removeView(it) } } catch (_:Exception){}; try { grid?.let { wm?.removeView(it) } } catch (_:Exception){}; panel=null; mini=null; grid=null; super.onDestroy() }
}
