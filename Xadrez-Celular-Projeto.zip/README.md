# Xadrez Celular — projeto inicial

Este é um projeto Android inicial para servir de base ao aplicativo Xadrez Celular.

## O que existe nesta versão
- Aplicativo Android simples com tela inicial.
- Configuração Java/Kotlin alinhada em JVM 17.
- Workflow do GitHub Actions para compilar um APK a partir do projeto extraído de um ZIP no repositório.

## O que ainda não existe
Esta versão **não** captura a tela, reconhece peças/tabuleiro, integra Stockfish nem desenha pontos verdes. Essas funções exigem implementação adicional e testes.

## Como usar com GitHub Actions
1. Envie este ZIP para a raiz do repositório GitHub.
2. Abra **Actions**.
3. Escolha **Build Android APK** e toque em **Run workflow**.
4. Quando concluir com sucesso, baixe o arquivo em **Artifacts**.
