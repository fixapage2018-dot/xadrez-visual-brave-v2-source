# Xadrez Celular

Projeto Android nativo (Kotlin) preparado para compilação automática de APK pelo GitHub Actions.

## O que já existe
- Aplicativo Android inicial com nome e tela de apresentação.
- Atalho para as configurações de permissão de sobreposição do Android.
- Workflow `.github/workflows/build.yml` para compilar um APK debug e publicá-lo como artefato.

## O que ainda falta implementar
Esta é a base inicial, não o sistema final de dicas ao vivo. Ainda precisam ser implementados e testados:
1. Captura da tela com `MediaProjection` e consentimento explícito do Android.
2. Calibração das 64 casas e reconhecimento de peças/skins.
3. Integração de um binário Stockfish Android compatível e geração da posição FEN.
4. Serviço de overlay para desenhar os dois pontos verdes nas casas de origem e destino.
5. Testes com diferentes jogos, orientações, escalas e skins.

O reconhecimento deve sinalizar incerteza em vez de sugerir uma jogada quando a posição não for confiável. Use as dicas ao vivo apenas em treino/partidas contra o computador.

## Compilar pelo GitHub
1. Crie um repositório vazio no GitHub chamado `xadrez-celular`.
2. Envie todos os arquivos deste projeto para a branch `main` (pode usar **Add file → Upload files** no site).
3. Abra a aba **Actions** e permita workflows, se o GitHub solicitar.
4. Selecione **Build Android APK** e clique em **Run workflow**, ou aguarde a compilação após o push.
5. Abra a execução concluída e baixe `xadrez-celular-debug-apk` em **Artifacts**.

Este APK é de desenvolvimento/debug, não uma versão assinada para publicar na Play Store.
