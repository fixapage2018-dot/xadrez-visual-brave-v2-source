# Xadrez Visual Android — Brave Dev (cópia experimental)

Cópia experimental separada para desenvolvimento e testes visuais, incluindo análise permitida, partidas concluídas e ambientes próprios/de treino. Não use sugestões de motor durante partidas competitivas ao vivo no Chess.com. Lê pixels da tela com autorização do usuário e indica origem/destino com dois círculos verdes. Não clica nem movimenta peças. Não oferece invisibilidade, evasão de anticheat ou garantia contra punições.

## Instalar e usar

1. Instale o APK de teste em Android 10 ou mais recente, processador ARM64 (por exemplo, Redmi Note 13 Pro). Não é app para iPhone.
2. Abra o app. Escolha Brancas ou Pretas: suas peças devem ficar embaixo.
3. Permita **aparecer sobre outros apps** e as notificações.
4. Toque em **Iniciar captura** e autorize **a tela inteira**. O Android mantém seu indicador de captura.
5. Abra o jogo em tela cheia, com o mesmo tema das referências. No painel, toque em **Área**. Toque no canto superior esquerdo e depois no inferior direito do tabuleiro, sem incluir margens.
6. Arraste a faixa de status do painel para fora do tabuleiro. Toque em **Nova** com a posição inicial visível. Aguarde duas leituras estáveis.
7. Mova a peça com o círculo verde para o outro círculo. A promoção aparece no painel. Durante animações ou leitura incerta, os círculos são removidos.
8. **▶/Ⅱ** pausa ou retoma a posição salva; **×** encerra a captura e remove todas as janelas. Também pode parar pela notificação do Android.

Nova só reinicia o histórico do assistente; não inicia uma partida no jogo. Se o Android encerrar a captura, abra o app e autorize novamente. Rotação ou mudança de resolução requer nova captura e seleção da área.

## O que está implementado

- MediaProjection e foreground service, consentimento novo para cada sessão.
- Dois marcadores visuais não tocáveis, opacidade 0,65; painel arrastável; botão ▁ alterna para modo compacto e toque no cabeçalho compacto reabre os controles.
- Captura local, sem permissão INTERNET, microfone, root ou acessibilidade.
- Stockfish 17.1 ARM64 oficial embutido, 2 threads, Hash 32 MB, MultiPV 3, busca de 350 ms (não é latência total garantida).
- Regras legais: xeque, roque, en passant e promoções. Recuperação de até dois meios-lances perdidos, somente com correspondência única.
- FEN salva no dispositivo. Para começar depois de vários lances não observados, importe uma FEN completa pelo app; uma imagem isolada não informa direitos de roque/en passant/histórico.
- Variação configurável: 80% procura o melhor lance; no restante tenta outra opção MultiPV com perda de no máximo 150 centipawns. Se não houver alternativa elegível, usa o melhor. Não representa taxa de vitória nem imitação garantida de jogador humano.
- Em erros de captura ou motor, informa a falha e tenta novamente sem apagar a posição.

## Limitações e validação

O reconhecimento usa o tema das peças do print fornecido. Mudar tema, brilho de peças, escala extrema, cobrir casas com botões ou selecionar margens pode impedir leitura. Não adivinha peças ocultas. Os círculos são brevemente ocultados durante a captura para não interferirem no reconhecimento; pode haver pulsação visível.

A posição é validada em duas leituras. O ciclo é 400 ms mais análise/processamento; o primeiro carregamento do Stockfish demora mais. O desempenho real e as permissões extras do fabricante precisam ser testados no aparelho.

Testes JVM de regras incluem contagens perft conhecidas (posição inicial até profundidade 4, Kiwipete até 3, posição de en passant), escolha arbitrária do primeiro lance e recuperação de dois meios-lances. Não há certificação de funcionamento em aparelhos físicos. Não detecta automaticamente o começo de uma nova partida. Empates por repetição não são rastreados nesta versão.

## Compilar

JDK 17, Gradle 8.10.2, Android SDK 35 / Build Tools 35.0.0.

```sh
python3 scripts/prepare_engine.py
gradle :app:assembleDebug
```

O fluxo privado em **Actions → APK Android de teste** também compila e entrega o APK como artefato. O binário grande não é versionado no Git: o script baixa o pacote oficial e confere SHA-256 antes de usá-lo. Builds de teste usam chave debug; builds em máquinas diferentes podem exigir desinstalar a versão anterior (apagando configurações).

## Licença e fontes

Stockfish © seus autores, GPL-3.0. Consulte LICENSE-Stockfish.txt e stockfish-source gerado pelo script. Pacote oficial exato: https://github.com/official-stockfish/Stockfish/releases/tag/sf_17.1 . As redes NNUE estão embutidas no executável oficial; os fontes e o Makefile no pacote indicam como obter as mesmas redes. Preserve a licença e ofereça o código-fonte correspondente ao redistribuir binários. O código original deste protótipo é disponibilizado sob GPL-3.0, conforme LICENSE-Stockfish.txt. Recortes de peças foram fornecidos pelo usuário para este teste privado; não presumir direitos para redistribuição pública desses recursos.

## Correção: "Leitura incerta"

`Vision.read` agora chama `snap()` antes de ler: a área marcada com os dois toques é ajustada às bordas
reais do tabuleiro (aprende as duas cores das casas e procura onde começam e terminam). Antes, um erro de
~5 px na área já deixava várias casas como `?`. Se as bordas encontradas não fizerem sentido, usa a área
original. Template, `feature()` e os limiares (0,30 / 0,025 / 35) não mudaram.


## Variante independente para Brave (desenvolvimento)

Esta pasta é uma variante de teste separada do APK original: o `applicationId` é `br.com.xadrezvisual.brave`, para permitir instalação paralela. O motor `Engine.java` e o parâmetro percentual foram preservados. O painel contém o botão **Nova partida**, que tenta identificar automaticamente a cor do lado inferior a partir da posição inicial reconhecida no ecrã; se a posição inicial não for reconhecida com segurança, o painel informa que é necessário tentar novamente.

Uso previsto: desenvolvimento, análise permitida, partidas finalizadas e treino contra bots. Não use sugestões de motor durante partidas competitivas online se isso contrariar as regras da plataforma.

Para compilar: `python3 scripts/prepare_engine.py` e `gradle :app:assembleDebug`. O APK de saída é `app/build/outputs/apk/debug/app-debug.apk`.
