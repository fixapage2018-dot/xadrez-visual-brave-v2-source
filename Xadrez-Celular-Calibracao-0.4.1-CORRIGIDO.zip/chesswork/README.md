# Xadrez Celular — Calibração manual (0.4.0)

Aplicativo Android de captura de tela e sobreposição flutuante para auxiliar a calibrar uma grade 8×8 sobre um tabuleiro de xadrez.

## Funcionalidades implementadas
- Solicitação de permissão de sobreposição e captura de tela do Android.
- Grade verde 8×8 sobreposta à tela.
- Ajuste horizontal e vertical da grade, tamanho, mostrar/ocultar.
- Painel flutuante arrastável e opção de minimizar/restaurar.
- Seleção manual de cor (Brancas/Pretas/Auto) apenas como configuração visual.

## Limitações importantes
- A grade é apenas uma referência visual; **não detecta as peças nem calcula jogadas**.
- A seleção Auto/Brancas/Pretas ainda não identifica a cor automaticamente.
- **Stockfish ainda não foi integrado** e as linhas verdes não são recomendações de lances.
- Reconhecer skins 3D personalizadas exige um módulo de visão computacional treinado e testes com capturas reais.
- O APK precisa ser compilado e testado em aparelho Android; este pacote contém o código-fonte.

## Compilação
O workflow `.github/workflows/build.yml` compila o APK debug com Java 17 e Gradle. No GitHub, execute Actions → Build Android APK → Run workflow e baixe o artefato gerado.
