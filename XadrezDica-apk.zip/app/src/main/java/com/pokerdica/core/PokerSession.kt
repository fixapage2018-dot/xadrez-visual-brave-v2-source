package com.pokerdica.core

import java.util.Random

/** Junta leitura + estabilidade + chance de ganhar + sugestão. */
class PokerSession(val glyphs: Glyphs, val onLearned: () -> Unit = {}, val onUnknown: (Unknown) -> Unit = {}) {
    class Out(val lines: List<String>, val action: String?, val heroTurn: Boolean, val learn: Unknown?) {
        val text: String get() = lines.joinToString("\n")
    }

    private val reader = TableReader(glyphs)
    private val rnd = Random()
    private var lastKey = ""
    private var stable = 0
    private var last: Out = Out(listOf("Poker Dica: aguardando a mesa..."), null, false, null)
    private val ignored = HashSet<String>()
    private var calcKey = ""
    private var calcEq: EquityResult? = null

    fun learn(u: Unknown, label: String) {
        glyphs.add(u.kind, label, u.norm)
        onLearned()
        lastKey = ""; stable = 0
    }

    fun ignore(u: Unknown) { ignored.add(sig(u)); lastKey = ""; stable = 0 }

    private fun sig(u: Unknown) = u.kind + u.norm.toHex()

    fun tick(frame: IntArray, w: Int, h: Int): Out {
        if (w < h) return Out(listOf("Gire o jogo pra deitado (a captura precisa ver a mesa inteira)."), null, false, null).also { last = it }
        val st = reader.read(frame, w, h)
        val key = st.key()
        if (key == lastKey) stable++ else { stable = 0; lastKey = key }
        if (stable < 2) return last          // espera a tela parar (animação de fichas/cartas)
        if (stable > 2) return last          // já calculado pra esse estado
        last = decide(st)
        return last
    }

    private fun decide(st: TableState): Out {
        val unk = st.allUnknown().filter { sig(it) !in ignored }
        // nunca interrompe o jogo: anota o símbolo novo pra você ensinar depois, no app
        for (u in unk) onUnknown(u)
        val blocking = unk.filter { it.kind != "num" }       // número novo só deixa pote/aposta "?", não trava a dica
        if (blocking.isNotEmpty()) {
            val u = blocking[0]
            val what = when (u.kind) { "rank" -> "valor de carta"; "suit" -> "naipe"; else -> "número" }
            return Out(listOf("Novo $what (${u.where}): não conheço ainda.", "Depois do jogo: abra o Poker Dica e toque em ensinar."), null, st.heroTurn, null)
        }
        val hero = st.heroCards()
        if (st.hero.isEmpty()) return Out(listOf("Aguardando suas cartas..."), null, st.heroTurn, null)
        if (hero == null) return Out(listOf("Não consegui ler suas cartas.", st.hero.joinToString(" | ") { it.desc.ifEmpty { "?" } }), null, st.heroTurn, null)
        val board = st.boardCards() ?: return Out(listOf("Mão: " + hero.joinToString(" ") { Cards.name(it) }, "Não consegui ler a mesa."), null, st.heroTurn, null)
        if (st.opponents == 0) return Out(listOf("Mão: " + hero.joinToString(" ") { Cards.name(it) }, "Sem adversários na mão (fim de rodada?)."), null, st.heroTurn, null)
        if (board.size == 1 || board.size == 2) return Out(listOf("Mesa com ${board.size} carta(s): aguardando o flop completo..."), null, st.heroTurn, null)
        val all = hero.toList() + board.toList()
        if (all.toSet().size != all.size) return Out(listOf("Leitura repetiu uma carta; aguardando..."), null, st.heroTurn, null)

        val ck = "${hero.joinToString(",")}|${board.joinToString(",")}|${st.opponents}"
        if (ck != calcKey) { calcEq = Equity.run(hero, board, st.opponents, 8000, rnd); calcKey = ck }
        val eq = calcEq!!.equity

        var maxBet = 0L; var unreadable = false; var sum = 0L
        for ((_, v) in st.bets) { if (v == null) unreadable = true else { sum += v; if (v > maxBet) maxBet = v } }
        val mine = st.bets["eu"] ?: 0L
        val toCall: Long? = if (unreadable) null else maxOf(0L, maxBet - mine)
        val pot: Long? = if (unreadable) st.pot else (st.pot ?: 0L) + sum
        val adv = Advisor.advise(eq, st.opponents, pot, toCall)
        val lines = ArrayList<String>()
        lines.add((if (st.heroTurn) "SUA VEZ  " else "(não é sua vez)  ") + hero.joinToString(" ") { Cards.name(it) } +
            (if (board.isNotEmpty()) "  |  " + board.joinToString(" ") { Cards.name(it) } else ""))
        lines.addAll(adv.lines)
        lines.add("➜ " + adv.action)
        return Out(lines, adv.action, st.heroTurn, null)
    }
}
