# Xadrez Celular — Etapa 2 (0.3.0)

Projeto Android para captura de tela e sobreposição durante partidas de xadrez. A grade verde de 8×8 é uma etapa de calibração manual baseada nas imagens de referência do jogo (tabuleiro quadrado de madeira, casas texturizadas e peças estilizadas). Os controles permitem mover a grade verticalmente, alterar seu tamanho e ocultá-la.

## Limites desta versão
- A captura depende da autorização explícita do Android.
- A grade ainda precisa ser alinhada manualmente; ela não detecta automaticamente o tabuleiro.
- **Ainda não há reconhecimento automático de peças, adaptação automática a skins, nem integração com Stockfish.** Os pontos/linhas verdes são apenas a grade de calibração, não recomendações de jogadas.

## Compilar
O workflow `.github/workflows/build.yml` compila o APK debug com Java 17 e Gradle 8.9. Coloque este ZIP sozinho no repositório (remova ZIPs antigos para o workflow não selecionar o arquivo errado), execute Actions → Build Android APK → Run workflow e baixe o artefato `xadrez-celular-apk`.
