package br.com.xadrezcelular

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 501
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(18, 22, 29))
        }
        val title = TextView(this).apply {
            text = "♟ Xadrez Celular"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Versão 0.3.0 — Etapa 2\n\nCaptura de tela e grade de calibração 8×8 ajustável para o tabuleiro de madeira das imagens de referência.\n\nEsta versão ainda não reconhece as peças nem calcula lances com Stockfish."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        val overlayPermission = Button(this).apply {
            text = "1. Permitir sobreposição"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    Toast.makeText(this@MainActivity, "Permissão de sobreposição já liberada.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val start = Button(this).apply {
            text = "2. Iniciar captura e painel"
            setOnClickListener { requestCapture() }
        }
        val stop = Button(this).apply {
            text = "Parar painel flutuante"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) }
        }
        fun add(view: android.view.View, top: Int) {
            root.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = top })
        }
        add(title, 0); add(status, 20); add(overlayPermission, 24); add(start, 10); add(stop, 10)
        setContentView(root)
    }

    private fun requestCapture() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primeiro libere a permissão de sobreposição.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated in Android API but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            status.text = "Captura autorizada. Ajuste a grade verde para coincidir com as bordas do tabuleiro.\n\nReconhecimento de peças e Stockfish serão a próxima etapa."
        } else if (requestCode == captureRequest) {
            Toast.makeText(this, "A captura não foi autorizada.", Toast.LENGTH_SHORT).show()
        }
    }
}
