package br.com.xadrezcelular

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.drawable.GradientDrawable
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "resultData"
        private const val CHANNEL_ID = "xadrez_capture"
        private const val NOTIFICATION_ID = 41
    }

    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var gridView: BoardGridView? = null
    private var gridParams: WindowManager.LayoutParams? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var minimized = false
    private var selectedColor = "Auto"
    private var panelParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(intent)
        showGrid()
        showPanel()
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent?) {
        try {
            val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
            @Suppress("DEPRECATION")
            val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
            } else {
                intent?.getParcelableExtra(EXTRA_DATA)
            }
            if (resultCode == 0 || data == null) return

            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels.coerceAtLeast(1)
            val height = metrics.heightPixels.coerceAtLeast(1)
            val density = metrics.densityDpi
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            imageReader?.setOnImageAvailableListener({ reader ->
                // Captura real de frames habilitada. O reconhecimento de tabuleiro será implementado na próxima etapa.
                val image = reader.acquireLatestImage()
                image?.close()
            }, null)
            virtualDisplay = projection?.createVirtualDisplay(
                "XadrezCelularCapture",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                null
            )
        } catch (_: Exception) {
            // Mantém o painel disponível mesmo se o aparelho bloquear a captura.
        }
    }

    // Grade de calibração: usa a proporção observada nas imagens de referência.
    // Não identifica peças ainda; permite alinhar as 64 casas ao tabuleiro real.
    private fun showGrid() {
        if (gridView != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val wm = windowManager ?: return
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val initialSize = minOf(metrics.widthPixels.toFloat(), metrics.heightPixels * 0.45f)
        val view = BoardGridView(this, initialSize, metrics.heightPixels * 0.263f)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(view, params)
            gridView = view
            gridParams = params
        } catch (_: Exception) { }
    }

    private fun showPanel() {
        if (panel != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            background = GradientDrawable().apply { setColor(Color.rgb(25, 32, 42)); cornerRadius = 24f; setStroke(2, Color.rgb(69, 180, 110)) }
        }
        val heading = TextView(this).apply { text = "♟ Xadrez Celular • Calibração"; setTextColor(Color.WHITE); textSize = 15f }
        val info = TextView(this).apply {
            text = "Ajuste a grade sobre o tabuleiro. Leitura de peças e Stockfish ainda não estão ativos."
            setTextColor(Color.LTGRAY); textSize = 12f; setPadding(0, 6, 0, 6)
        }
        fun control(label: String, action: () -> Unit): Button = Button(this).apply { text = label; textSize = 11f; setOnClickListener { action() } }
        val up = control("Grade ↑", { gridView?.moveY(-12f) })
        val down = control("Grade ↓", { gridView?.moveY(12f) })
        val left = control("Grade ←", { gridView?.moveX(-12f) })
        val right = control("Grade →", { gridView?.moveX(12f) })
        val smaller = control("− Grade", { gridView?.resize(-12f) })
        val larger = control("+ Grade", { gridView?.resize(12f) })
        val toggle = control("Mostrar / ocultar grade", { gridView?.toggle() })
        val minimize = control("Minimizar", { setPanelMinimized(true) })
        val close = control("Fechar painel e captura", { stopSelf() })
        val colorLabel = TextView(this).apply { text = "Minha cor (manual):"; setTextColor(Color.WHITE); textSize = 12f }
        val autoColor = control("Auto", { setColorChoice("Auto") })
        val whiteColor = control("Brancas", { setColorChoice("Brancas") })
        val blackColor = control("Pretas", { setColorChoice("Pretas") })
        container.addView(heading); container.addView(info); container.addView(colorLabel)
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(autoColor, LinearLayout.LayoutParams(0, -2, 1f)); addView(whiteColor, LinearLayout.LayoutParams(0, -2, 1f)); addView(blackColor, LinearLayout.LayoutParams(0, -2, 1f)) }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(up, LinearLayout.LayoutParams(0, -2, 1f)); addView(down, LinearLayout.LayoutParams(0, -2, 1f)) }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(smaller, LinearLayout.LayoutParams(0, -2, 1f)); addView(larger, LinearLayout.LayoutParams(0, -2, 1f)) }
        val rowHorizontal = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(left, LinearLayout.LayoutParams(0, -2, 1f)); addView(right, LinearLayout.LayoutParams(0, -2, 1f)) }
        container.addView(colorRow); container.addView(rowHorizontal); container.addView(row1); container.addView(row2); container.addView(toggle); container.addView(minimize); container.addView(close)
        heading.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0f; private var startY = 0f; private var originalX = 0; private var originalY = 0
            override fun onTouch(v: View, event: android.view.MotionEvent): Boolean {
                val lp = container.layoutParams as? WindowManager.LayoutParams ?: return false
                when (event.action) {
                    android.view.MotionEvent.ACTION_DOWN -> { startX = event.rawX; startY = event.rawY; originalX = lp.x; originalY = lp.y; return true }
                    android.view.MotionEvent.ACTION_MOVE -> { lp.x = originalX + (event.rawX - startX).toInt(); lp.y = originalY + (event.rawY - startY).toInt(); try { windowManager?.updateViewLayout(container, lp) } catch (_: Exception) {}; return true }
                }
                return event.action == android.view.MotionEvent.ACTION_UP
            }
        })
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END; x = 8; y = 100
        }
        try { windowManager?.addView(container, params); panel = container; panelParams = params } catch (_: Exception) { stopSelf() }
    }

    private fun setColorChoice(choice: String) {
        selectedColor = choice
        android.widget.Toast.makeText(this, "Cor selecionada: $choice", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun setPanelMinimized(value: Boolean) {
        val wm = windowManager ?: return
        val current = panel ?: return
        try { wm.removeView(current) } catch (_: Exception) {}
        if (value) {
            val mini = Button(this).apply {
                text = "♟"
                textSize = 18f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.rgb(25, 32, 42))
                setOnClickListener { setPanelMinimized(false) }
            }
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(56, 56, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 8; y = 100 }
            try { wm.addView(mini, params); panel = mini; panelParams = params; minimized = true } catch (_: Exception) { stopSelf() }
        } else {
            panel = null
            minimized = false
            showPanel()
        }
    }

    private class BoardGridView(context: Context, initialSize: Float, initialTop: Float) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(70, 255, 125); strokeWidth = 3f; style = Paint.Style.STROKE }
        private var boardSize = initialSize
        private var left = 0f
        private var top = initialTop
        private var visible = true
        fun moveY(delta: Float) { top = (top + delta).coerceIn(0f, (height - boardSize).coerceAtLeast(0f)); invalidate() }
        fun moveX(delta: Float) { left = (left + delta).coerceIn(0f, (width - boardSize).coerceAtLeast(0f)); invalidate() }
        fun resize(delta: Float) { boardSize = (boardSize + delta).coerceIn(240f, minOf(width.toFloat(), height.toFloat())); top = top.coerceAtMost((height-boardSize).coerceAtLeast(0f)); invalidate() }
        fun toggle() { visible = !visible; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (!visible) return
            val size = minOf(boardSize, (width - left).coerceAtLeast(0f), (height - top).coerceAtLeast(0f))
            paint.alpha = 210
            canvas.drawRect(left, top, left + size, top + size, paint)
            for (i in 1..7) {
                val x = left + size * i / 8f
                val y = top + size * i / 8f
                canvas.drawLine(x, top, x, top + size, paint)
                canvas.drawLine(left, y, left + size, y, paint)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Captura do Xadrez Celular", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Xadrez Celular ativo")
                .setContentText("Captura de tela e painel flutuante")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Xadrez Celular ativo")
                .setContentText("Captura de tela e painel flutuante")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        }
    }

    override fun onDestroy() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        try { gridView?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        virtualDisplay = null
        imageReader = null
        projection = null
        panel = null
        panelParams = null
        gridView = null
        gridParams = null
        super.onDestroy()
    }
}
