package br.com.xadrezvisual;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Leitura do tabuleiro por comparação com as peças de referência (assets/pieces).
 *
 * Correção em relação à versão 0.1: antes de ler, a área marcada pelo usuário é
 * "encaixada" (snap) nas bordas reais do tabuleiro. A leitura original comparava
 * máscaras de 60x60 pixel a pixel e errava com deslocamento de ~5 px na área,
 * o que acontece em qualquer toque manual nos cantos.
 */
final class Vision {

    private record Template(char label, float[] f) {}

    private static final int SIZE = 60;
    private static final int SAT_MAX = 18;          // pixel "sem cor" = parte da peça
    private static final float MIN_PRESENCE = 24f;  // abaixo disso a casa é vazia; tolera peças pequenas
    private static final float MAX_DIST = 0.42f;    // limite mais tolerante a escala/antialiasing do navegador
    private static final float MIN_GAP = 0.008f;    // margem mínima entre melhor e segundo melhor modelo

    private final List<Template> templates = new ArrayList<>();

    Vision(Context ctx) throws IOException {
        String[] names = ctx.getAssets().list("pieces");
        if (names != null) {
            for (String n : names) {
                if (!n.endsWith(".png")) continue;
                try (InputStream in = ctx.getAssets().open("pieces/" + n)) {
                    Bitmap b = BitmapFactory.decodeStream(in);
                    templates.add(new Template(n.charAt(0), feature(b)));
                    b.recycle();
                }
            }
        }
        if (templates.isEmpty()) throw new IOException("Referências das peças ausentes");
    }

    /** Mesmo cálculo da versão 0.1: máscara (pixels sem cor) + brilho, em 60x60. */
    static float[] feature(Bitmap src) {
        Bitmap b = Bitmap.createScaledBitmap(src, SIZE, SIZE, true);
        float[] f = new float[SIZE * SIZE * 2];
        for (int y = 4; y < 56; y++) {
            for (int x = 6; x < 54; x++) {
                int p = b.getPixel(x, y);
                // Os modelos PNG têm fundo transparente. Ignorar esses pixels é
                // essencial: o RGB de pixels transparentes pode ser preto e ser
                // confundido com o contorno da peça, distorcendo toda a máscara.
                if (Color.alpha(p) < 32) continue;
                int r = Color.red(p), g = Color.green(p), bl = Color.blue(p);
                int sat = Math.max(r, Math.max(g, bl)) - Math.min(r, Math.min(g, bl));
                if (sat < SAT_MAX) {
                    int i = (y * SIZE + x) * 2;
                    f[i] = 1f;
                    f[i + 1] = (r + g + bl) / 765f;
                }
            }
        }
        if (b != src) b.recycle();
        return f;
    }

    /**
     * Ajusta a área aproximada (dois toques do usuário) para as bordas exatas do
     * tabuleiro. Aprende as duas cores das casas dentro da área, monta uma máscara
     * "pixel com cor de casa" e procura onde essa máscara começa e termina.
     * Se algo não bater (bordas implausíveis), devolve a área original.
     */
    static Rect snap(Bitmap bmp, Rect rough) {
        int W = bmp.getWidth(), H = bmp.getHeight();
        int w = rough.width(), h = rough.height();
        if (w < 80 || h < 80) return rough;
        int m = (int) (0.12f * w);
        int x0 = Math.max(0, rough.left - m), x1 = Math.min(W, rough.right + m);
        int y0 = Math.max(0, rough.top - m), y1 = Math.min(H, rough.bottom + m);
        int ww = x1 - x0, wh = y1 - y0;
        if (ww <= 0 || wh <= 0) return rough;
        int[] win = new int[ww * wh];
        bmp.getPixels(win, 0, ww, x0, y0, ww, wh);

        // 1) cores das casas: duas cores coloridas mais frequentes dentro da área
        int[] hist = new int[4096];
        int ix0 = Math.max(0, rough.left), ix1 = Math.min(W, rough.right);
        int iy0 = Math.max(0, rough.top), iy1 = Math.min(H, rough.bottom);
        for (int y = iy0; y < iy1; y += 2) {
            for (int x = ix0; x < ix1; x += 2) {
                int p = win[(y - y0) * ww + (x - x0)];
                int r = Color.red(p), g = Color.green(p), b = Color.blue(p);
                if (Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b)) < SAT_MAX) continue;
                hist[((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4)]++;
            }
        }
        int ka = -1;
        for (int k = 0; k < 4096; k++) if (ka < 0 || hist[k] > hist[ka]) ka = k;
        if (ka < 0 || hist[ka] == 0) return rough;
        int[] ca = binCenter(ka);
        int kb = -1;
        for (int k = 0; k < 4096; k++) {
            if (hist[k] == 0) continue;
            int[] c = binCenter(k);
            if (Math.abs((c[0] + c[1] + c[2]) - (ca[0] + ca[1] + ca[2])) <= 45) continue;
            if (kb < 0 || hist[k] > hist[kb]) kb = k;
        }
        if (kb < 0) return rough;
        int[] cb = binCenter(kb);

        // 2) fração de pixels "cor de casa" por coluna e por linha (faixa central)
        int cy0 = Math.max(0, (int) (rough.top + 0.2f * h) - y0);
        int cy1 = Math.min(wh, (int) (rough.top + 0.8f * h) - y0);
        int cx0 = Math.max(0, (int) (rough.left + 0.2f * w) - x0);
        int cx1 = Math.min(ww, (int) (rough.left + 0.8f * w) - x0);
        if (cy1 <= cy0 || cx1 <= cx0) return rough;
        int[] colHit = new int[ww];
        int[] rowHit = new int[wh];
        for (int y = 0; y < wh; y++) {
            for (int x = 0; x < ww; x++) {
                int p = win[y * ww + x];
                int r = Color.red(p), g = Color.green(p), b = Color.blue(p);
                boolean hit = close(r, g, b, ca) || close(r, g, b, cb);
                if (!hit) continue;
                if (y >= cy0 && y < cy1) colHit[x]++;
                if (x >= cx0 && x < cx1) rowHit[y]++;
            }
        }
        int nl = first(colHit, 0.30f * (cy1 - cy0));
        int nr = last(colHit, 0.30f * (cy1 - cy0)) + 1;
        int nt = first(rowHit, 0.30f * (cx1 - cx0));
        int nb = last(rowHit, 0.30f * (cx1 - cx0)) + 1;
        if (nl < 0 || nt < 0 || nr <= 0 || nb <= 0) return rough;
        nl += x0; nr += x0; nt += y0; nb += y0;
        int nw = nr - nl, nh = nb - nt;
        if (nw <= 0 || nh <= 0) return rough;
        if (Math.abs(nw - nh) > 0.03f * Math.max(nw, nh)) return rough;   // tem de ser quadrado
        if (nw < 0.5f * w || nw > 1.6f * w) return rough;                 // tamanho implausível
        return new Rect(nl, nt, nr, nb);
    }

    private static int[] binCenter(int k) {
        return new int[]{((k >> 8) & 15) * 16 + 8, ((k >> 4) & 15) * 16 + 8, (k & 15) * 16 + 8};
    }

    private static boolean close(int r, int g, int b, int[] c) {
        return Math.abs(r - c[0]) <= 24 && Math.abs(g - c[1]) <= 24 && Math.abs(b - c[2]) <= 24;
    }

    private static int first(int[] a, float thr) {
        for (int i = 0; i < a.length; i++) if (a[i] >= thr) return i;
        return -1;
    }

    private static int last(int[] a, float thr) {
        for (int i = a.length - 1; i >= 0; i--) if (a[i] >= thr) return i;
        return -1;
    }

    /** 64 caracteres: peça (PNBRQK/pnbrqk), '.' vazia ou '?' incerta. */
    String read(Bitmap bmp, Rect rough, boolean whiteBottom) {
        Rect area = snap(bmp, rough);
        StringBuilder sb = new StringBuilder();
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                int l = area.left + Math.round(area.width() * col / 8f);
                int t = area.top + Math.round(area.height() * row / 8f);
                int r = area.left + Math.round((col + 1) * area.width() / 8f);
                int bt = area.top + Math.round((row + 1) * area.height() / 8f);
                Bitmap cell = Bitmap.createBitmap(bmp, l, t, r - l, bt - t);
                float[] f = feature(cell);
                cell.recycle();

                float presence = 0f;
                for (int i = 0; i < f.length; i += 2) presence += f[i];
                if (presence < MIN_PRESENCE) { sb.append('.'); continue; }

                Map<Character, Float> best = new HashMap<>();
                for (Template tp : templates) {
                    float union = 0f, dist = 0f;
                    for (int i = 0; i < f.length; i += 2) {
                        union += Math.max(f[i], tp.f()[i]);
                        float dx = f[i] - tp.f()[i];
                        float dy = f[i + 1] - tp.f()[i + 1];
                        dist += dx * dx + dy * dy;
                    }
                    best.merge(tp.label(), dist / Math.max(1f, union), Math::min);
                }
                char label = '?';
                float b1 = Float.MAX_VALUE, b2 = Float.MAX_VALUE;
                char lb = '?';
                for (Map.Entry<Character, Float> e : best.entrySet()) {
                    float v = e.getValue();
                    if (v < b1) { b2 = b1; b1 = v; lb = e.getKey(); }
                    else b2 = Math.min(b2, v);
                }
                if (b1 < MAX_DIST && (b2 - b1) > MIN_GAP) label = lb;
                sb.append(label);
            }
        }
        if (!whiteBottom) sb.reverse();
        return sb.toString();
    }
}
