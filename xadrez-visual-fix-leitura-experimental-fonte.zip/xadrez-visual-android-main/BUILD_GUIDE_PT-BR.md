# Xadrez Visual Brave — pacote de teste

## O que foi verificado
- Os testes JVM de regras do xadrez passaram neste ambiente: `PASS: perft initial/kiwipete/en-passant, arbitrary first moves, 2 plies, uncertainty, immutability`.
- O APK Android **não foi compilado neste ambiente** porque não há Android SDK/Gradle instalado aqui.
- O reconhecimento visual ainda precisa ser testado em aparelho com capturas reais; os testes de regras não comprovam a leitura correta das casas inferiores.

## Gerar o APK pelo GitHub (celular)
1. Abra `https://github.com/fixapage2018-dot/xadrez-visual-brave1`.
2. Trabalhe apenas na variante Brave; não apague nem substitua o aplicativo original.
3. Extraia este ZIP e envie os arquivos/pastas para a raiz de uma cópia do repositório, mantendo a estrutura (`app/`, `scripts/`, `tests/`, `.github/`, `build.gradle`, `settings.gradle`).
4. No GitHub, abra **Actions** → **APK Android de teste** → **Run workflow**.
5. Espere a execução terminar com marca verde. Abra a execução e baixe o artefato **XadrezVisual-Android-teste**.
6. Extraia o artefato e instale `app-debug.apk` no Android. Se o sistema bloquear, autorize a instalação para o aplicativo usado para abrir o arquivo.
7. Esta é uma build de teste assinada com chave debug. Não desinstale a versão que já funciona antes de confirmar que esta variante instala e abre corretamente.

## Limites conhecidos
- O workflow precisa de Android SDK 35, Build Tools 35.0.0, JDK 17 e Gradle 8.10.2.
- O workflow baixa o Stockfish oficial e verifica o SHA-256; a compilação depende de o download estar acessível.
- Use a assistência apenas em imagens próprias, partidas finalizadas ou ambientes de treino/bot em que seja permitida.


## Ajuste experimental de reconhecimento (22/10/2026)

A versão atual usa limites de comparação mais tolerantes para reduzir casas marcadas como `?` quando o navegador redimensiona ou suaviza as imagens das peças. Isso pode reconhecer mais peças, mas precisa ser validado com o tema exato do tabuleiro no aparelho; em casos ambíguos, pode aumentar o risco de classificar uma peça incorretamente. O botão **Cor/posição** foi alterado para mostrar os controles dentro do próprio painel flutuante, evitando abrir uma segunda janela de sobreposição.
