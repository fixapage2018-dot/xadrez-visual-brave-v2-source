import br.com.xadrezvisual.Board;
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.*;
import java.util.*;
import javax.imageio.ImageIO;

/**
 * Testes do reconhecedor com tabuleiros SINTÉTICOS (verde/creme, peças cinza "3D" derivadas das silhuetas
 * de referência). Não substituem um teste com captura real do Chess.com no aparelho.
 * Usa reflexão porque BoardReader é package-private (mesmo pacote do app).
 */
public class BoardReaderTest {
    static int passed = 0;
    static void check(boolean ok, String why) { if (!ok) throw new AssertionError(why); passed++; }

    // ---- acesso ao BoardReader via reflexão
    static Class<?> BR, LIB, RES;
    static Object statLib;
    static Object invoke(String m, Class<?>[] t, Object... a) throws Exception {
        Method me = BR.getDeclaredMethod(m, t); me.setAccessible(true); return me.invoke(null, a);
    }
    static Object field(Object o, String f) throws Exception { Field x = o.getClass().getDeclaredField(f); x.setAccessible(true); return x.get(o); }

    static Object loadStatic(String dir) throws Exception {
        List<int[]> px = new ArrayList<>(), dims = new ArrayList<>(); List<Character> lab = new ArrayList<>();
        File[] fs = new File(dir).listFiles((d, n) -> n.endsWith(".png")); Arrays.sort(fs);
        for (File f : fs) {
            BufferedImage im = ImageIO.read(f); int w = im.getWidth(), h = im.getHeight();
            int[] p = new int[w * h]; im.getRGB(0, 0, w, h, p, 0, w);
            px.add(p); dims.add(new int[]{w, h}); lab.add(f.getName().charAt(0));
        }
        return invoke("buildStatic", new Class<?>[]{List.class, List.class, List.class}, px, dims, lab);
    }

    /** Resultado simplificado. */
    static class R { String status, labels, message; int[] rect; boolean learned; List<String> unc; float grid; }
    static R read(int[] px, int W, int H, int[] rough, boolean snap, boolean whiteBottom, boolean allowLearn, Object learnedIn, Object[] learnedOut) throws Exception {
        Object holder = Array.newInstance(LIB, 1);
        Object res = invoke("read", new Class<?>[]{int[].class, int.class, int.class, int[].class, boolean.class, boolean.class, LIB, LIB, boolean.class, holder.getClass()},
                px, W, H, rough, snap, whiteBottom, statLib, learnedIn, allowLearn, holder);
        R r = new R(); r.status = field(res, "status").toString(); r.labels = (String) field(res, "labels"); r.message = (String) field(res, "message");
        r.rect = (int[]) field(res, "rect"); r.learned = (Boolean) field(res, "learnedUsed"); r.unc = (List<String>) field(res, "uncertain"); r.grid = (Float) field(res, "gridScore");
        if (learnedOut != null) learnedOut[0] = Array.get(holder, 0);
        return r;
    }

    // ---- gerador de tabuleiro sintético
    static class Theme {
        int light = 0xEEEED2, dark = 0x769656; int cell = 126; float sx = 1.30f, sy = 1.12f;
        float wA = 70, wB = .55f, bA = 15, bB = .9f; boolean shadeGradient = true; boolean flip = false; int thick = 0;
    }
    static Map<Character, boolean[]> maskCache = new HashMap<>(); static Map<Character, float[]> lumCache = new HashMap<>(); static Map<Character, int[]> dimCache = new HashMap<>();
    static String assets;

    static void sprite(char piece) throws Exception {
        if (maskCache.containsKey(piece)) return;
        File[] fs = new File(assets).listFiles((d, n) -> n.charAt(0) == piece && n.endsWith(".png")); Arrays.sort(fs);
        BufferedImage im = ImageIO.read(fs[0]); int w = im.getWidth(), h = im.getHeight();
        int[] p = new int[w * h]; im.getRGB(0, 0, w, h, p, 0, w);
        int bg = p[3 * w + w / 2]; // pixel de fundo no topo
        boolean[] m = new boolean[w * h]; float[] lum = new float[w * h];
        for (int i = 0; i < w * h; i++) {
            int q = p[i]; int d = Math.max(Math.abs(((q >> 16) & 255) - ((bg >> 16) & 255)), Math.max(Math.abs(((q >> 8) & 255) - ((bg >> 8) & 255)), Math.abs((q & 255) - (bg & 255))));
            m[i] = d > 40; lum[i] = (.299f * ((q >> 16) & 255) + .587f * ((q >> 8) & 255) + .114f * (q & 255));
        }
        // maior componente (descarta dígitos/letras)
        int[] comp = new int[w * h]; int bestId = 0, bestN = 0, id = 0; int[] st = new int[w * h];
        for (int s = 0; s < w * h; s++) {
            if (!m[s] || comp[s] != 0) continue; id++; int sp = 0, n = 0; st[sp++] = s; comp[s] = id;
            while (sp > 0) { int i = st[--sp]; n++; int x = i % w, y = i / w;
                if (x > 0 && m[i - 1] && comp[i - 1] == 0) { comp[i - 1] = id; st[sp++] = i - 1; }
                if (x < w - 1 && m[i + 1] && comp[i + 1] == 0) { comp[i + 1] = id; st[sp++] = i + 1; }
                if (y > 0 && m[i - w] && comp[i - w] == 0) { comp[i - w] = id; st[sp++] = i - w; }
                if (y < h - 1 && m[i + w] && comp[i + w] == 0) { comp[i + w] = id; st[sp++] = i + w; } }
            if (n > bestN) { bestN = n; bestId = id; }
        }
        for (int i = 0; i < w * h; i++) m[i] = comp[i] == bestId;
        maskCache.put(piece, m); lumCache.put(piece, lum); dimCache.put(piece, new int[]{w, h});
    }

    static int[] pix; static int PW, PH;
    static void px(int x, int y, int c) { if (x >= 0 && y >= 0 && x < PW && y < PH) pix[y * PW + x] = c; }
    static int blend(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | r << 16 | g << 8 | bl;
    }

    /** labels em ordem a8..h1; devolve imagem; board em (bx,by) com lado cell*8. */
    static int[] render(String labels, Theme th, int W, int H, int bx, int by, Set<Integer> highlight, Set<Integer> dots) throws Exception {
        pix = new int[W * H]; PW = W; PH = H;
        Arrays.fill(pix, 0xFF302E2B);
        for (int y = 0; y < 100; y++) for (int x = 0; x < W; x++) pix[y * W + x] = 0xFF262522;
        String view = th.flip ? new StringBuilder(labels).reverse().toString() : labels;
        int cs = th.cell;
        for (int i = 0; i < 64; i++) {
            int r = i / 8, c = i % 8; int base = ((r + c) % 2 == 0) ? th.light : th.dark; int x0 = bx + c * cs, y0 = by + r * cs;
            int col = 0xFF000000 | base;
            if (highlight != null && highlight.contains(i)) col = blend(col, 0xF6F669, .5f);
            for (int y = 0; y < cs; y++) for (int x = 0; x < cs; x++) px(x0 + x, y0 + y, col);
            if (dots != null && dots.contains(i)) for (int y = 0; y < cs; y++) for (int x = 0; x < cs; x++) { int dx = x - cs / 2, dy = y - cs / 2; if (dx * dx + dy * dy < (cs / 6) * (cs / 6)) px(x0 + x, y0 + y, blend(col, 0, .12f)); }
            int opp = ((r + c) % 2 == 0) ? (0xFF000000 | th.dark) : (0xFF000000 | th.light);
            if (c == 0) for (int y = 4; y < 4 + cs / 9; y++) for (int x = 4; x < 4 + cs / 14; x++) px(x0 + x, y0 + y, opp);
            if (r == 7) for (int y = cs - 4 - cs / 9; y < cs - 4; y++) for (int x = cs - 4 - cs / 14; x < cs - 4; x++) px(x0 + x, y0 + y, opp);
        }
        for (int i = 0; i < 64; i++) {
            char p = view.charAt(i); if (p == '.') continue; sprite(p);
            boolean[] m = maskCache.get(p); float[] lum = lumCache.get(p); int TW = dimCache.get(p)[0], TH = dimCache.get(p)[1]; boolean white = Character.isUpperCase(p);
            int r = i / 8, c = i % 8; int cx = bx + c * cs + cs / 2, cy = by + r * cs + cs / 2 + cs / 14;
            int dw = Math.round(cs * .78f * th.sx), dh = Math.round(cs * .78f * th.sy);
            for (int y = 0; y < dh; y++) for (int x = 0; x < dw; x++) {
                int sx = x * TW / dw, sy = y * TH / dh; int si = sy * TW + sx; if (si >= m.length || !m[si]) continue;
                float L = lum[si]; float v = white ? th.wA + th.wB * L : th.bA + th.bB * L;
                if (th.shadeGradient) v += 22f * (.5f - y / (float) dh);
                v = Math.max(0, Math.min(255, v)); int g = (int) v; px(cx - dw / 2 + x, cy - dh / 2 + y, 0xFF000000 | g << 16 | g << 8 | g);
            }
        }
        return pix;
    }

    static String PLAIN(String rows) { return rows.replace("/", ""); }
    static final String D3 = PLAIN("rnbqkbnr/pppppppp/......../......../......../...P..../PPP.PPPP/RNBQKBNR");   // posição do teste: d3? (peão em d3)
    static String D3FIX() { // peão branco em d3 (linha 5, coluna d)
        char[] a = HOME().toCharArray(); a[51] = '.'; a[43] = 'P'; return new String(a);
    }
    static String HOME() { return "rnbqkbnr" + "pppppppp" + "........".repeat(4) + "PPPPPPPP" + "RNBQKBNR"; }

    static String rotate(String s) { return new StringBuilder(s).reverse().toString(); }

    public static void main(String[] args) throws Exception {
        assets = args.length > 0 ? args[0] : "app/src/main/assets/pieces";
        BR = Class.forName("br.com.xadrezvisual.BoardReader"); LIB = Class.forName("br.com.xadrezvisual.BoardReader$Library");
        statLib = loadStatic(assets);
        int W = 1080, H = 1400, bx = 36, by = 160; Theme th = new Theme();
        int s = th.cell * 8;
        int[] truth = {bx, by, bx + s, by + s};

        // ---------- 1/2: grade de 64 casas + posição do teste (peão em d3), brancas embaixo
        String exp = D3FIX();
        check(exp.charAt(43) == 'P' && exp.charAt(51) == '.' && exp.indexOf('P') >= 0, "gabarito d3");
        int[] img = render(exp, th, W, H, bx, by, Set.of(51, 43), null);
        int[] rough = {truth[0] + 9, truth[1] - 7, truth[2] - 6, truth[3] + 8}; // toque manual impreciso (quadrado ~ +-8px)
        rough[2] = rough[0] + (truth[2] - truth[0] - 15); rough[3] = rough[1] + (rough[2] - rough[0]);
        R r = read(img, W, H, rough, true, true, true, null, null);
        System.out.println("D3 white-bottom: " + r.status + " learned=" + r.learned + " grid=" + r.grid + " rect=" + Arrays.toString(r.rect) + " unc=" + r.unc);
        check(r.rect != null && Math.abs(r.rect[0] - truth[0]) <= 2 && Math.abs(r.rect[1] - truth[1]) <= 2 && Math.abs(r.rect[2] - truth[2]) <= 2 && Math.abs(r.rect[3] - truth[3]) <= 2, "snap às bordas reais (64 casas): " + Arrays.toString(r.rect));
        check(r.status.equals("OK"), "leitura OK: " + r.message);
        check(r.labels.equals(exp), "posição reconstruída:\n" + r.labels + "\n" + exp);
        check(Board.invalidReason(r.labels) == null, "posição válida");
        Board init = new Board(Board.INITIAL);
        Board rec = init.recover(r.labels);
        check(rec != null && !rec.white && rec.fen().startsWith("rnbqkbnr/pppppppp/8/8/8/3P4/PPP1PPPP/RNBQKBNR b"), "recover: d2-d3, pretas jogam: " + (rec == null ? null : rec.fen()));
        boolean[] g = new boolean[1]; Board obs = Board.fromObserved(r.labels, true, g);
        check(obs != null && g[0], "fromObserved sem histórico: lado indeterminável (assumido)");

        // ---------- 3: pretas embaixo
        Theme tb = new Theme(); tb.flip = true;
        int[] img2 = render(exp, tb, W, H, bx, by, null, null);
        R rb = read(img2, W, H, rough, true, false, true, null, null);
        check(rb.status.equals("OK") && rb.labels.equals(exp), "orientação pretas embaixo: " + rb.status + " " + rb.message);

        // ---------- 4: meio-jogo com várias casas vazias, peças de ambas as cores
        String mid = PLAIN("r..q.rk./pp..bppp/..n.pn../..pp..../......../..NP.N../PPP.BPPP/R..Q.RK.");
        check(mid.length() == 64, "len mid");
        int[] im3 = render(mid, th, W, H, bx, by, Set.of(10, 20), Set.of(30, 31));
        R rm = read(im3, W, H, rough, true, true, false, null, null);
        System.out.println("mid (sem aprender): " + rm.status + " " + rm.message);
        // Propriedade essencial: nunca inventa/troca peça; '.' só onde está vazio
        for (int i = 0; i < 64; i++) if (rm.labels.charAt(i) != '?') check(rm.labels.charAt(i) == mid.charAt(i), "sem inventar peça em " + Board.name(i) + ": " + rm.labels.charAt(i) + " vs " + mid.charAt(i));

        // ---------- 5: aprendizado do tema com estrutura inicial + leitura posterior com biblioteca aprendida
        Theme alien = new Theme(); alien.light = 0xF0D9B5; alien.dark = 0xB58863; alien.cell = 96; alien.sx = 1.5f; alien.sy = 0.95f; alien.wA = 30; alien.wB = .75f; alien.bA = 40; alien.bB = .5f;
        int ab = 80, ay = 200, as = alien.cell * 8; int[] aroughs = {ab + 5, ay + 5, ab + as - 5, ay + as - 5};
        int[] imA = render(exp, alien, W, H, ab, ay, null, null);
        Object[] lo = new Object[1];
        R ra = read(imA, W, H, aroughs, true, true, true, null, lo);
        System.out.println("alien: " + ra.status + " learned=" + ra.learned + " unc=" + ra.unc);
        for (int i = 0; i < 64; i++) if (ra.labels.charAt(i) != '?') check(ra.labels.charAt(i) == exp.charAt(i), "alien sem inventar em " + Board.name(i));
        check(ra.status.equals("OK") && ra.labels.equals(exp), "tema diferente lido com aprendizado: " + ra.message);
        check(ra.learned, "usou modelos aprendidos");
        // depois: lance e5 jogado, biblioteca aprendida reutilizada (sem estrutura inicial)
        String after = new String(exp);
        char[] ac = after.toCharArray(); ac[12] = '.'; ac[28] = 'p'; ac[52] = '.'; ac[36] = 'P'; after = new String(ac);
        int[] imA2 = render(after, alien, W, H, ab, ay, null, null);
        R ra2 = read(imA2, W, H, ra.rect, false, true, false, lo[0], null);
        check(ra2.status.equals("OK") && ra2.labels.equals(after), "leitura posterior com biblioteca aprendida: " + ra2.message + "\n" + ra2.labels);

        // ---------- 6: casas encobertas -> '?' nas encobertas, nada inventado
        int[] imC = render(exp, th, W, H, bx, by, null, null);
        for (int y = by + th.cell * 4; y < by + th.cell * 5; y++) for (int x = bx + th.cell * 3; x < bx + th.cell * 5; x++) imC[y * W + x] = 0xFF1B3B55; // painel por cima de e4/d4? (linha 4, colunas 3-4)
        R rc = read(imC, W, H, truth, false, true, false, null, null);
        System.out.println("cobertas: " + rc.status + " " + rc.message);
        check(rc.status.equals("UNCERTAIN") || rc.status.equals("NO_GRID"), "casas encobertas não passam como OK");
        if (rc.status.equals("UNCERTAIN")) for (int i = 0; i < 64; i++) if (rc.labels.charAt(i) != '?') check(rc.labels.charAt(i) == exp.charAt(i), "cobertas: nada inventado em " + Board.name(i));
        check(!rc.labels.equals(exp), "cobertas: leitura diferente da posição real não é aceita como OK");

        // ---------- 7: captura incompleta (área cortada pela metade) e área sem tabuleiro
        R rinc = read(img, W, H, new int[]{bx, by + s / 2, bx + s, by + s / 2 + s}, false, true, true, null, null);
        check(!rinc.status.equals("OK"), "captura incompleta (borda inferior fora): " + rinc.status);
        R rcut = read(img, W, H, new int[]{bx + 200, by, bx + 200 + s, by + s}, false, true, true, null, null);
        check(!rcut.status.equals("OK") || !Board.invalidReason(rcut.labels).equals(null), "área deslocada não vira posição válida: " + rcut.status);
        int[] gray = new int[W * H]; Arrays.fill(gray, 0xFF808080);
        R rg = read(gray, W, H, truth, true, true, true, null, null);
        check(rg.status.equals("NO_GRID"), "imagem sem tabuleiro -> NO_GRID: " + rg.status);
        Random rnd = new Random(7); int[] noise = new int[W * H]; for (int i = 0; i < noise.length; i++) noise[i] = 0xFF000000 | rnd.nextInt(0xFFFFFF);
        R rn = read(noise, W, H, truth, true, true, true, null, null);
        check(!rn.status.equals("OK"), "ruído não vira posição: " + rn.status);

        // ---------- 8: baixa confiança: peça substituída por mancha que não é peça
        int[] imL = render(exp, th, W, H, bx, by, null, null);
        int cx0 = bx + th.cell * 4 + 20, cy0 = by + th.cell * 3 + 20; // e5 vazia
        for (int y = 0; y < th.cell - 40; y++) for (int x = 0; x < th.cell - 40; x++) if (((x / 7) + (y / 7)) % 2 == 0) imL[(cy0 + y) * W + cx0 + x] = 0xFF404040;
        R rl = read(imL, W, H, truth, false, true, false, null, null);
        check(rl.status.equals("UNCERTAIN") && rl.labels.charAt(28) == '?' && rl.unc.contains("e5"), "mancha estranha em e5 -> '?' e listada: " + rl.status + " " + rl.unc);

        // ---------- 9: entradas degeneradas nunca lançam exceção
        for (int[] bad : new int[][]{{0, 0, 0, 0}, {-5, -5, 100, 100}, {0, 0, W + 50, H + 50}, {10, 10, 30, 30}}) {
            R rr = read(img, W, H, bad, true, true, true, null, null);
            check(!rr.status.equals("OK"), "área inválida " + Arrays.toString(bad) + " -> " + rr.status);
        }

        // ---------- 10: validação de posição
        check(Board.invalidReason(HOME()) == null, "posição inicial válida");
        check(Board.invalidReason(HOME().replace('K', '.')) != null, "sem rei branco inválida");
        check(Board.invalidReason(HOME().replace("RNBQKBNR", "RNBQKBNP")) != null, "peão na fileira 1 inválida");
        check(Board.invalidReason("?" + HOME().substring(1)) != null, "'?' inválida");
        check(Board.invalidReason(HOME().replace('n', 'q')) != null, "peças pretas demais para peões");
        String chk = PLAIN("....k.../......../......../......../......../......../....r.../....K...");
        Board bc = Board.fromObserved(chk, false, g); check(bc != null && bc.white && !g[0], "xeque define o lado: brancas em xeque jogam");
        String both = PLAIN("....k.../........./".substring(0, 9) + "......./......../......../......../......../....R.../....K...");
        check(Board.fromObserved(PLAIN("....kR../......../......../......../......../......../....r.../....K..."), true, g) == null, "xeque duplo impossível");
        check(Board.fromObserved(HOME(), true, g) != null && g[0], "inicial sem xeque: lado assumido sinalizado");
        check(!new Board(Board.INITIAL).fen().isEmpty(), "Board intacto");


        // ---------- 11: CAPTURA REAL (Chess.com no Brave, Redmi 1080x2400) e variante com peão em d3
        File fx = new File(args.length > 1 ? args[1] : "tests/fixtures/chesscom-brave-inicial.jpg");
        check(fx.exists(), "fixture da captura real ausente: " + fx);
        BufferedImage ri = ImageIO.read(fx); int RW = ri.getWidth(), RH = ri.getHeight();
        int[] rp = new int[RW * RH]; ri.getRGB(0, 0, RW, RH, rp, 0, RW);
        int[] rr0 = {90, 565, 1065, 1540}; // toque manual impreciso; tabuleiro real = 83,557,1073,1547
        R real0 = read(rp, RW, RH, rr0, true, true, false, null, null);
        check(real0.rect != null && Math.abs(real0.rect[0] - 83) <= 2 && Math.abs(real0.rect[1] - 557) <= 2 && Math.abs(real0.rect[2] - 1073) <= 2 && Math.abs(real0.rect[3] - 1547) <= 2, "real: recorte exato " + Arrays.toString(real0.rect));
        for (int i = 0; i < 64; i++) if (real0.labels.charAt(i) != '?') check(real0.labels.charAt(i) == HOME().charAt(i), "real (modelos embutidos): nada errado em " + Board.name(i));
        Object[] rl2 = new Object[1];
        R realL = read(rp, RW, RH, rr0, true, true, true, null, rl2);
        check(realL.status.equals("OK") && realL.labels.equals(HOME()) && realL.learned, "real: posição inicial completa com aprendizado: " + realL.message + " " + realL.labels);
        check(Board.invalidReason(realL.labels) == null, "real: posição válida");
        // variante: move o peão d2->d3 editando pixels (peão de c2, casa clara, vai para d3, casa clara; d2 recebe fundo de d4)
        int cw = 990 / 8; int[] vp = rp.clone();
        int c2x = 83 + 2 * cw, c2y = 557 + 6 * cw, d3x = 83 + 3 * cw, d3y = 557 + 5 * cw, d2x = 83 + 3 * cw, d2y = 557 + 6 * cw, d4x = 83 + 3 * cw, d4y = 557 + 4 * cw;
        for (int y = 0; y < cw; y++) for (int x = 0; x < cw; x++) { vp[(d3y + y) * RW + d3x + x] = rp[(c2y + y) * RW + c2x + x]; vp[(d2y + y) * RW + d2x + x] = rp[(d4y + y) * RW + d4x + x]; }
        R realD3 = read(vp, RW, RH, rr0, true, true, true, null, null);
        check(realD3.status.equals("OK") && realD3.labels.equals(D3FIX()), "real: d3 lido como está (sem assumir posição inicial): " + realD3.message + "\n" + realD3.labels);
        Board rrec = new Board(Board.INITIAL).recover(realD3.labels);
        check(rrec != null && !rrec.white, "real d3: pretas a jogar via recuperação");
        R realD3b = read(vp, RW, RH, new int[]{83, 557, 1073, 1547}, false, true, false, rl2[0], null);
        check(realD3b.status.equals("OK") && realD3b.labels.equals(D3FIX()), "real d3 com tema aprendido antes: " + realD3b.message);
        // pretas embaixo: gira a imagem de tabuleiro 180 graus nos pixels do tabuleiro
        int[] fp = rp.clone();
        for (int y = 0; y < 990; y++) for (int x = 0; x < 990; x++) fp[(557 + y) * RW + 83 + x] = rp[(557 + 989 - y) * RW + 83 + 989 - x];
        R realF = read(fp, RW, RH, rr0, true, false, true, null, null);
        check(realF.status.equals("OK") && realF.labels.equals(HOME()), "real: orientação pretas embaixo: " + realF.message + " " + realF.labels);
        // painel encobrindo casas reais
        int[] cp = rp.clone();
        for (int y = 557 + 3 * cw; y < 557 + 5 * cw; y++) for (int x = 83 + 2 * cw; x < 83 + 5 * cw; x++) cp[y * RW + x] = 0xFF0F2B3B;
        R realC = read(cp, RW, RH, new int[]{83, 557, 1073, 1547}, false, true, true, null, null);
        check(!realC.status.equals("OK"), "real: casas encobertas não são OK");
        for (int i = 0; i < 64; i++) if (realC.labels.charAt(i) != '?') check(realC.labels.charAt(i) == HOME().charAt(i), "real encoberta: nada inventado em " + Board.name(i));
        // orientação errada (usuário escolheu a cor errada): detectada pela estrutura inicial de cabeça para baixo
        R wrongO = read(rp, RW, RH, new int[]{83, 557, 1073, 1547}, false, false, true, null, null);
        check(Board.whiteLooksOnTop(wrongO.labels) || !wrongO.status.equals("OK"), "orientação errada detectável: " + wrongO.labels);
        check(!Board.whiteLooksOnTop(realL.labels) && !Board.whiteLooksOnTop(realF.labels), "orientação certa não dispara correção");
        check(Board.whiteLooksOnTop(rotate(HOME())), "estrutura girada detectada");
        check(!Board.whiteLooksOnTop(D3FIX()), "d3 não dispara correção");
        System.out.println("real: recorte=" + Arrays.toString(real0.rect) + " embutidos incertas=" + real0.unc + " aprendido=" + realL.status);

        System.out.println("PASS BoardReaderTest: " + passed + " verificações");
    }
}
