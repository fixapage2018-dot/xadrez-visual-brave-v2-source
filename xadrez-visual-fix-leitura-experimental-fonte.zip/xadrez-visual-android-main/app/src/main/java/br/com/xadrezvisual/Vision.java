package br.com.xadrezvisual;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Ponte entre o Android (Bitmap/Rect) e o reconhecedor em Java puro {@link BoardReader}.
 *
 * Causa raiz da "Leitura incerta" na versão anterior: as imagens de referência são casas
 * 2D em marrom/creme com coordenadas, e a comparação era pixel a pixel (máscara de pixels
 * "sem cor" + brilho). Qualquer outro tema (ex.: casas verdes e peças 3D cinza do Chess.com)
 * nunca ficava abaixo do limite de distância, e uma única casa '?' derrubava a leitura inteira.
 * Agora a leitura é por silhueta, independente de cor/tema, com aprendizado do tema na
 * própria tela quando a estrutura inicial está visível.
 */
final class Vision {

    private final BoardReader.Library stat;
    private volatile BoardReader.Library learned;

    Vision(Context ctx) throws IOException {
        List<int[]> px = new ArrayList<>();
        List<int[]> dims = new ArrayList<>();
        List<Character> labels = new ArrayList<>();
        String[] names = ctx.getAssets().list("pieces");
        if (names != null) {
            for (String n : names) {
                if (!n.endsWith(".png")) continue;
                try (InputStream in = ctx.getAssets().open("pieces/" + n)) {
                    Bitmap b = BitmapFactory.decodeStream(in);
                    if (b == null) continue;
                    int[] p = new int[b.getWidth() * b.getHeight()];
                    b.getPixels(p, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
                    px.add(p);
                    dims.add(new int[]{b.getWidth(), b.getHeight()});
                    labels.add(n.charAt(0));
                    b.recycle();
                }
            }
        }
        stat = BoardReader.buildStatic(px, dims, labels);
        if (stat.isEmpty()) throw new IOException("Referências das peças ausentes");
    }

    /** Esquece o tema aprendido (nova partida, nova área, nova captura). */
    void reset() { learned = null; }

    /**
     * Lê o tabuleiro. {@code snap}: ajustar às bordas reais (use só até a primeira leitura válida).
     * {@code allowLearn}: permite aprender o tema com a estrutura inicial visível.
     * O Result.rect vem em coordenadas de tela.
     */
    BoardReader.Result read(Bitmap bmp, Rect rough, boolean whiteBottom, boolean snap, boolean allowLearn) {
        int W = bmp.getWidth(), H = bmp.getHeight();
        int m = (int) (0.15f * rough.width());
        int x0 = Math.max(0, rough.left - m), y0 = Math.max(0, rough.top - m);
        int x1 = Math.min(W, rough.right + m), y1 = Math.min(H, rough.bottom + m);
        int ww = x1 - x0, wh = y1 - y0;
        BoardReader.Result bad = new BoardReader.Result();
        if (ww <= 0 || wh <= 0 || rough.left < 0 || rough.top < 0 || rough.right > W || rough.bottom > H) {
            bad.message = "Área fora da tela: selecione o tabuleiro novamente";
            return bad;
        }
        int[] win = new int[ww * wh];
        bmp.getPixels(win, 0, ww, x0, y0, ww, wh);
        int[] r = {rough.left - x0, rough.top - y0, rough.right - x0, rough.bottom - y0};
        if (learned != null && Math.abs(learned.cellSize - rough.width()) > 0.15f * rough.width()) learned = null;
        BoardReader.Library[] holder = new BoardReader.Library[1];
        BoardReader.Result res = BoardReader.read(win, ww, wh, r, snap, whiteBottom, stat, learned, allowLearn, holder);
        if (res.rect != null) res.rect = new int[]{res.rect[0] + x0, res.rect[1] + y0, res.rect[2] + x0, res.rect[3] + y0};
        if (holder[0] != null && res.learnedUsed) learned = holder[0];
        return res;
    }
}
