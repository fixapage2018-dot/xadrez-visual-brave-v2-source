package br.com.xadrezvisual;
import java.io.*;import java.util.*;import java.util.concurrent.*;
/** UCI with bounded waits; never blocks the Android main thread. */
final class Engine implements AutoCloseable {
 private final Process process;private final BufferedWriter input;private final BlockingQueue<String> output=new LinkedBlockingQueue<>(8192);private final Random random=new Random();
 Engine(String path)throws Exception {process=new ProcessBuilder(path).redirectErrorStream(true).start();input=new BufferedWriter(new OutputStreamWriter(process.getOutputStream()));Thread reader=new Thread(()->{try(BufferedReader b=new BufferedReader(new InputStreamReader(process.getInputStream()))){String s;while((s=b.readLine())!=null){if(!output.offer(s)){output.poll();output.offer(s);}}}catch(IOException ignored){}finally{output.offer("ENGINE_EXIT");}},"stockfish-output");reader.setDaemon(true);reader.start();send("uci");until("uciok",10000);send("setoption name Threads value 2");send("setoption name Hash value 32");send("setoption name MultiPV value 3");send("isready");until("readyok",10000);}
 private void send(String s)throws IOException{input.write(s);input.newLine();input.flush();}
 private String next(long end)throws Exception{long ms=end-System.currentTimeMillis();if(ms<=0)throw new IOException("Motor excedeu o tempo de resposta");String s=output.poll(ms,TimeUnit.MILLISECONDS);if(s==null||s.equals("ENGINE_EXIT"))throw new IOException("Motor parou ou não respondeu");return s;}
 private void until(String expected,int ms)throws Exception{long end=System.currentTimeMillis()+ms;while(!next(end).startsWith(expected)){} }
 record Choice(String move,int score,int depth){}
 synchronized String best(Board board,int bestPercent)throws Exception{send("position fen "+board.fen());send("go movetime 350");long end=System.currentTimeMillis()+6000;Map<Integer,Choice> candidates=new HashMap<>();String best="";while(true){String line=next(end);if(line.startsWith("bestmove ")){best=line.split(" ")[1];break;}if(line.startsWith("info ")&&line.contains(" pv ")&&line.contains(" score cp ")&&!line.contains("bound")){String[] a=line.split(" ");try{int rank=1,score=0,depth=0;String move="";for(int i=0;i<a.length-1;i++){if(a[i].equals("depth"))depth=Integer.parseInt(a[i+1]);if(a[i].equals("multipv"))rank=Integer.parseInt(a[i+1]);if(a[i].equals("score")&&a[i+1].equals("cp"))score=Integer.parseInt(a[i+2]);if(a[i].equals("pv")){move=a[i+1];break;}}if(!move.isEmpty())candidates.put(rank,new Choice(move,score,depth));}catch(RuntimeException ignored){}}}
  if(best.equals("(none)")||best.equals("0000"))return "";
  if(random.nextInt(100)>=bestPercent&&candidates.containsKey(1)&&candidates.get(1).move.equals(best)){Choice top=candidates.get(1);List<String> choices=new ArrayList<>();for(var e:candidates.entrySet())if(e.getKey()>1&&e.getValue().depth==top.depth&&!e.getValue().move.equals(best)&&top.score-e.getValue().score>=0&&top.score-e.getValue().score<=150)choices.add(e.getValue().move);if(!choices.isEmpty())best=choices.get(random.nextInt(choices.size()));}
  final String selected=best;if(board.legal().stream().noneMatch(m->m.uci().equals(selected)))throw new IOException("Motor devolveu lance inválido");return best;
 }
 public void close(){process.destroy();}
}
