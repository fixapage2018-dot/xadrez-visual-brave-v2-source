package br.com.xadrezvisual;

/**
 * Ajuste ("snap") da área aproximada para as bordas reais do tabuleiro, em pixels ARGB.
 * Mesma ideia da versão anterior (cores das duas casas -> máscara -> bordas), mas sem
 * dependência do Android e devolvendo null quando as bordas não são plausíveis.
 * O chamador compara o resultado com a área original pela qualidade da grade 8x8.
 */
final class BoardGeometry {
    private static final int SAT_MIN = 18;

    private BoardGeometry() {}

    /** @return {l,t,r,b} ajustado, ou null se não for possível. */
    static int[] snap(int[] px, int W, int H, int[] rough) {
        int w = rough[2] - rough[0], h = rough[3] - rough[1];
        if (w < 80 || h < 80) return null;
        int m = (int) (0.12f * w);
        int x0 = Math.max(0, rough[0] - m), x1 = Math.min(W, rough[2] + m);
        int y0 = Math.max(0, rough[1] - m), y1 = Math.min(H, rough[3] + m);
        int ww = x1 - x0, wh = y1 - y0;
        if (ww <= 0 || wh <= 0) return null;

        int[] hist = new int[4096];
        int ix0 = Math.max(0, rough[0]), ix1 = Math.min(W, rough[2]);
        int iy0 = Math.max(0, rough[1]), iy1 = Math.min(H, rough[3]);
        for (int y = iy0; y < iy1; y += 2) for (int x = ix0; x < ix1; x += 2) {
            int p = px[y * W + x];
            int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
            if (Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b)) < SAT_MIN) continue;
            hist[((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4)]++;
        }
        int ka = -1;
        for (int k = 0; k < 4096; k++) if (ka < 0 || hist[k] > hist[ka]) ka = k;
        if (ka < 0 || hist[ka] == 0) return null;
        int[] ca = center(ka);
        int kb = -1;
        for (int k = 0; k < 4096; k++) {
            if (hist[k] == 0) continue;
            int[] c = center(k);
            if (Math.abs((c[0] + c[1] + c[2]) - (ca[0] + ca[1] + ca[2])) <= 45) continue;
            if (kb < 0 || hist[k] > hist[kb]) kb = k;
        }
        if (kb < 0) return null;
        int[] cb = center(kb);

        int cy0 = Math.max(0, (int) (rough[1] + 0.2f * h) - y0), cy1 = Math.min(wh, (int) (rough[1] + 0.8f * h) - y0);
        int cx0 = Math.max(0, (int) (rough[0] + 0.2f * w) - x0), cx1 = Math.min(ww, (int) (rough[0] + 0.8f * w) - x0);
        if (cy1 <= cy0 || cx1 <= cx0) return null;
        int[] colHit = new int[ww], rowHit = new int[wh];
        for (int y = 0; y < wh; y++) for (int x = 0; x < ww; x++) {
            int p = px[(y0 + y) * W + x0 + x];
            int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
            if (!(close(r, g, b, ca) || close(r, g, b, cb))) continue;
            if (y >= cy0 && y < cy1) colHit[x]++;
            if (x >= cx0 && x < cx1) rowHit[y]++;
        }
        int nl = first(colHit, 0.30f * (cy1 - cy0)), nr = last(colHit, 0.30f * (cy1 - cy0)) + 1;
        int nt = first(rowHit, 0.30f * (cx1 - cx0)), nb = last(rowHit, 0.30f * (cx1 - cx0)) + 1;
        if (nl < 0 || nt < 0 || nr <= 0 || nb <= 0) return null;
        nl += x0; nr += x0; nt += y0; nb += y0;
        int nw = nr - nl, nh = nb - nt;
        if (nw <= 0 || nh <= 0) return null;
        if (Math.abs(nw - nh) > 0.03f * Math.max(nw, nh)) return null;
        if (nw < 0.5f * w || nw > 1.6f * w) return null;
        return new int[]{nl, nt, nr, nb};
    }

    private static int[] center(int k) {
        return new int[]{((k >> 8) & 15) * 16 + 8, ((k >> 4) & 15) * 16 + 8, (k & 15) * 16 + 8};
    }

    private static boolean close(int r, int g, int b, int[] c) {
        return Math.abs(r - c[0]) <= 24 && Math.abs(g - c[1]) <= 24 && Math.abs(b - c[2]) <= 24;
    }

    private static int first(int[] a, float t) { for (int i = 0; i < a.length; i++) if (a[i] >= t) return i; return -1; }
    private static int last(int[] a, float t) { for (int i = a.length - 1; i >= 0; i--) if (a[i] >= t) return i; return -1; }
}
