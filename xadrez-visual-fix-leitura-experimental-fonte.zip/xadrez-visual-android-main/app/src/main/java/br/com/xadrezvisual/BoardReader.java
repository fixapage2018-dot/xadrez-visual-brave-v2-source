package br.com.xadrezvisual;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Reconhecimento do tabuleiro em um vetor de pixels ARGB (sem dependências do Android,
 * para poder ser testado na JVM).
 *
 * Princípios (não depende do tema de cores nem do desenho das peças):
 *  1. A grade 8x8 é validada pelo padrão xadrez das cores de fundo das casas.
 *  2. Cada casa tem seu fundo estimado pelo anel externo da própria casa (cobre casas
 *     destacadas); vazio/ocupado vem da silhueta (pixels que diferem do fundo),
 *     ignorando as coordenadas impressas nos cantos.
 *  3. Cor da peça: luminância do interior da silhueta, separada por limiar adaptativo.
 *  4. Tipo da peça: silhueta normalizada contra (a) modelos embutidos ou (b) modelos
 *     aprendidos nesta mesma tela quando a estrutura inicial está visível.
 *  5. Qualquer casa sem evidência suficiente vira '?' — nunca é adivinhada.
 */
final class BoardReader {

    static final int G = 48;      // grade de análise por casa
    static final int S = 32;      // grade da silhueta normalizada
    static final int PROF = 16;   // linhas do perfil de largura

    static final float DIST_FG = 34f;
    static final float EMPTY_AREA = 0.02f;    // abaixo: casa vazia
    static final float PIECE_AREA = 0.07f;    // acima (e componente grande): peça
    static final float GRID_MIN = 0.85f;

    static final float STATIC_MIN_SIM = 0.80f, STATIC_MIN_GAP = 0.04f;
    static final float LEARNED_MIN_SIM = 0.80f, LEARNED_MIN_GAP = 0.04f;

    static final String HOME =
            "rnbqkbnr" + "pppppppp" + "........" + "........" + "........" + "........" + "PPPPPPPP" + "RNBQKBNR";

    enum Status { OK, BAD_AREA, NO_GRID, UNCERTAIN }

    static final class Result {
        Status status = Status.BAD_AREA;
        String labels = "?".repeat(64);          // ordem a8..h1 (orientação já aplicada)
        String message = "";
        List<String> uncertain = new ArrayList<>();
        int[] rect;                              // l,t,r,b no sistema de coordenadas recebido
        float gridScore;
        boolean learnedUsed;
        boolean learnedNow;
        boolean ok() { return status == Status.OK; }
    }

    /** Silhueta normalizada de um modelo. */
    static final class Sil {
        final char type; final float[] m; final boolean[] dil; final float[] prof; final float aspect;
        Sil(char type, float[] m, float[] prof, float aspect) {
            this.type = type; this.m = m; this.prof = prof; this.aspect = aspect;
            this.dil = dilate(m, 2);
        }
        Sil mirrored() {
            float[] f = new float[S * S];
            for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) f[y * S + x] = m[y * S + (S - 1 - x)];
            return new Sil(type, f, prof, aspect);
        }
    }

    static final class Library {
        final List<Sil> items = new ArrayList<>();
        final boolean learned;
        float lumWhite = Float.NaN, lumBlack = Float.NaN;
        int cellSize;
        Library(boolean learned) { this.learned = learned; }
        void add(Sil s) { items.add(s); }
        boolean isEmpty() { return items.isEmpty(); }
    }

    /** Resultado da análise de uma casa. */
    static final class Cell {
        boolean emptyCell, uncertainCell, bgOk;
        float area, lum = Float.NaN;
        float[] bg = new float[3];
        float bgSat;
        Sil sil;           // silhueta da peça (type '?')
    }

    // ------------------------------------------------------------------ biblioteca embutida

    /** Cria a biblioteca a partir de recortes de casa (cada recorte = uma casa inteira). */
    static Library buildStatic(List<int[]> pixels, List<int[]> dims, List<Character> labels) {
        Library lib = new Library(false);
        for (int i = 0; i < pixels.size(); i++) {
            int w = dims.get(i)[0], h = dims.get(i)[1];
            Cell c = analyzeCell(pixels.get(i), w, 0, 0, w, h);
            if (c.sil == null) continue;
            char t = Character.toLowerCase(labels.get(i));
            Sil s = new Sil(t, c.sil.m, c.sil.prof, c.sil.aspect);
            lib.add(s);
            lib.add(s.mirrored());
        }
        return lib;
    }

    // ------------------------------------------------------------------ análise de casa

    static Cell analyzeCell(int[] px, int W, int x0, int y0, int cw, int ch) { return analyzeCell(px, W, x0, y0, cw, ch, null); }

    static Cell analyzeCell(int[] px, int W, int x0, int y0, int cw, int ch, float[] opp) {
        Cell out = new Cell();
        float[][] c = new float[3][G * G];
        for (int gy = 0; gy < G; gy++) {
            int ya = y0 + gy * ch / G, yb = Math.max(ya + 1, y0 + (gy + 1) * ch / G);
            for (int gx = 0; gx < G; gx++) {
                int xa = x0 + gx * cw / G, xb = Math.max(xa + 1, x0 + (gx + 1) * cw / G);
                long r = 0, g = 0, b = 0; int n = 0;
                for (int y = ya; y < yb; y++) for (int x = xa; x < xb; x++) {
                    int p = px[y * W + x];
                    r += (p >> 16) & 255; g += (p >> 8) & 255; b += p & 255; n++;
                }
                int i = gy * G + gx;
                c[0][i] = r / (float) n; c[1][i] = g / (float) n; c[2][i] = b / (float) n;
            }
        }
        // fundo: moda do anel (distância 2..4 células da borda)
        int[] hist = new int[4096];
        for (int gy = 0; gy < G; gy++) for (int gx = 0; gx < G; gx++) {
            int d = Math.min(Math.min(gx, gy), Math.min(G - 1 - gx, G - 1 - gy));
            if (d < 2 || d > 4) continue;
            int i = gy * G + gx;
            if (overlayGreen(c[0][i], c[1][i], c[2][i])) continue;
            hist[(((int) c[0][i] >> 4) << 8) | (((int) c[1][i] >> 4) << 4) | ((int) c[2][i] >> 4)]++;
        }
        int best = 0;
        for (int k = 1; k < 4096; k++) if (hist[k] > hist[best]) best = k;
        float[] ref = {((best >> 8) & 15) * 16 + 8, ((best >> 4) & 15) * 16 + 8, (best & 15) * 16 + 8};
        double sr = 0, sg = 0, sb = 0; int sn = 0, ringN = 0;
        for (int gy = 0; gy < G; gy++) for (int gx = 0; gx < G; gx++) {
            int d = Math.min(Math.min(gx, gy), Math.min(G - 1 - gx, G - 1 - gy));
            if (d < 2 || d > 4) continue;
            int i = gy * G + gx;
            if (overlayGreen(c[0][i], c[1][i], c[2][i])) continue;
            ringN++;
            if (dist(c, i, ref) <= 24) { sr += c[0][i]; sg += c[1][i]; sb += c[2][i]; sn++; }
        }
        if (sn == 0) { out.uncertainCell = true; return out; }
        out.bg = new float[]{(float) (sr / sn), (float) (sg / sn), (float) (sb / sn)};
        out.bgOk = sn >= 0.5f * ringN;
        out.bgSat = Math.max(out.bg[0], Math.max(out.bg[1], out.bg[2])) - Math.min(out.bg[0], Math.min(out.bg[1], out.bg[2]));

        // primeiro plano
        boolean[] fg = new boolean[G * G];
        boolean[] unknown = new boolean[G * G];
        for (int gy = 2; gy < G - 2; gy++) for (int gx = 2; gx < G - 2; gx++) {
            int i = gy * G + gx;
            float d = dist(c, i, out.bg);
            float sat = Math.max(c[0][i], Math.max(c[1][i], c[2][i])) - Math.min(c[0][i], Math.min(c[1][i], c[2][i]));
            // peça branca sobre casa colorida: preenchimento acromático
            boolean f = d > DIST_FG || (out.bgSat >= 24 && sat <= 10 && d >= 12);
            if (overlayGreen(c[0][i], c[1][i], c[2][i])) { unknown[i] = true; f = false; }   // círculo de dica do app
            fg[i] = f;
        }
        fillUnknown(fg, unknown);
        // cantos: coordenadas impressas (letras/dígitos, na cor da casa oposta) e selos coloridos
        // (ex.: ícone de livro de aberturas) deformavam a silhueta (a letra "d" encostada na dama,
        // o selo no canto de c6). Remove só pixels com a cor desses elementos, nunca bordas de peça.
        boolean[] chrom = new boolean[G * G];
        for (int i = 0; i < G * G; i++) {
            float sat = Math.max(c[0][i], Math.max(c[1][i], c[2][i])) - Math.min(c[0][i], Math.min(c[1][i], c[2][i]));
            chrom[i] = sat >= 55f && dist(c, i, out.bg) > 60f;
        }
        boolean[] kill = new boolean[G * G];
        for (int gy = 2; gy < G - 2; gy++) for (int gx = 2; gx < G - 2; gx++) {
            int i = gy * G + gx;
            if (!fg[i] || !((gx < 15 || gx >= 33) && (gy < 15 || gy >= 33))) continue;
            if (opp != null && dist(c, i, opp) <= 30f) { kill[i] = true; continue; }
            if (out.bgSat < 24) continue;
            for (int dy = -2; dy <= 2 && !kill[i]; dy++) for (int dx = -2; dx <= 2; dx++) {
                int yy = gy + dy, xx = gx + dx;
                if (yy >= 0 && xx >= 0 && yy < G && xx < G && chrom[yy * G + xx]) { kill[i] = true; break; }
            }
        }
        for (int i = 0; i < G * G; i++) if (kill[i]) fg[i] = false;
        // componentes conexos; descarta rótulos de coordenada (cantos) e ruído
        int[] comp = new int[G * G];
        List<int[]> boxes = new ArrayList<>(); // minx,miny,maxx,maxy,area
        int[] stack = new int[G * G];
        for (int s = 0; s < G * G; s++) {
            if (!fg[s] || comp[s] != 0) continue;
            int id = boxes.size() + 1, sp = 0, area = 0;
            int[] bx = {G, G, -1, -1, 0};
            stack[sp++] = s; comp[s] = id;
            while (sp > 0) {
                int i = stack[--sp]; int x = i % G, y = i / G; area++;
                bx[0] = Math.min(bx[0], x); bx[1] = Math.min(bx[1], y); bx[2] = Math.max(bx[2], x); bx[3] = Math.max(bx[3], y);
                if (x > 0 && fg[i - 1] && comp[i - 1] == 0) { comp[i - 1] = id; stack[sp++] = i - 1; }
                if (x < G - 1 && fg[i + 1] && comp[i + 1] == 0) { comp[i + 1] = id; stack[sp++] = i + 1; }
                if (y > 0 && fg[i - G] && comp[i - G] == 0) { comp[i - G] = id; stack[sp++] = i - G; }
                if (y < G - 1 && fg[i + G] && comp[i + G] == 0) { comp[i + G] = id; stack[sp++] = i + G; }
            }
            bx[4] = area;
            boxes.add(bx);
        }
        boolean[] keep = new boolean[boxes.size() + 1];
        int total = 0, largest = 0;
        int minX = G, minY = G, maxX = -1, maxY = -1;
        for (int k = 0; k < boxes.size(); k++) {
            int[] b = boxes.get(k);
            boolean corner = (b[2] <= 16 && b[3] <= 16) || (b[0] >= 31 && b[1] >= 31)
                    || (b[2] <= 16 && b[1] >= 31) || (b[0] >= 31 && b[3] <= 16);
            if (b[4] < 10) continue;
            if (corner && b[4] < 0.06f * G * G) continue;
            keep[k + 1] = true;
            total += b[4]; largest = Math.max(largest, b[4]);
            minX = Math.min(minX, b[0]); minY = Math.min(minY, b[1]); maxX = Math.max(maxX, b[2]); maxY = Math.max(maxY, b[3]);
        }
        out.area = total / (float) (G * G);
        if (out.area < EMPTY_AREA) { out.emptyCell = true; return out; }
        if (out.area < PIECE_AREA || largest < 0.05f * G * G) { out.uncertainCell = true; return out; }

        boolean[] mask = new boolean[G * G];
        for (int i = 0; i < G * G; i++) mask[i] = comp[i] > 0 && keep[comp[i]];
        int w = maxX - minX + 1, h = maxY - minY + 1;
        // silhueta normalizada pelo maior lado, centrada na caixa
        int m = Math.max(w, h);
        float cx = minX + w / 2f, cy = minY + h / 2f;
        float[] sil = new float[S * S];
        for (int j = 0; j < S; j++) for (int i = 0; i < S; i++) {
            int hit = 0;
            for (int sy = 0; sy < 2; sy++) for (int sx = 0; sx < 2; sx++) {
                float fx = cx + ((i + (sx + .5f) / 2f) - S / 2f) * m / S;
                float fy = cy + ((j + (sy + .5f) / 2f) - S / 2f) * m / S;
                int ix = (int) Math.floor(fx), iy = (int) Math.floor(fy);
                if (ix >= 0 && iy >= 0 && ix < G && iy < G && mask[iy * G + ix]) hit++;
            }
            sil[j * S + i] = hit >= 2 ? 1f : 0f;
        }
        float[] prof = new float[PROF];
        for (int k = 0; k < PROF; k++) {
            int y = minY + Math.min(h - 1, (int) ((k + .5f) * h / PROF));
            int a = G, z = -1;
            for (int x = minX; x <= maxX; x++) if (mask[y * G + x]) { a = Math.min(a, x); z = Math.max(z, x); }
            prof[k] = z < 0 ? 0f : (z - a + 1) / (float) h;
        }
        out.sil = new Sil('?', sil, prof, w / (float) h);

        // luminância do interior (erosão 2x)
        boolean[] in = erode(erode(mask));
        List<Float> ls = new ArrayList<>();
        for (int i = 0; i < G * G; i++) if (in[i]) ls.add(lum(c, i));
        if (ls.size() < 20) { ls.clear(); in = erode(mask); for (int i = 0; i < G * G; i++) if (in[i]) ls.add(lum(c, i)); }
        if (ls.size() < 10) { ls.clear(); for (int i = 0; i < G * G; i++) if (mask[i]) ls.add(lum(c, i)); }
        float[] la = new float[ls.size()];
        for (int i = 0; i < la.length; i++) la[i] = ls.get(i);
        Arrays.sort(la);
        out.lum = la[la.length / 2];
        return out;
    }

    /** Verde vivo dos círculos de dica que o próprio app desenha sobre o tabuleiro (e suas bordas suavizadas). */
    static boolean overlayGreen(float r, float g, float b) {
        return g >= 165f && g - Math.max(r, b) >= 30f;
    }

    /**
     * Pixels cobertos pelo círculo de dica do app não dizem se havia peça embaixo. Um pixel coberto
     * vira "peça" somente se estiver ENTRE pedaços de peça (peça dos dois lados, na horizontal ou na
     * vertical, atravessando só pixels cobertos); arcos do anel fora da peça ficam como fundo.
     */
    private static void fillUnknown(boolean[] fg, boolean[] unk) {
        boolean[] res = new boolean[G * G];
        final int MAX = 9;
        for (int y = 0; y < G; y++) for (int x = 0; x < G; x++) {
            int i = y * G + x;
            if (!unk[i]) continue;
            boolean l = ray(fg, unk, x, y, -1, 0, MAX), r = ray(fg, unk, x, y, 1, 0, MAX);
            boolean u = ray(fg, unk, x, y, 0, -1, MAX), d = ray(fg, unk, x, y, 0, 1, MAX);
            res[i] = (l && r) || (u && d);
        }
        for (int i = 0; i < G * G; i++) if (unk[i]) { unk[i] = false; fg[i] = res[i]; }
    }

    private static boolean ray(boolean[] fg, boolean[] unk, int x, int y, int dx, int dy, int max) {
        for (int k = 1; k <= max; k++) {
            int xx = x + dx * k, yy = y + dy * k;
            if (xx < 0 || yy < 0 || xx >= G || yy >= G) return false;
            int j = yy * G + xx;
            if (unk[j]) continue;
            return fg[j];
        }
        return false;
    }

    private static float dist(float[][] c, int i, float[] ref) {
        return Math.max(Math.abs(c[0][i] - ref[0]), Math.max(Math.abs(c[1][i] - ref[1]), Math.abs(c[2][i] - ref[2])));
    }

    private static float lum(float[][] c, int i) { return .299f * c[0][i] + .587f * c[1][i] + .114f * c[2][i]; }

    private static boolean[] erode(boolean[] m) {
        boolean[] o = new boolean[G * G];
        for (int y = 1; y < G - 1; y++) for (int x = 1; x < G - 1; x++) {
            int i = y * G + x;
            o[i] = m[i] && m[i - 1] && m[i + 1] && m[i - G] && m[i + G];
        }
        return o;
    }

    static boolean[] dilate(float[] m, int r) {
        boolean[] o = new boolean[S * S];
        for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) {
            boolean v = false;
            for (int dy = -r; dy <= r && !v; dy++) for (int dx = -r; dx <= r; dx++) {
                int yy = y + dy, xx = x + dx;
                if (yy >= 0 && xx >= 0 && yy < S && xx < S && m[yy * S + xx] > .5f) { v = true; break; }
            }
            o[y * S + x] = v;
        }
        return o;
    }

    // ------------------------------------------------------------------ similaridade

    static float similarity(Sil a, Sil b) {
        int na = 0, nb = 0, ia = 0, ib = 0;
        for (int i = 0; i < S * S; i++) {
            if (a.m[i] > .5f) { na++; if (b.dil[i]) ia++; }
            if (b.m[i] > .5f) { nb++; if (a.dil[i]) ib++; }
        }
        if (na == 0 || nb == 0) return 0f;
        float cov = (ia / (float) na + ib / (float) nb) / 2f;
        float pd = 0;
        for (int k = 0; k < PROF; k++) pd += Math.abs(a.prof[k] - b.prof[k]);
        pd /= PROF;
        float profSim = Math.max(0f, 1f - pd * 2.5f);
        float asp = Math.min(1f, Math.abs((float) Math.log(a.aspect / b.aspect)));
        return 0.55f * cov + 0.30f * profSim + 0.15f * (1f - asp);
    }

    /** Devolve {tipo, melhor, segundo}: tipo '?' se a evidência for insuficiente. */
    static float[] classify(Sil s, Library lib) {
        float[] best = new float[128];
        for (Sil t : lib.items) best[t.type] = Math.max(best[t.type], similarity(s, t));
        char bt = '?'; float b1 = -1, b2 = -1;
        for (char t : "pnbrqk".toCharArray()) {
            float v = best[t];
            if (v > b1) { b2 = b1; b1 = v; bt = t; } else if (v > b2) b2 = v;
        }
        float minSim = lib.learned ? LEARNED_MIN_SIM : STATIC_MIN_SIM;
        float minGap = lib.learned ? LEARNED_MIN_GAP : STATIC_MIN_GAP;
        if (b1 < minSim || b1 - b2 < minGap) bt = '?';
        return new float[]{bt, b1, b2};
    }

    // ------------------------------------------------------------------ leitura

    /**
     * @param px     janela de pixels (largura W, altura H)
     * @param rough  área aproximada l,t,r,b dentro da janela
     * @param snap   ajustar às bordas reais antes de ler
     * @param stat   modelos embutidos (obrigatório)
     * @param learned modelos aprendidos nesta tela (pode ser null)
     * @param allowLearn tenta aprender a aparência das peças se a estrutura inicial estiver visível
     * @param holder recebe a biblioteca aprendida (índice 0), se houver
     */
    static Result read(int[] px, int W, int H, int[] rough, boolean snap, boolean whiteBottom,
                       Library stat, Library learned, boolean allowLearn, Library[] holder) {
        return read(px, W, H, rough, snap, whiteBottom, stat, learned, allowLearn, holder, null, null);
    }

    /**
     * @param expected posição rastreada (64 etiquetas a8..h1) ou null
     * @param ringSq   casas (a8..h1) cobertas por círculos de dica do próprio app, ou null
     */
    static Result read(int[] px, int W, int H, int[] rough, boolean snap, boolean whiteBottom,
                       Library stat, Library learned, boolean allowLearn, Library[] holder,
                       String expected, int[] ringSq) {
        Result res = new Result();
        int rw = rough[2] - rough[0], rh = rough[3] - rough[1];
        if (rw < 160 || rh < 160 || rough[0] < 0 || rough[1] < 0 || rough[2] > W || rough[3] > H) {
            res.message = "Área inválida: selecione o tabuleiro novamente";
            return res;
        }
        // candidatos de recorte: encaixado e original; vence o que formar melhor grade 8x8
        List<int[]> cands = new ArrayList<>();
        if (snap) { int[] s = BoardGeometry.snap(px, W, H, rough); if (s != null) cands.add(s); }
        cands.add(rough);
        int[] rect = null; Cell[] cells = null; float bestScore = -1;
        for (int[] cand : cands) {
            if (cand[2] - cand[0] < 160 || cand[3] - cand[1] < 160) continue;
            Cell[] cs = analyzeBoard(px, W, H, cand);
            if (cs == null) continue;
            float sc = gridScore(cs);
            if (sc > bestScore) { bestScore = sc; rect = cand; cells = cs; }
        }
        res.gridScore = Math.max(0f, bestScore);
        if (rect == null || bestScore < GRID_MIN) {
            res.status = Status.NO_GRID;
            res.rect = rect;
            res.message = "Tabuleiro não localizado: a área não forma a grade 8x8 (confira a área marcada)";
            return res;
        }
        res.rect = rect;
        markCovered(cells);

        // ordem a8..h1
        Cell[] ord = new Cell[64];
        for (int i = 0; i < 64; i++) ord[i] = whiteBottom ? cells[i] : cells[63 - i];

        Library lib = learned != null ? learned : stat;
        char[] out = classifyAll(ord, lib, res);
        boolean anyUnc = false;
        for (char ch : out) if (ch == '?') anyUnc = true;

        if (anyUnc && allowLearn && learned == null) {
            Library L = learnFromHome(ord, rect[2] - rect[0]);
            if (L != null) {
                Result r2 = new Result();
                char[] o2 = classifyAll(ord, L, r2);
                boolean unc2 = false;
                for (char ch : o2) if (ch == '?') unc2 = true;
                if (!unc2) {
                    out = o2; res.uncertain = r2.uncertain; res.learnedNow = true; anyUnc = false;
                    if (holder != null) holder[0] = L;
                    lib = L;
                } else if (holder != null) {
                    holder[0] = L; // mantém: pode servir nos próximos quadros
                    out = o2; res.uncertain = r2.uncertain;
                    anyUnc = true; lib = L;
                }
            }
        }
        if (anyUnc && !lib.learned) {
            int fixed = bootstrap(ord, out, lib);
            if (fixed > 0) {
                res.uncertain = new ArrayList<>();
                anyUnc = false;
                for (int i = 0; i < 64; i++) if (out[i] == '?') { anyUnc = true; res.uncertain.add(Board.name(i)); }
            }
        }
        if (anyUnc) {
            int fixed = exemplarPass(ord, out, lib);
            if (fixed > 0) {
                res.uncertain = new ArrayList<>();
                anyUnc = false;
                for (int i = 0; i < 64; i++) if (out[i] == '?') { anyUnc = true; res.uncertain.add(Board.name(i)); }
            }
        }
        if (anyUnc && expected != null && expected.length() == 64 && ringSq != null) {
            if (ringFallback(ord, out, lib, expected, ringSq) > 0) {
                res.uncertain = new ArrayList<>();
                anyUnc = false;
                for (int i = 0; i < 64; i++) if (out[i] == '?') { anyUnc = true; res.uncertain.add(Board.name(i)); }
            }
        }
        res.learnedUsed = lib.learned;
        res.labels = new String(out);
        if (anyUnc) {
            res.status = Status.UNCERTAIN;
            StringBuilder sb = new StringBuilder();
            int n = 0;
            for (String u : res.uncertain) { if (n++ == 6) { sb.append("…"); break; } sb.append(sb.length() > 0 ? " " : "").append(u); }
            res.message = "Leitura incerta (" + res.uncertain.size() + " casas: " + sb + "). Confira tema e peças cobertas";
        } else {
            res.status = Status.OK;
            res.message = "";
        }
        return res;
    }

    static Cell[] analyzeBoard(int[] px, int W, int H, int[] r) {
        int s = Math.min(r[2] - r[0], r[3] - r[1]);
        if (s < 160 || r[0] < 0 || r[1] < 0 || r[0] + s > W || r[1] + s > H) return null;
        Cell[] cs = pass(px, W, r, s, null);
        float[][] med = parityMedians(cs);
        if (med == null) return cs;
        float sep = Math.max(Math.abs(med[0][0] - med[1][0]), Math.max(Math.abs(med[0][1] - med[1][1]), Math.abs(med[0][2] - med[1][2])));
        if (sep < 12f) return cs;
        return pass(px, W, r, s, med);   // 2ª passada: remove letras/números com a cor da outra casa
    }

    private static Cell[] pass(int[] px, int W, int[] r, int s, float[][] med) {
        Cell[] cs = new Cell[64];
        for (int row = 0; row < 8; row++) for (int col = 0; col < 8; col++) {
            int l = r[0] + Math.round(s * col / 8f), t = r[1] + Math.round(s * row / 8f);
            int rr = r[0] + Math.round(s * (col + 1) / 8f), bb = r[1] + Math.round(s * (row + 1) / 8f);
            float[] other = med == null ? null : med[1 - ((row + col) % 2)];
            cs[row * 8 + col] = analyzeCell(px, W, l, t, rr - l, bb - t, other);
        }
        return cs;
    }

    /** Cor mediana de fundo de cada paridade (0 = casas com (linha+coluna) par), ou null se insuficiente. */
    private static float[][] parityMedians(Cell[] cs) {
        float[][] med = new float[2][3];
        for (int par = 0; par < 2; par++) for (int ch = 0; ch < 3; ch++) {
            List<Float> v = new ArrayList<>();
            for (int i = 0; i < 64; i++) if (((i / 8) + (i % 8)) % 2 == par && cs[i].bgOk) v.add(cs[i].bg[ch]);
            if (v.size() < 8) return null;
            float[] a = new float[v.size()];
            for (int i = 0; i < a.length; i++) a[i] = v.get(i);
            Arrays.sort(a);
            med[par][ch] = a[a.length / 2];
        }
        return med;
    }

    /** Fração de casas cujo fundo concorda com a cor da sua paridade (padrão xadrez). */
    static float gridScore(Cell[] cs) { return grid(cs, false); }

    /**
     * Casas cujo fundo não é a cor do tabuleiro nem um realce típico (amarelo do último lance,
     * vermelho de xeque/pré-lance) estão encobertas por outro elemento: não dá para afirmar
     * que estão vazias nem ocupadas, então viram '?'.
     */
    static void markCovered(Cell[] cs) { grid(cs, true); }

    /** Realces do Chess.com (último lance, livro, xeque, pré-lance): matiz vermelho→amarelo-esverdeado e claro. */
    private static boolean tint(float[] bg) {
        float mx = Math.max(bg[0], Math.max(bg[1], bg[2])), mn = Math.min(bg[0], Math.min(bg[1], bg[2]));
        if (mx < 120f || mx - mn < 25f) return false;
        float h;
        if (mx == bg[0]) h = 60f * (((bg[1] - bg[2]) / (mx - mn)) % 6f);
        else if (mx == bg[1]) h = 60f * ((bg[2] - bg[0]) / (mx - mn) + 2f);
        else h = 60f * ((bg[0] - bg[1]) / (mx - mn) + 4f);
        if (h < 0) h += 360f;
        return h <= 80f || h >= 345f;
    }

    private static float grid(Cell[] cs, boolean mark) {
        float[][] med = new float[2][3];
        for (int par = 0; par < 2; par++) {
            for (int ch = 0; ch < 3; ch++) {
                List<Float> v = new ArrayList<>();
                for (int i = 0; i < 64; i++) if (((i / 8) + (i % 8)) % 2 == par && cs[i].bgOk) v.add(cs[i].bg[ch]);
                if (v.size() < 8) return 0f;
                float[] a = new float[v.size()];
                for (int i = 0; i < a.length; i++) a[i] = v.get(i);
                Arrays.sort(a);
                med[par][ch] = a[a.length / 2];
            }
        }
        float sep = Math.max(Math.abs(med[0][0] - med[1][0]), Math.max(Math.abs(med[0][1] - med[1][1]), Math.abs(med[0][2] - med[1][2])));
        if (sep < 12f) return 0f;
        int ok = 0;
        for (int i = 0; i < 64; i++) {
            int par = ((i / 8) + (i % 8)) % 2;
            float d = Math.max(Math.abs(cs[i].bg[0] - med[par][0]), Math.max(Math.abs(cs[i].bg[1] - med[par][1]), Math.abs(cs[i].bg[2] - med[par][2])));
            if (cs[i].bgOk && d <= 34f) ok++;
            else if (mark && !tint(cs[i].bg)) { cs[i].emptyCell = false; cs[i].uncertainCell = true; cs[i].sil = null; }
        }
        // casas destacadas (último lance) são poucas; exige maioria esmagadora
        return ok / 64f;
    }

    private static char[] classifyAll(Cell[] ord, Library lib, Result res) {
        char[] out = new char[64];
        res.uncertain = new ArrayList<>();
        // limiar de luminância
        float thr = lumThreshold(ord, lib);
        for (int i = 0; i < 64; i++) {
            Cell c = ord[i];
            char ch;
            if (c.emptyCell) ch = '.';
            else if (c.uncertainCell || c.sil == null) ch = '?';
            else {
                float[] cl = classify(c.sil, lib);
                char t = (char) cl[0];
                if (t == '?') ch = '?';
                else if (Float.isNaN(thr) || Math.abs(c.lum - thr) < 10f) ch = '?';
                else ch = c.lum > thr ? Character.toUpperCase(t) : t;
            }
            out[i] = ch;
            if (ch == '?') res.uncertain.add(Board.name(i));
        }
        return out;
    }

    /**
     * Casas incertas são comparadas com as peças já lidas COM SEGURANÇA neste mesmo tabuleiro
     * (mesmo tema, mesmo tamanho). Exige semelhança alta e folga sobre o 2º tipo; nunca altera
     * uma casa já decidida e nunca decide sem exemplar parecido.
     * @return quantas casas foram resolvidas
     */
    static int exemplarPass(Cell[] ord, char[] out, Library base) {
        Library ex = new Library(true);
        for (int i = 0; i < 64; i++) {
            char ch = out[i];
            if (ch == '?' || ch == '.' || ord[i].sil == null) continue;
            Sil s = ord[i].sil;
            ex.add(new Sil(Character.toLowerCase(ch), s.m, s.prof, s.aspect));
        }
        if (ex.isEmpty()) return 0;
        float thr = lumThreshold(ord, base);
        if (Float.isNaN(thr)) return 0;
        int fixed = 0;
        for (int i = 0; i < 64; i++) {
            if (out[i] != '?' || ord[i].sil == null || ord[i].uncertainCell) continue;
            float[] best = new float[128];
            for (Sil t : ex.items) best[t.type] = Math.max(best[t.type], similarity(ord[i].sil, t));
            char bt = '?'; float b1 = -1, b2 = -1;
            for (char t : "pnbrqk".toCharArray()) {
                float v = best[t];
                if (v > b1) { b2 = b1; b1 = v; bt = t; } else if (v > b2) b2 = v;
            }
            if (b1 < 0.90f || b1 - b2 < 0.05f) continue;
            if (Math.abs(ord[i].lum - thr) < 10f) continue;
            out[i] = ord[i].lum > thr ? Character.toUpperCase(bt) : bt;
            fixed++;
        }
        return fixed;
    }

    /**
     * Casas cobertas por um círculo de dica do app: o círculo deforma a silhueta e deixaria a casa
     * em '?'. Se a casa ficou incerta e a posição rastreada tem ali uma peça, aceita essa peça apenas
     * quando (1) há um objeto na casa, (2) a cor medida bate com a da peça esperada e (3) o formato
     * mais parecido (modelos ou peças vistas no tabuleiro) concorda com o tipo esperado.
     * Qualquer divergência mantém '?'. Não toca em casas fora dos círculos.
     */
    static int ringFallback(Cell[] ord, char[] out, Library base, String expected, int[] ringSq) {
        float thr = lumThreshold(ord, base);
        if (Float.isNaN(thr)) return 0;
        Library ex = new Library(true);
        for (int i = 0; i < 64; i++) {
            char ch = out[i];
            if (ch == '?' || ch == '.' || ord[i].sil == null) continue;
            Sil sl = ord[i].sil;
            ex.add(new Sil(Character.toLowerCase(ch), sl.m, sl.prof, sl.aspect));
        }
        int fixed = 0;
        for (int i : ringSq) {
            if (i < 0 || i >= 64 || out[i] != '?') continue;
            char e = expected.charAt(i);
            if ("pnbrqkPNBRQK".indexOf(e) < 0) continue;
            Cell c = ord[i];
            if (c.sil == null || c.uncertainCell || Float.isNaN(c.lum)) continue;
            if (Math.abs(c.lum - thr) < 10f || (c.lum > thr) != Character.isUpperCase(e)) continue;
            char t = Character.toLowerCase(e);
            if (argType(c.sil, base) != t && (ex.isEmpty() || argType(c.sil, ex) != t)) continue;
            out[i] = e;
            fixed++;
        }
        return fixed;
    }

    /** Tipo de maior semelhança, sem limiares (só para confirmar uma expectativa). */
    private static char argType(Sil s, Library lib) {
        float[] best = new float[128];
        for (Sil t : lib.items) best[t.type] = Math.max(best[t.type], similarity(s, t));
        char bt = '?'; float b = -1;
        for (char t : "pnbrqk".toCharArray()) if (best[t] > b) { b = best[t]; bt = t; }
        return bt;
    }

    private static float lumThreshold(Cell[] ord, Library lib) {
        if (!Float.isNaN(lib.lumWhite) && !Float.isNaN(lib.lumBlack)) return (lib.lumWhite + lib.lumBlack) / 2f;
        List<Float> ls = new ArrayList<>();
        for (Cell c : ord) if (c.sil != null && !Float.isNaN(c.lum)) ls.add(c.lum);
        if (ls.isEmpty()) return Float.NaN;
        float lo = Collections.min(ls), hi = Collections.max(ls);
        if (hi - lo < 50f) return 128f;
        float t = (lo + hi) / 2f;
        for (int it = 0; it < 10; it++) {
            double a = 0, b = 0; int na = 0, nb = 0;
            for (float v : ls) if (v > t) { a += v; na++; } else { b += v; nb++; }
            if (na == 0 || nb == 0) break;
            t = (float) ((a / na + b / nb) / 2);
        }
        return t;
    }

    // ------------------------------------------------------------------ segunda passada

    /**
     * Casas ainda duvidosas são comparadas com peças DESTE tabuleiro já reconhecidas com folga
     * (mesmo tema, mesma escala). Só altera casas '?'; nunca muda uma casa já lida; exige amostra
     * do mesmo tipo e semelhança alta com margem. Se as amostras de um tipo discordam entre si,
     * o tipo é descartado. Não depende de ter visto a posição inicial.
     * @return quantas casas foram resolvidas
     */
    static int bootstrap(Cell[] ord, char[] out, Library base) {
        Library L = new Library(true);
        String types = "pnbrqk";
        List<List<Sil>> samples = new ArrayList<>();
        for (int k = 0; k < 6; k++) samples.add(new ArrayList<>());
        for (int i = 0; i < 64; i++) {
            if (out[i] == '?' || out[i] == '.' || ord[i].sil == null) continue;
            float[] cl = classify(ord[i].sil, base);
            if ((char) cl[0] == '?' || cl[1] < 0.85f || cl[1] - cl[2] < 0.06f) continue;
            samples.get(types.indexOf(Character.toLowerCase(out[i]))).add(ord[i].sil);
        }
        for (int k = 0; k < 6; k++) {
            List<Sil> sm = samples.get(k);
            boolean consistent = !sm.isEmpty();
            for (int a = 0; a < sm.size() && consistent; a++) for (int b = a + 1; b < sm.size(); b++)
                if (similarity(sm.get(a), sm.get(b)) < 0.80f) { consistent = false; break; }
            if (consistent) for (Sil x : sm) L.add(new Sil(types.charAt(k), x.m, x.prof, x.aspect));
        }
        if (L.isEmpty()) return 0;
        float thr = lumThreshold(ord, base);
        if (Float.isNaN(thr)) return 0;
        int fixed = 0;
        for (int i = 0; i < 64; i++) {
            if (out[i] != '?' || ord[i].sil == null || ord[i].uncertainCell || Float.isNaN(ord[i].lum)) continue;
            float[] cl = classify(ord[i].sil, L);
            if ((char) cl[0] == '?' || cl[1] < 0.85f || cl[1] - cl[2] < 0.06f) continue;
            if (Math.abs(ord[i].lum - thr) < 10f) continue;
            out[i] = ord[i].lum > thr ? Character.toUpperCase((char) cl[0]) : (char) cl[0];
            fixed++;
        }
        return fixed;
    }

    // ------------------------------------------------------------------ aprendizado

    /**
     * Aprende silhuetas e luminâncias dos 6 tipos a partir da estrutura inicial visível
     * (4 linhas externas quase cheias, centro quase vazio). Só vale se as amostras forem
     * consistentes entre si; caso contrário devolve null. Usa apenas aparência — a posição
     * lida depois vem de cada casa individualmente (um peão em d3 é lido como peão em d3).
     */
    static Library learnFromHome(Cell[] ord, int boardSize) {
        int occ = 0, mid = 0;
        for (int i = 0; i < 64; i++) {
            Cell c = ord[i];
            boolean home = i < 16 || i >= 48;
            if (c.sil != null) { if (home) occ++; else mid++; }
        }
        if (occ < 28 || mid > 2) return null;
        // cada linha inicial precisa ter ao menos 6 ocupadas e as posições-chave não podem faltar
        Library L = new Library(true);
        L.cellSize = boardSize;
        List<List<Sil>> samples = new ArrayList<>();
        String types = "pnbrqk";
        for (int k = 0; k < 6; k++) samples.add(new ArrayList<>());
        List<Float> white = new ArrayList<>(), black = new ArrayList<>();
        for (int i = 0; i < 64; i++) {
            if (!(i < 16 || i >= 48)) continue;
            Cell c = ord[i];
            char h = HOME.charAt(i);
            if (c.sil == null) {
                if (i >= 8 && i < 56 && Character.toLowerCase(h) == 'p') continue; // peão a menos (jogado)
                return null;                                                       // peça maior ausente
            }
            int k = types.indexOf(Character.toLowerCase(h));
            samples.get(k).add(c.sil);
            if (Character.isUpperCase(h)) white.add(c.lum); else black.add(c.lum);
        }
        if (white.isEmpty() || black.isEmpty()) return null;
        float mw = median(white), mb = median(black);
        if (mw - mb < 40f) return null;                       // cores não separáveis
        float thr = (mw + mb) / 2f;
        for (float v : white) if (v < thr + 8f) return null;  // tem de estar claramente do lado certo
        for (float v : black) if (v > thr - 8f) return null;
        // consistência interna dos tipos
        for (int k = 0; k < 6; k++) {
            List<Sil> s = samples.get(k);
            if (s.size() < (k == 0 ? 8 : 2)) return null;
            for (int a = 0; a < s.size(); a++) for (int b = a + 1; b < s.size(); b++)
                if (similarity(s.get(a), s.get(b)) < 0.80f) return null;
        }
        for (int k = 0; k < 6; k++) for (Sil s : samples.get(k)) L.add(new Sil(types.charAt(k), s.m, s.prof, s.aspect));
        L.lumWhite = mw; L.lumBlack = mb;
        // autoverificação: cada amostra tem de se reconhecer corretamente e com folga
        for (int k = 0; k < 6; k++) for (Sil s : samples.get(k)) {
            float[] cl = classify(s, L);
            if ((char) cl[0] != types.charAt(k)) return null;
        }
        return L;
    }

    private static float median(List<Float> v) {
        float[] a = new float[v.size()];
        for (int i = 0; i < a.length; i++) a[i] = v.get(i);
        Arrays.sort(a);
        return a[a.length / 2];
    }
}
